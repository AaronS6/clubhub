import { createServer, Server as HttpServer, IncomingMessage, ServerResponse } from "http"
import { Server } from "socket.io"

// Socket.io server — gateway forwards browser ws connections to this port.
// Path MUST be "/" so Caddy routes it correctly.
const wsServer = createServer()
const io = new Server(wsServer, {
  path: "/",
  cors: { origin: "*", methods: ["GET", "POST"] },
  pingTimeout: 60000,
  pingInterval: 25000,
})

// Presence: map socketId -> { userId, clubIds: Set }. We broadcast presence
// deltas to the affected club rooms so clients can show online dots on avatars.
const socketPresence = new Map<string, { userId: string; clubIds: Set<string> }>()

function broadcastPresence(clubId: string) {
  const online: string[] = []
  for (const p of socketPresence.values()) {
    if (p.clubIds.has(clubId)) online.push(p.userId)
  }
  io.to(`club:${clubId}`).emit("realtime:club", { type: "presence_update", online, clubId })
}

io.on("connection", (socket) => {
  socket.on("auth", (payload: { userId: string; clubIds: string[] }) => {
    if (!payload?.userId) return
    const clubSet = new Set(payload.clubIds ?? [])
    socketPresence.set(socket.id, { userId: payload.userId, clubIds: clubSet })
    socket.join(`user:${payload.userId}`)
    for (const clubId of clubSet) {
      socket.join(`club:${clubId}`)
      broadcastPresence(clubId)
    }
  })
  socket.on("join-club", (clubId: string) => {
    if (!clubId) return
    socket.join(`club:${clubId}`)
    const p = socketPresence.get(socket.id)
    if (p) {
      p.clubIds.add(clubId)
      broadcastPresence(clubId)
    }
  })
  socket.on("leave-club", (clubId: string) => {
    if (!clubId) return
    socket.leave(`club:${clubId}`)
    const p = socketPresence.get(socket.id)
    if (p && p.clubIds.delete(clubId)) {
      broadcastPresence(clubId)
    }
  })
  socket.on("viewing", (payload: { clubId: string; view: string }) => {
    // Used by the "X people viewing" indicator (e.g. approvals queue).
    if (!payload?.clubId || !payload.view) return
    io.to(`club:${payload.clubId}`).emit("realtime:viewing", {
      userId: socketPresence.get(socket.id)?.userId,
      view: payload.view,
      clubId: payload.clubId,
    })
  })
  socket.on("stop-viewing", (payload: { clubId: string; view: string }) => {
    if (!payload?.clubId) return
    io.to(`club:${payload.clubId}`).emit("realtime:stop-viewing", {
      userId: socketPresence.get(socket.id)?.userId,
      view: payload.view,
      clubId: payload.clubId,
    })
  })
  // Chat typing indicator — broadcast to the club room with the type tag
  // `chat_typing` so the ChatView can show "X is typing…" without
  // invalidating React-Query caches (typing is ephemeral; refetching the
  // message list on every keystroke would be wasteful and visually janky).
  // We also include the originating userId so recipients can ignore their
  // own typing.
  socket.on("typing", (payload: { clubId?: string; conversationId?: string; userId?: string }) => {
    if (!payload?.clubId || !payload.conversationId || !payload.userId) return
    io.to(`club:${payload.clubId}`).emit("realtime:club", {
      type: "chat_typing",
      conversationId: payload.conversationId,
      userId: payload.userId,
      clubId: payload.clubId,
    })
  })
  socket.on("typing:stop", (payload: { clubId?: string; conversationId?: string; userId?: string }) => {
    if (!payload?.clubId || !payload.conversationId || !payload.userId) return
    io.to(`club:${payload.clubId}`).emit("realtime:club", {
      type: "chat_typing:stop",
      conversationId: payload.conversationId,
      userId: payload.userId,
      clubId: payload.clubId,
    })
  })
  socket.on("disconnect", () => {
    const p = socketPresence.get(socket.id)
    if (p) {
      for (const clubId of p.clubIds) broadcastPresence(clubId)
      socketPresence.delete(socket.id)
    }
  })
})

// Separate internal HTTP API (port 3004) for the Next.js app to emit events.
// This avoids the socket.io path:"/" handler intercepting plain POSTs.
const INTERNAL_TOKEN = process.env.REALTIME_TOKEN || "dev-realtime-token"
const emitServer = createServer(async (req: IncomingMessage, res: ServerResponse) => {
  if (req.method !== "POST") {
    res.writeHead(404, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "not found" }))
    return
  }
  const url = new URL(req.url ?? "", "http://localhost")
  if (url.pathname !== "/emit") {
    res.writeHead(404, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "not found" }))
    return
  }
  const auth = req.headers["x-realtime-token"]
  if (auth !== INTERNAL_TOKEN) {
    res.writeHead(401, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "unauthorized" }))
    return
  }
  const chunks: Buffer[] = []
  for await (const chunk of req) chunks.push(chunk as Buffer)
  let body: any
  try {
    body = JSON.parse(Buffer.concat(chunks).toString("utf8"))
  } catch {
    res.writeHead(400, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "bad json" }))
    return
  }
  const { room, event, data } = body || {}
  if (!room || !event) {
    res.writeHead(400, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "room and event required" }))
    return
  }
  io.to(room).emit(event, data ?? {})
  res.writeHead(200, { "Content-Type": "application/json" }).end(JSON.stringify({ ok: true }))
})

const WS_PORT = 3003
const EMIT_PORT = 3004

wsServer.listen(WS_PORT, () => console.log(`Realtime (socket.io) on port ${WS_PORT}`))
emitServer.listen(EMIT_PORT, () => console.log(`Realtime emit API on port ${EMIT_PORT}`))

const shutdown = (srv: HttpServer, name: string) => srv.close(() => console.log(`${name} closed`))
process.on("SIGTERM", () => { shutdown(wsServer, "ws"); shutdown(emitServer, "emit") })
process.on("SIGINT", () => { shutdown(wsServer, "ws"); shutdown(emitServer, "emit") })
