#!/bin/bash
# Keep ClubHub production server running forever.
cd /home/z/my-project/.next/standalone
while true; do
  if ! curl -s -o /dev/null --max-time 5 http://localhost:3000/ 2>/dev/null; then
    echo "[$(date +%H:%M:%S)] Server down, starting..."
    pkill -f "server.js" 2>/dev/null
    sleep 1
    NODE_ENV=production NEXT_TELEMETRY_DISABLED=1 NODE_OPTIONS="--max-old-space-size=1200" bun server.js > /home/z/my-project/server.log 2>&1 &
    echo "[$(date +%H:%M:%S)] Started server"
    sleep 3
  fi
  sleep 8
done
