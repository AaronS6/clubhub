// Verification script for Task 2D — runs the 8 Section-5 checks against the live dev server.
// Usage: bun scripts/verify.mjs
//
// This script:
//   1. Signs up two test users via /api/auth/signup.
//   2. Logs them in via NextAuth credentials callback (cookie jar).
//   3. Exercises each of the 8 verification items end-to-end against http://localhost:3000.
//   4. Cleans up the test users/clubs/files it creates.
//   5. Prints a summary table.
//
// Notes:
//   - Uses the existing dev database (db/custom.db) but DELETES all test artifacts at the end.
//   - Test users have emails prefixed with `2d-verify-` so cleanup is unambiguous.

import sharp from "sharp";
import { promises as fs } from "fs";
import path from "path";

const BASE = "http://localhost:3000";
const RUN_PREFIX = `2d-verify-${Date.now()}`;
const CLEANUP = {
  users: [],
  clubs: [],
  files: [],
};

const results = [];
function pass(name, detail = "") {
  results.push({ name, ok: true, detail });
  console.log(`✓ ${name}${detail ? ` — ${detail}` : ""}`);
}
function fail(name, reason) {
  results.push({ name, ok: false, reason });
  console.log(`✗ ${name} — ${reason}`);
}

// ---------------- Cookie-jar fetch helper ----------------
class CookieJar {
  constructor() {
    this.cookies = new Map();
  }
  set(url, cookieHeader) {
    // Parse Set-Cookie header(s) and store name -> value
    const headers = Array.isArray(cookieHeader) ? cookieHeader : [cookieHeader];
    for (const h of headers) {
      if (!h) continue;
      const first = h.split(";")[0];
      const eq = first.indexOf("=");
      if (eq > 0) {
        const name = first.slice(0, eq).trim();
        const value = first.slice(eq + 1).trim();
        this.cookies.set(name, value);
      }
    }
  }
  header() {
    return Array.from(this.cookies.entries())
      .map(([n, v]) => `${n}=${v}`)
      .join("; ");
  }
}

async function req(jar, method, urlPath, { body, headers = {}, isForm = false, rawBody = false, retries = 3 } = {}) {
  const url = urlPath.startsWith("http") ? urlPath : `${BASE}${urlPath}`;
  const finalHeaders = { ...headers };
  const cookie = jar.header();
  if (cookie) finalHeaders.Cookie = cookie;

  let payload;
  if (rawBody) {
    // Caller supplied a string + explicit Content-Type; pass through as-is.
    payload = body;
  } else if (body && !isForm) {
    finalHeaders["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  } else if (isForm) {
    payload = body; // FormData
  } else {
    payload = undefined;
  }

  // Retry on transient connection errors (dev server may be recompiling or briefly OOM).
  let lastErr;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, { method, headers: finalHeaders, body: payload });
      if (res.headers.get("set-cookie")) {
        jar.set(url, res.headers.get("set-cookie"));
        const multi = res.headers.getSetCookie?.();
        if (multi && multi.length > 1) jar.set(url, multi);
      }
      return res;
    } catch (e) {
      lastErr = e;
      // Wait a bit before retrying (exponential backoff capped at 4s)
      const wait = Math.min(1000 * Math.pow(2, attempt), 4000);
      await new Promise((r) => setTimeout(r, wait));
    }
  }
  throw lastErr;
}

async function jsonOrText(res) {
  const ct = res.headers.get("content-type") || "";
  if (ct.includes("application/json")) {
    try { return await res.json(); } catch { return await res.text(); }
  }
  return await res.text();
}

// ---------------- Auth helpers ----------------
async function getCsrfToken(jar) {
  const res = await req(jar, "GET", "/api/auth/csrf");
  const data = await res.json();
  return data.csrfToken;
}

async function signup(email, password, name) {
  const res = await fetch(`${BASE}/api/auth/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password, name }),
  });
  if (res.status !== 200) throw new Error(`signup failed: ${res.status}`);
  return res.json();
}

async function login(email, password) {
  const jar = new CookieJar();
  const csrf = await getCsrfToken(jar);
  const res = await req(jar, "POST", "/api/auth/callback/credentials", {
    body: new URLSearchParams({
      csrfToken: csrf,
      email,
      password,
      json: "true",
      callbackUrl: "/",
    }).toString(),
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    rawBody: true,
  });
  if (res.status !== 200) throw new Error(`login failed: ${res.status}`);
  // Fetch session to confirm login worked
  const s = await req(jar, "GET", "/api/auth/session");
  const sj = await s.json();
  if (!sj?.user?.email) throw new Error(`login did not produce session: ${JSON.stringify(sj)}`);
  return { jar, user: sj.user };
}

// ---------------- Helpers for cleanup ----------------
async function cleanup(clubsCreated, usersCreated, filesToClean) {
  // Use admin via the existing custom.db connection through a script that calls db directly
  // We'll delete via the API where possible (leave club), but for users we need a direct path.
  // Easiest: spawn a tiny Prisma script via `bun -e` to delete by id.
  const payload = JSON.stringify({ clubsCreated, usersCreated, filesToClean });
  const fs2 = await import("fs");
  const tmpPath = path.join(process.cwd(), "scripts", ".cleanup-payload.json");
  await fs2.promises.writeFile(tmpPath, payload);
  // Use a tiny inline bun script with @/lib/db
  const { execSync } = await import("child_process");
  try {
    execSync(`bun -e '
import { db } from "./src/lib/db";
const fs = require("fs");
const p = JSON.parse(fs.readFileSync("./scripts/.cleanup-payload.json","utf8"));
(async () => {
  for (const cid of p.clubsCreated) {
    await db.club.delete({ where: { id: cid } }).catch(()=>{});
  }
  for (const uid of p.usersCreated) {
    await db.user.delete({ where: { id: uid } }).catch(()=>{});
  }
  await db.$disconnect();
})();
'`, { stdio: "inherit", cwd: process.cwd() });
  } catch (e) {
    console.error("cleanup script error:", e.message);
  }
  // Remove orphan proof files
  for (const f of filesToClean) {
    await fs.unlink(f).catch(() => {});
  }
  await fs2.promises.unlink(tmpPath).catch(() => {});
}

// ---------------- Check 1: image upload + sharp compression ----------------
async function check1_imageCompression(jar, clubId) {
  // Generate a large 3000x2000 PNG (solid gradient)
  const bigPng = await sharp({
    create: { width: 3000, height: 2000, channels: 3, background: { r: 200, g: 50, b: 100 } },
  }).png().toBuffer();
  const inputSize = bigPng.length;

  const form = new FormData();
  form.append("file", new Blob([bigPng], { type: "image/png" }), "big.png");

  const res = await req(jar, "POST", `/api/clubs/${clubId}/hours/upload`, {
    body: form, isForm: true,
  });
  if (res.status !== 200) {
    return fail("1. Image upload + sharp compression", `upload returned ${res.status}`);
  }
  const data = await res.json();
  if (!data?.url) return fail("1. Image upload + sharp compression", "no url returned");
  const fileRel = data.url.replace(/^\//, "");
  const fullPath = path.join(process.cwd(), "public", fileRel);
  CLEANUP.files.push(fullPath);

  const stat = await fs.stat(fullPath);
  const outputSize = stat.size;

  // Verify dimensions are ≤1600px on the long edge
  const meta = await sharp(fullPath).metadata();

  if (outputSize >= inputSize) {
    return fail("1. Image upload + sharp compression", `output (${outputSize}B) not smaller than input (${inputSize}B)`);
  }
  if (Math.max(meta.width || 0, meta.height || 0) > 1600) {
    return fail("1. Image upload + sharp compression", `long edge ${Math.max(meta.width, meta.height)} > 1600`);
  }
  return pass("1. Image upload + sharp compression", `input=${inputSize}B → output=${outputSize}B (jpg, ${meta.width}x${meta.height})`);
}

// ---------------- Check 2: proof file deleted on approve + reject ----------------
async function check2_proofDeletedOnApproveAndReject(jar, clubId, hourSubmitterJar, hourSubmitterUserId) {
  // Submit two hours entries, each with a proof image
  async function uploadProof(j) {
    const png = await sharp({ create: { width: 800, height: 600, channels: 3, background: { r: 10, g: 200, b: 80 } } }).png().toBuffer();
    const form = new FormData();
    form.append("file", new Blob([png], { type: "image/png" }), "p.png");
    const r = await req(j, "POST", `/api/clubs/${clubId}/hours/upload`, { body: form, isForm: true });
    const d = await r.json();
    return d.url;
  }
  async function submitHours(j, proofUrl) {
    const r = await req(j, "POST", `/api/clubs/${clubId}/hours`, {
      body: {
        dateOfService: new Date(Date.now() - 86400000).toISOString(),
        hours: 2,
        reasonText: "verify check2 — proof deletion test",
        proofFileUrl: proofUrl,
      },
    });
    const d = await r.json();
    return d.entry;
  }
  async function fileExists(proofUrl) {
    const rel = proofUrl.replace(/^\//, "");
    const p = path.join(process.cwd(), "public", rel);
    try { await fs.access(p); return true; } catch { return false; }
  }

  // APPROVE path
  const proof1 = await uploadProof(hourSubmitterJar);
  const entry1 = await submitHours(hourSubmitterJar, proof1);
  const file1Path = path.join(process.cwd(), "public", proof1.replace(/^\//, ""));
  const r1 = await req(jar, "PATCH", `/api/clubs/${clubId}/hours/${entry1.id}`, { body: { status: "approved", reviewComment: "ok" } });
  if (r1.status !== 200) return fail("2. Proof deleted on approve+reject", `approve PATCH returned ${r1.status}`);
  const stillThere1 = await fileExists(proof1);
  if (stillThere1) return fail("2. Proof deleted on approve+reject", `approve did NOT delete proof file at ${proof1}`);

  // REJECT path
  const proof2 = await uploadProof(hourSubmitterJar);
  const entry2 = await submitHours(hourSubmitterJar, proof2);
  const r2 = await req(jar, "PATCH", `/api/clubs/${clubId}/hours/${entry2.id}`, { body: { status: "rejected", reviewComment: "nope" } });
  if (r2.status !== 200) return fail("2. Proof deleted on approve+reject", `reject PATCH returned ${r2.status}`);
  const stillThere2 = await fileExists(proof2);
  if (stillThere2) return fail("2. Proof deleted on approve+reject", `reject did NOT delete proof file at ${proof2}`);

  return pass("2. Proof deleted on approve+reject", "both approve and reject removed the proof file from disk");
}

// ---------------- Check 3: last-executive guard ----------------
async function check3_lastExecutiveGuard(jarA, clubId, userAId, jarB, userBId) {
  // A is sole exec → demote self should fail with 400
  const r1 = await req(jarA, "PATCH", `/api/clubs/${clubId}/members`, { body: { action: "demote", userId: userAId } });
  if (r1.status !== 400) return fail("3. Last-executive guard", `expected 400 on demote-self (got ${r1.status})`);
  const j1 = await jsonOrText(r1);
  if (!String(j1?.error || "").toLowerCase().includes("last executive")) {
    return fail("3. Last-executive guard", `demote error message missing 'last executive': ${JSON.stringify(j1)}`);
  }

  // A removes self → should fail with 400
  const r2 = await req(jarA, "PATCH", `/api/clubs/${clubId}/members`, { body: { action: "remove", userId: userAId } });
  if (r2.status !== 400) return fail("3. Last-executive guard", `expected 400 on remove-self (got ${r2.status})`);
  const j2 = await jsonOrText(r2);
  if (!String(j2?.error || "").toLowerCase().includes("last executive")) {
    return fail("3. Last-executive guard", `remove error message missing 'last executive': ${JSON.stringify(j2)}`);
  }

  // B joins the club as a member
  await req(jarB, "POST", "/api/clubs/join", {
    body: { clubCode: CLUB_CODES[clubId].code, clubPassword: CLUB_CODES[clubId].password },
  });

  // A promotes B → 200
  const r3 = await req(jarA, "PATCH", `/api/clubs/${clubId}/members`, { body: { action: "promote", userId: userBId } });
  if (r3.status !== 200) return fail("3. Last-executive guard", `promote B returned ${r3.status}`);

  // Path 1: A removes B (2nd exec) → should succeed (A is still exec).
  const r4 = await req(jarA, "PATCH", `/api/clubs/${clubId}/members`, { body: { action: "remove", userId: userBId } });
  if (r4.status !== 200) return fail("3. Last-executive guard", `remove 2nd exec B failed: ${r4.status}`);

  // Re-add B (was "removed" status — re-activates on join)
  await req(jarB, "POST", "/api/clubs/join", {
    body: { clubCode: CLUB_CODES[clubId].code, clubPassword: CLUB_CODES[clubId].password },
  });
  const r5 = await req(jarA, "PATCH", `/api/clubs/${clubId}/members`, { body: { action: "promote", userId: userBId } });
  if (r5.status !== 200) return fail("3. Last-executive guard", `re-promote B failed: ${r5.status}`);

  // Path 2: A demotes self now that B is also exec → 200
  const r6 = await req(jarA, "PATCH", `/api/clubs/${clubId}/members`, { body: { action: "demote", userId: userAId } });
  if (r6.status !== 200) return fail("3. Last-executive guard", `demote self (with 2nd exec) failed: ${r6.status}`);

  // Restore A to executive (using B's now-executive session) so the club is left in a sane state.
  const r7 = await req(jarB, "PATCH", `/api/clubs/${clubId}/members`, { body: { action: "promote", userId: userAId } });
  if (r7.status !== 200) return fail("3. Last-executive guard", `B promoting A back failed: ${r7.status}`);

  return pass("3. Last-executive guard", "blocked demote/remove of last exec, then succeeded after 2nd exec promoted");
}

// ---------------- Check 4: regenerate code invalidates old credentials ----------------
const CLUB_CODES = {}; // clubId -> {code, password}

async function check4_regenerateCodeInvalidates(jar, clubId, initialCode, initialPassword) {
  // Regenerate
  const r = await req(jar, "POST", `/api/clubs/${clubId}/regenerate`);
  if (r.status !== 200) return fail("4. Regenerate code invalidates old", `regenerate returned ${r.status}`);
  const d = await r.json();
  const newCode = d.clubCode;
  if (!newCode) return fail("4. Regenerate code invalidates old", "no clubCode returned");

  // Attempt to join with OLD code via a separate non-member user
  // Use a brand-new user (signed up + logged in below) to avoid membership state confusion
  const thirdEmail = `${RUN_PREFIX}-c@verify.test`;
  const thirdPassword = "Password123!";
  await signup(thirdEmail, thirdPassword, "Verify C");
  const { jar: jarC, user: userC } = await login(thirdEmail, thirdPassword);
  CLEANUP.users.push(userC.id);

  // Try OLD code → expect 404
  const rOld = await req(jarC, "POST", "/api/clubs/join", {
    body: { clubCode: initialCode, clubPassword: initialPassword },
  });
  if (rOld.status !== 404) return fail("4. Regenerate code invalidates old", `expected 404 with old code, got ${rOld.status}`);
  const jOld = await jsonOrText(rOld);
  if (!String(jOld?.error || "").toLowerCase().includes("no club found")) {
    return fail("4. Regenerate code invalidates old", `old-code error message mismatch: ${JSON.stringify(jOld)}`);
  }
  // Try NEW code → expect 200
  const rNew = await req(jarC, "POST", "/api/clubs/join", {
    body: { clubCode: newCode, clubPassword: initialPassword },
  });
  if (rNew.status !== 200) return fail("4. Regenerate code invalidates old", `expected 200 with new code, got ${rNew.status}`);

  CLUB_CODES[clubId] = { code: newCode, password: initialPassword };
  return pass("4. Regenerate code invalidates old", `old code → 404, new code (${newCode}) → 200`);
}

// ---------------- Check 5: bulk approve/reject ----------------
async function check5_bulkReview(jarExec, clubId, submitterJar) {
  const ids = [];
  for (let i = 0; i < 3; i++) {
    const r = await req(submitterJar, "POST", `/api/clubs/${clubId}/hours`, {
      body: {
        dateOfService: new Date(Date.now() - (i + 1) * 86400000).toISOString(),
        hours: 1.5 + i * 0.5,
        reasonText: `verify check5 entry ${i}`,
      },
    });
    if (r.status !== 201) return fail("5. Bulk approve/reject", `submit #${i} returned ${r.status}`);
    const d = await r.json();
    ids.push(d.entry.id);
  }
  const r = await req(jarExec, "POST", `/api/clubs/${clubId}/hours/bulk-review`, {
    body: { hourIds: ids, status: "approved", reviewComment: "bulk ok" },
  });
  if (r.status !== 200) return fail("5. Bulk approve/reject", `bulk-review returned ${r.status}`);
  const d = await r.json();
  if (d.reviewed !== 3) return fail("5. Bulk approve/reject", `expected reviewed=3, got ${d.reviewed}`);
  // Verify all 3 transitioned to approved via GET scope=all
  const g = await req(jarExec, "GET", `/api/clubs/${clubId}/hours?scope=all&status=approved`);
  const gj = await g.json();
  const approvedIds = new Set(gj.items.map((x) => x.id));
  for (const id of ids) {
    if (!approvedIds.has(id)) return fail("5. Bulk approve/reject", `entry ${id} not in approved list`);
  }
  return pass("5. Bulk approve/reject", `3 entries submitted, 3 approved in one bulk call`);
}

// ---------------- Check 6: ICS export ----------------
async function check6_icsExport(jar, clubId) {
  // Create a non-recurring meeting (start in 2 days)
  const start = new Date(Date.now() + 2 * 86400000);
  start.setMinutes(0, 0, 0);
  const end = new Date(start.getTime() + 90 * 60 * 1000);
  const r1 = await req(jar, "POST", `/api/clubs/${clubId}/meetings`, {
    body: {
      title: "Verify Standup, Inc. (with, comma)",
      description: "Line one\nLine two; semi",
      location: "Room 1, Building A",
      startTime: start.toISOString(),
      endTime: end.toISOString(),
    },
  });
  if (r1.status !== 201) return fail("6. ICS export", `non-recurring create returned ${r1.status}`);
  // Create a recurring weekly meeting
  const start2 = new Date(Date.now() + 3 * 86400000);
  start2.setMinutes(0, 0, 0);
  const end2 = new Date(start2.getTime() + 60 * 60 * 1000);
  const r2 = await req(jar, "POST", `/api/clubs/${clubId}/meetings`, {
    body: {
      title: "Weekly Sync",
      description: "Recurring weekly",
      location: "Zoom",
      startTime: start2.toISOString(),
      endTime: end2.toISOString(),
      isRecurring: true,
      recurrenceRule: "weekly",
    },
  });
  if (r2.status !== 201) return fail("6. ICS export", `recurring create returned ${r2.status}`);

  const r = await req(jar, "GET", `/api/clubs/${clubId}/meetings/ics`);
  if (r.status !== 200) return fail("6. ICS export", `ICS GET returned ${r.status}`);
  const text = await r.text();

  // Header checks
  const header = text.slice(0, 200);
  if (!text.startsWith("BEGIN:VCALENDAR")) return fail("6. ICS export", "does not start with BEGIN:VCALENDAR");
  if (!text.includes("VERSION:2.0")) return fail("6. ICS export", "missing VERSION:2.0");
  if (!text.includes("PRODID:")) return fail("6. ICS export", "missing PRODID");

  // Count VEVENTs
  const vevents = text.split("BEGIN:VEVENT").length - 1;
  if (vevents < 2) return fail("6. ICS export", `expected ≥2 VEVENTs, got ${vevents}`);

  // Validate each VEVENT has required props
  const events = text.split("BEGIN:VEVENT").slice(1).map((s) => s.split("END:VEVENT")[0]);
  for (let i = 0; i < events.length; i++) {
    const e = events[i];
    const required = ["UID:", "DTSTAMP:", "DTSTART:", "DTEND:", "SUMMARY:", "LOCATION:"];
    for (const key of required) {
      if (!e.includes(key)) return fail("6. ICS export", `VEVENT #${i + 1} missing ${key}`);
    }
  }
  // CRLF line endings — every \n must be preceded by \r (no bare LF).
  const lfCount = (text.match(/\n/g) || []).length;
  const crlfCount = (text.match(/\r\n/g) || []).length;
  if (lfCount !== crlfCount) {
    return fail("6. ICS export", `mixed line endings: ${lfCount} LF vs ${crlfCount} CRLF`);
  }
  // Escape commas/semicolons/newlines in text fields
  // The non-recurring title had a comma → expect SUMMARY:Verify Standup\, Inc. (with\, comma)
  if (!text.includes("SUMMARY:Verify Standup\\, Inc. (with\\, comma)")) {
    return fail("6. ICS export", "comma in SUMMARY not escaped");
  }
  if (!text.includes("LOCATION:Room 1\\, Building A")) {
    return fail("6. ICS export", "comma in LOCATION not escaped");
  }
  // Print first ~20 lines
  const first20 = text.split("\r\n").slice(0, 20).join("\r\n");
  console.log("    ---- ICS first 20 lines ----");
  console.log(first20.split("\r\n").map((l) => "    " + l).join("\n"));

  return pass("6. ICS export", `${vevents} VEVENTs, RFC-5545 basics OK (CRLF + escaped commas)`);
}

// ---------------- Check 7: soft-delete recoverable ----------------
async function check7_softDeleteRecoverable(jarExec, clubId) {
  // (a) Comment soft-delete → "[comment removed]"
  const annRes = await req(jarExec, "POST", `/api/clubs/${clubId}/announcements`, {
    body: { title: "Verify Ann", body: "verify body" },
  });
  if (annRes.status !== 201) return fail("7. Soft-delete recoverable", `announcement create returned ${annRes.status}`);
  const ann = (await annRes.json()).item;

  const cRes = await req(jarExec, "POST", `/api/clubs/${clubId}/announcements/${ann.id}/comments`, {
    body: { body: "verify comment" },
  });
  if (cRes.status !== 201) return fail("7. Soft-delete recoverable", `comment create returned ${cRes.status}`);
  const comment = (await cRes.json()).item;

  const delRes = await req(jarExec, "DELETE", `/api/clubs/${clubId}/announcements/${ann.id}/comments/${comment.id}`);
  if (delRes.status !== 200) return fail("7. Soft-delete recoverable", `comment delete returned ${delRes.status}`);

  const listRes = await req(jarExec, "GET", `/api/clubs/${clubId}/announcements/${ann.id}/comments`);
  const listJson = await listRes.json();
  const found = listJson.items.find((x) => x.id === comment.id);
  if (!found) return fail("7. Soft-delete recoverable", "soft-deleted comment not returned in GET");
  if (!found.deleted) return fail("7. Soft-delete recoverable", `soft-deleted comment missing deleted:true (got ${JSON.stringify(found)})`);

  // (b) Announcement soft-delete → invisible by default, visible with ?includeDeleted=true for execs
  const ann2Res = await req(jarExec, "POST", `/api/clubs/${clubId}/announcements`, {
    body: { title: "Verify Ann 2", body: "verify body 2" },
  });
  const ann2 = (await ann2Res.json()).item;
  const delAnn = await req(jarExec, "DELETE", `/api/clubs/${clubId}/announcements/${ann2.id}`);
  if (delAnn.status !== 200) return fail("7. Soft-delete recoverable", `announcement delete returned ${delAnn.status}`);

  const listNoFlag = await req(jarExec, "GET", `/api/clubs/${clubId}/announcements`);
  const listNoFlagJson = await listNoFlag.json();
  if (listNoFlagJson.items.some((x) => x.id === ann2.id)) {
    return fail("7. Soft-delete recoverable", "soft-deleted announcement visible in default GET");
  }

  const listWithFlag = await req(jarExec, "GET", `/api/clubs/${clubId}/announcements?includeDeleted=true`);
  const listWithFlagJson = await listWithFlag.json();
  if (!listWithFlagJson.items.some((x) => x.id === ann2.id)) {
    return fail("7. Soft-delete recoverable", `soft-deleted announcement NOT visible with ?includeDeleted=true (status ${listWithFlag.status})`);
  }

  // Restore announcement
  const restoreAnn = await req(jarExec, "POST", `/api/clubs/${clubId}/announcements/${ann2.id}/restore`);
  if (restoreAnn.status !== 200) return fail("7. Soft-delete recoverable", `announcement restore endpoint returned ${restoreAnn.status}`);

  const listAfterRestore = await req(jarExec, "GET", `/api/clubs/${clubId}/announcements`);
  const listAfterRestoreJson = await listAfterRestore.json();
  if (!listAfterRestoreJson.items.some((x) => x.id === ann2.id)) {
    return fail("7. Soft-delete recoverable", "announcement NOT visible after restore");
  }

  // (c) Task soft-delete + restore
  const tRes = await req(jarExec, "POST", `/api/clubs/${clubId}/tasks`, {
    body: { title: "Verify Task" },
  });
  if (tRes.status !== 201) return fail("7. Soft-delete recoverable", `task create returned ${tRes.status}`);
  const task = (await tRes.json()).task;

  const dtRes = await req(jarExec, "DELETE", `/api/clubs/${clubId}/tasks/${task.id}`);
  if (dtRes.status !== 200) return fail("7. Soft-delete recoverable", `task delete returned ${dtRes.status}`);

  const tasksNoFlag = await req(jarExec, "GET", `/api/clubs/${clubId}/tasks`);
  const tasksNoFlagJson = await tasksNoFlag.json();
  if (tasksNoFlagJson.tasks.some((x) => x.id === task.id)) {
    return fail("7. Soft-delete recoverable", "soft-deleted task visible in default GET");
  }
  const tasksWithFlag = await req(jarExec, "GET", `/api/clubs/${clubId}/tasks?includeDeleted=true`);
  const tasksWithFlagJson = await tasksWithFlag.json();
  if (!tasksWithFlagJson.tasks.some((x) => x.id === task.id)) {
    return fail("7. Soft-delete recoverable", `soft-deleted task NOT visible with ?includeDeleted=true`);
  }
  const restoreTask = await req(jarExec, "POST", `/api/clubs/${clubId}/tasks/${task.id}/restore`);
  if (restoreTask.status !== 200) return fail("7. Soft-delete recoverable", `task restore endpoint returned ${restoreTask.status}`);

  const tasksAfterRestore = await req(jarExec, "GET", `/api/clubs/${clubId}/tasks`);
  const tasksAfterRestoreJson = await tasksAfterRestore.json();
  if (!tasksAfterRestoreJson.tasks.some((x) => x.id === task.id)) {
    return fail("7. Soft-delete recoverable", "task NOT visible after restore");
  }

  return pass("7. Soft-delete recoverable", "comment deleted:true; announcement & task hidden by default, restored via restore endpoint + visible with includeDeleted=true");
}

// ---------------- Check 8: multi-club scoping ----------------
async function check8_multiClubScoping(jarA, clubX, clubY) {
  // Create an announcement in X only → GET /announcements for Y must be empty
  const axRes = await req(jarA, "POST", `/api/clubs/${clubX}/announcements`, {
    body: { title: "X-only ann", body: "x" },
  });
  if (axRes.status !== 201) return fail("8. Multi-club scoping", `announcement create in X returned ${axRes.status}`);
  const yList = await req(jarA, "GET", `/api/clubs/${clubY}/announcements`);
  const yListJson = await yList.json();
  if (yListJson.items.length !== 0) {
    return fail("8. Multi-club scoping", `Y announcements leak X data (${yListJson.items.length} items)`);
  }

  // Create a task in X only → GET /tasks for Y must be empty
  const txRes = await req(jarA, "POST", `/api/clubs/${clubX}/tasks`, {
    body: { title: "X-only task" },
  });
  if (txRes.status !== 201) return fail("8. Multi-club scoping", `task create in X returned ${txRes.status}`);
  const yTasks = await req(jarA, "GET", `/api/clubs/${clubY}/tasks`);
  const yTasksJson = await yTasks.json();
  if (yTasksJson.tasks.length !== 0) {
    return fail("8. Multi-club scoping", `Y tasks leak X data (${yTasksJson.tasks.length} items)`);
  }

  // Submit hours in X → GET /hours?scope=all for Y (A is exec) must be empty
  const hxRes = await req(jarA, "POST", `/api/clubs/${clubX}/hours`, {
    body: {
      dateOfService: new Date(Date.now() - 86400000).toISOString(),
      hours: 3,
      reasonText: "verify check8 X-only hours",
    },
  });
  if (hxRes.status !== 201) return fail("8. Multi-club scoping", `hours submit in X returned ${hxRes.status}`);
  const yHours = await req(jarA, "GET", `/api/clubs/${clubY}/hours?scope=all`);
  const yHoursJson = await yHours.json();
  const yLeak = yHoursJson.items.some((x) => x.userId === USER_A_ID);
  if (yLeak) {
    return fail("8. Multi-club scoping", `Y hours leak X submission: ${JSON.stringify(yHoursJson.items.map((x) => x.id))}`);
  }

  // X hours must contain the submitted entry
  const xHours = await req(jarA, "GET", `/api/clubs/${clubX}/hours?scope=all`);
  const xHoursJson = await xHours.json();
  if (!xHoursJson.items.some((x) => x.userId === USER_A_ID)) {
    return fail("8. Multi-club scoping", "X hours missing the X submission");
  }

  return pass("8. Multi-club scoping", "announcements/tasks/hours strictly scoped by clubId — no leakage");
}

// ---------------- Main ----------------
let USER_A_ID, USER_B_ID;

async function main() {
  console.log(`\n=== Verification run ${RUN_PREFIX} ===\n`);

  // Sign up two users
  const emailA = `${RUN_PREFIX}-a@verify.test`;
  const emailB = `${RUN_PREFIX}-b@verify.test`;
  const password = "Password123!";
  const signupA = await signup(emailA, password, "Verify A");
  const signupB = await signup(emailB, password, "Verify B");
  CLEANUP.users.push(signupA.userId, signupB.userId);

  const { jar: jarA, user: userA } = await login(emailA, password);
  const { jar: jarB, user: userB } = await login(emailB, password);
  USER_A_ID = userA.id;
  USER_B_ID = userB.id;

  // Create club X (A is exec) — for checks 1, 2, 3, 4, 5, 6, 7
  const clubPassword = "club-pass-1234";
  const cX = await req(jarA, "POST", "/api/clubs", {
    body: { name: `${RUN_PREFIX} Club X`, description: "verify", accentColor: "#16a34a", clubPassword },
  });
  const cXj = await cX.json();
  const clubXId = cXj.club.id;
  CLUB_CODES[clubXId] = { code: cXj.club.clubCode, password: clubPassword };
  CLEANUP.clubs.push(clubXId);

  // Create club Y (A is exec) — for check 8
  const cY = await req(jarA, "POST", "/api/clubs", {
    body: { name: `${RUN_PREFIX} Club Y`, description: "verify", accentColor: "#db2777", clubPassword },
  });
  const cYj = await cY.json();
  const clubYId = cYj.club.id;
  CLUB_CODES[clubYId] = { code: cYj.club.clubCode, password: clubPassword };
  CLEANUP.clubs.push(clubYId);

  // Run checks (1-7 use clubX, 8 uses both X & Y)
  await check1_imageCompression(jarA, clubXId);
  await check2_proofDeletedOnApproveAndReject(jarA, clubXId, jarA, userA.id);
  await check3_lastExecutiveGuard(jarA, clubXId, userA.id, jarB, userB.id);
  await check4_regenerateCodeInvalidates(jarA, clubXId, cXj.club.clubCode, clubPassword);
  await check5_bulkReview(jarA, clubXId, jarA); // A is exec AND submitter (fine for this check)
  await check6_icsExport(jarA, clubXId);
  await check7_softDeleteRecoverable(jarA, clubXId);
  await check8_multiClubScoping(jarA, clubXId, clubYId);

  // Print summary table
  console.log("\n=== Summary ===");
  for (const r of results) {
    console.log(`${r.ok ? "✓" : "✗"} ${r.name}${r.ok ? (r.detail ? " — " + r.detail : "") : " — " + r.reason}`);
  }
  const ok = results.filter((r) => r.ok).length;
  console.log(`\n${ok}/${results.length} checks passed`);
}

main()
  .catch((e) => {
    console.error("verify.mjs crashed:", e);
    process.exitCode = 1;
  })
  .finally(async () => {
    // Cleanup test artifacts
    console.log("\n--- cleanup ---");
    await cleanup(CLEANUP.clubs, CLEANUP.users, CLEANUP.files);
    // Also remove any orphan directories under public/uploads/clubs/<clubId>
    for (const cid of CLEANUP.clubs) {
      await fs.rm(path.join(process.cwd(), "public", "uploads", "clubs", cid), { recursive: true, force: true }).catch(() => {});
    }
    console.log("cleanup done");
  });
