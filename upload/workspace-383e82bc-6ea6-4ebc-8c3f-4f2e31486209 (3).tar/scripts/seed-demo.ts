/**
 * Demo data seed script.
 * Run with: bun scripts/seed-demo.ts
 *
 * Creates two demo accounts + a fully-populated demo club so you can explore
 * every feature without manual setup. Safe to re-run (idempotent — cleans up
 * existing demo data first).
 */
import { db } from "../src/lib/db"
import { hashPassword } from "../src/lib/auth"
import { encryptClubPassword } from "../src/lib/club-crypto"

const DEMO_EXEC_EMAIL = "exec@demo.clubhub.test"
const DEMO_MEMBER_EMAIL = "member@demo.clubhub.test"
const DEMO_PASSWORD = "demo1234"
const DEMO_ACCENT = "#a855f7" // violet

async function main() {
  console.log("Seeding demo data…")

  // Clean up any previous demo data (idempotent re-runs)
  const existingClub = await db.club.findFirst({ where: { name: "Robotics Society (Demo)" } })
  if (existingClub) {
    console.log("Removing previous demo club…")
    await db.notification.deleteMany({ where: { clubId: existingClub.id } })
    await db.activityLog.deleteMany({ where: { clubId: existingClub.id } })
    await db.messageReaction.deleteMany({ where: { message: { conversation: { clubId: existingClub.id } } } })
    await db.message.deleteMany({ where: { conversation: { clubId: existingClub.id } } })
    await db.conversationMember.deleteMany({ where: { conversation: { clubId: existingClub.id } } })
    await db.conversation.deleteMany({ where: { clubId: existingClub.id } })
    await db.taskComment.deleteMany({ where: { task: { clubId: existingClub.id } } })
    await db.subtask.deleteMany({ where: { task: { clubId: existingClub.id } } })
    await db.task.deleteMany({ where: { clubId: existingClub.id } })
    await db.meetingRsvp.deleteMany({ where: { meeting: { clubId: existingClub.id } } })
    await db.meeting.deleteMany({ where: { clubId: existingClub.id } })
    await db.serviceHour.deleteMany({ where: { clubId: existingClub.id } })
    await db.serviceCategory.deleteMany({ where: { clubId: existingClub.id } })
    await db.teamMember.deleteMany({ where: { team: { clubId: existingClub.id } } })
    await db.team.deleteMany({ where: { clubId: existingClub.id } })
    await db.announcementComment.deleteMany({ where: { announcement: { clubId: existingClub.id } } })
    await db.announcementReaction.deleteMany({ where: { announcement: { clubId: existingClub.id } } })
    await db.announcement.deleteMany({ where: { clubId: existingClub.id } })
    await db.clubMember.deleteMany({ where: { clubId: existingClub.id } })
    await db.club.delete({ where: { id: existingClub.id } })
  }
  for (const email of [DEMO_EXEC_EMAIL, DEMO_MEMBER_EMAIL]) {
    const u = await db.user.findUnique({ where: { email } })
    if (u) await db.user.delete({ where: { id: u.id } })
  }

  // --- Users ---
  const pwHash = await hashPassword(DEMO_PASSWORD)
  const exec = await db.user.create({
    data: { name: "Alex Chen (Exec)", email: DEMO_EXEC_EMAIL, passwordHash: pwHash, bio: "Club president and robotics mentor.", emailVerified: true },
  })
  const member = await db.user.create({
    data: { name: "Sam Rivera", email: DEMO_MEMBER_EMAIL, passwordHash: pwHash, bio: "First-year member, loves CAD.", emailVerified: true },
  })
  // A few extra members to make the directory + leaderboard feel real
  const extras = await Promise.all([
    db.user.create({ data: { name: "Jordan Lee", email: "jordan@demo.clubhub.test", passwordHash: pwHash, emailVerified: true } }),
    db.user.create({ data: { name: "Priya Patel", email: "priya@demo.clubhub.test", passwordHash: pwHash, emailVerified: true } }),
    db.user.create({ data: { name: "Marcus Kim", email: "marcus@demo.clubhub.test", passwordHash: pwHash, emailVerified: true } }),
    db.user.create({ data: { name: "Lia Wong", email: "lia@demo.clubhub.test", passwordHash: pwHash, emailVerified: true } }),
  ])

  // --- Club ---
  const club = await db.club.create({
    data: {
      name: "Robotics Society (Demo)",
      description: "Building robots, competing in FIRST, and growing future engineers.",
      accentColor: DEMO_ACCENT,
      clubCode: "ROBO42",
      clubPasswordEnc: encryptClubPassword("robo2026"),
      hoursGoal: 20,
      createdBy: exec.id,
      members: {
        create: [
          { userId: exec.id, role: "executive" },
          { userId: member.id, role: "member" },
          ...extras.map((u) => ({ userId: u.id, role: "member" as const })),
        ],
      },
    },
  })
  console.log(`Created club "${club.name}" (code: ${club.clubCode})`)

  // --- Service categories ---
  const catBuild = await db.serviceCategory.create({ data: { clubId: club.id, name: "Build Sessions" } })
  const catOut = await db.serviceCategory.create({ data: { clubId: club.id, name: "Outreach" } })
  const catFund = await db.serviceCategory.create({ data: { clubId: club.id, name: "Fundraising" } })

  // --- Service hours (approved + pending) ---
  const now = new Date()
  const daysAgo = (n: number) => new Date(now.getTime() - n * 86400000)
  await db.serviceHour.createMany({
    data: [
      { clubId: club.id, userId: member.id, categoryId: catBuild.id, dateOfService: daysAgo(20), hours: 4, reasonText: "Assembled chassis frame and wired drive motors.", status: "approved", reviewedBy: exec.id, reviewComment: "Great work!", submittedAt: daysAgo(20), reviewedAt: daysAgo(19) },
      { clubId: club.id, userId: member.id, categoryId: catBuild.id, dateOfService: daysAgo(15), hours: 3, reasonText: "CAD modeling of the arm mechanism.", status: "approved", reviewedBy: exec.id, submittedAt: daysAgo(15), reviewedAt: daysAgo(14) },
      { clubId: club.id, userId: member.id, categoryId: catOut.id, dateOfService: daysAgo(10), hours: 5, reasonText: "Mentored middle-school robotics club.", status: "approved", reviewedBy: exec.id, submittedAt: daysAgo(10), reviewedAt: daysAgo(9) },
      { clubId: club.id, userId: member.id, categoryId: catFund.id, dateOfService: daysAgo(2), hours: 2, reasonText: "Bake sale fundraiser for competition travel.", status: "pending", submittedAt: daysAgo(2) },
      { clubId: club.id, userId: extras[0].id, categoryId: catBuild.id, dateOfService: daysAgo(18), hours: 6, reasonText: "Wired and tested the control board.", status: "approved", reviewedBy: exec.id, submittedAt: daysAgo(18), reviewedAt: daysAgo(17) },
      { clubId: club.id, userId: extras[1].id, categoryId: catOut.id, dateOfService: daysAgo(12), hours: 4, reasonText: "Demo day at the local library.", status: "approved", reviewedBy: exec.id, submittedAt: daysAgo(12), reviewedAt: daysAgo(11) },
      { clubId: club.id, userId: extras[2].id, categoryId: catBuild.id, dateOfService: daysAgo(3), hours: 3, reasonText: "Programming autonomous pathing.", status: "pending", submittedAt: daysAgo(3) },
    ],
  })

  // --- Announcements ---
  const ann1 = await db.announcement.create({ data: { clubId: club.id, authorId: exec.id, title: "Welcome to the new season! 🤖", body: "Hey everyone, our first build session kicks off this Saturday at 10am in Lab 204. Bring your safety glasses and a notebook. Excited to build with all of you this year!", isPinned: true, createdAt: daysAgo(21) } })
  const ann2 = await db.announcement.create({ data: { clubId: club.id, authorId: exec.id, title: "Regional competition date confirmed", body: "We've been registered for the Pacific Regional on March 15-16. Start thinking about travel logistics — we'll coordinate carpools at the next meeting.", isPinned: false, createdAt: daysAgo(7) } })
  const ann3 = await db.announcement.create({ data: { clubId: club.id, authorId: exec.id, title: "Fundraiser recap — thank you!", body: "The bake sale raised $340 for travel. Huge thanks to everyone who baked, tabled, and bought treats. Special shoutout to Sam for organizing.", isPinned: false, createdAt: daysAgo(1) } })
  // reactions + a comment
  await db.announcementReaction.create({ data: { announcementId: ann1.id, userId: member.id, emoji: "🎉" } })
  await db.announcementReaction.create({ data: { announcementId: ann1.id, userId: extras[0].id, emoji: "👍" } })
  await db.announcementReaction.create({ data: { announcementId: ann1.id, userId: extras[1].id, emoji: "❤️" } })
  await db.announcementReaction.create({ data: { announcementId: ann3.id, userId: member.id, emoji: "👏" } })
  await db.announcementComment.create({ data: { announcementId: ann1.id, authorId: member.id, body: "So excited! Will be there early.", createdAt: daysAgo(20) } })
  await db.announcementComment.create({ data: { announcementId: ann2.id, authorId: extras[1].id, body: "I can drive 3 people from the north side.", createdAt: daysAgo(6) } })

  // --- Teams ---
  const teamBuild = await db.team.create({ data: { clubId: club.id, name: "Build Team", description: "Chassis, arm, and mechanism fabrication." } })
  const teamCode = await db.team.create({ data: { clubId: club.id, name: "Programming Team", description: "Autonomous + driver control code." } })
  const teamBiz = await db.team.create({ data: { clubId: club.id, name: "Business & Outreach", description: "Fundraising, demos, community." } })
  await db.teamMember.createMany({ data: [
    { teamId: teamBuild.id, userId: member.id }, { teamId: teamBuild.id, userId: extras[0].id }, { teamId: teamBuild.id, userId: extras[2].id },
    { teamId: teamCode.id, userId: extras[2].id }, { teamId: teamCode.id, userId: extras[3].id },
    { teamId: teamBiz.id, userId: extras[1].id }, { teamId: teamBiz.id, userId: member.id },
  ]})

  // --- Tasks ---
  const task1 = await db.task.create({ data: { clubId: club.id, teamId: teamBuild.id, title: "Finalize chassis CAD", description: "Lock the frame dimensions and order stock.", assignedToUserId: member.id, dueDate: daysAgo(-3), status: "in_progress", createdById: exec.id } })
  await db.subtask.createMany({ data: [
    { taskId: task1.id, title: "Measure wheelbase constraints", isDone: true },
    { taskId: task1.id, title: "Order aluminum stock", isDone: true },
    { taskId: task1.id, title: "Export final drawings", isDone: false },
  ]})
  await db.task.create({ data: { clubId: club.id, teamId: teamCode.id, title: "Implement autonomous pathing", description: "Path-following PID for the sandstorm period.", assignedToUserId: extras[2].id, dueDate: daysAgo(-7), status: "not_started", createdById: exec.id } })
  await db.task.create({ data: { clubId: club.id, teamId: teamBiz.id, title: "Draft sponsorship letter", description: "Reach out to 5 local businesses.", assignedToUserId: extras[1].id, dueDate: daysAgo(2), status: "done", createdById: exec.id } })
  await db.task.create({ data: { clubId: club.id, title: "Update club website", description: "Refresh the roster page.", assignedToUserId: extras[3].id, dueDate: daysAgo(-14), status: "in_progress", createdById: exec.id } })
  await db.task.create({ data: { clubId: club.id, title: "Inventory the parts bin", description: "Sort and label all hardware.", dueDate: daysAgo(-5), status: "not_started", createdById: exec.id } })

  // --- Meetings ---
  const inDays = (n: number) => new Date(now.getTime() + n * 86400000)
  await db.meeting.create({ data: { clubId: club.id, title: "Weekly Build Session", location: "Lab 204", startTime: inDays(2), endTime: inDays(2), isRecurring: true, recurrenceRule: "weekly", createdById: exec.id } })
  await db.meeting.create({ data: { clubId: club.id, title: "Strategy Review", location: "Zoom", startTime: inDays(5), endTime: inDays(5), isRecurring: false, createdById: exec.id } })
  await db.meeting.create({ data: { clubId: club.id, title: "Outreach Demo @ Library", location: "Central Library", startTime: inDays(9), endTime: inDays(9), isRecurring: false, createdById: exec.id } })
  await db.meeting.create({ data: { clubId: club.id, title: "Pre-competition Briefing", location: "Lab 204", startTime: inDays(14), endTime: inDays(14), isRecurring: false, createdById: exec.id } })

  // --- Chat (club-wide conversation auto-bootstrapped) ---
  const conv = await db.conversation.create({ data: { clubId: club.id, type: "club_wide", name: club.name, createdBy: exec.id } })
  await db.conversationMember.createMany({ data: [
    { conversationId: conv.id, userId: exec.id, role: "owner" },
    { conversationId: conv.id, userId: member.id },
    ...extras.map((u) => ({ conversationId: conv.id, userId: u.id })),
  ]})
  await db.message.createMany({ data: [
    { conversationId: conv.id, authorId: exec.id, body: "Hey team — welcome to the chat! Use this for quick coordination.", createdAt: daysAgo(21) },
    { conversationId: conv.id, authorId: member.id, body: "Awesome, thanks for setting this up!", createdAt: daysAgo(21) },
    { conversationId: conv.id, authorId: extras[0].id, body: "Build team — I'll bring the spare batteries Saturday.", createdAt: daysAgo(2) },
    { conversationId: conv.id, authorId: member.id, body: "Pinned the parts list to the shared folder.", createdAt: daysAgo(1), pinnedAt: daysAgo(1) },
    { conversationId: conv.id, authorId: extras[1].id, body: "Anyone free to help with the sponsorship letters tonight?", createdAt: daysAgo(0) },
  ]})
  await db.messageReaction.create({ data: { messageId: (await db.message.findFirst({ where: { conversationId: conv.id, authorId: exec.id } }))!.id, userId: member.id, emoji: "👍" } })

  // --- Activity log ---
  await db.activityLog.createMany({ data: [
    { clubId: club.id, actorUserId: exec.id, actionType: "club_created", targetType: "club", targetId: club.id, description: "Alex Chen (Exec) created the club", createdAt: daysAgo(21) },
    { clubId: club.id, actorUserId: exec.id, actionType: "new_announcement", targetType: "announcement", description: "Alex Chen (Exec) posted \"Welcome to the new season!\"", createdAt: daysAgo(21) },
    { clubId: club.id, actorUserId: exec.id, actionType: "team_created", targetType: "team", description: "Alex Chen (Exec) created Build Team", createdAt: daysAgo(20) },
    { clubId: club.id, actorUserId: exec.id, actionType: "hours_approved", targetType: "service_hour", description: "Alex Chen (Exec) approved 4 hours for Sam Rivera", createdAt: daysAgo(19) },
    { clubId: club.id, actorUserId: exec.id, actionType: "new_member", targetType: "user", targetId: extras[0].id, description: "Jordan Lee joined the club", createdAt: daysAgo(18) },
    { clubId: club.id, actorUserId: exec.id, actionType: "new_announcement", targetType: "announcement", description: "Alex Chen (Exec) posted \"Fundraiser recap\"", createdAt: daysAgo(1) },
  ]})

  console.log("\n✅ Demo data seeded successfully!")
  console.log("\n📋 Demo accounts (password for both: demo1234):")
  console.log(`   Executive: ${DEMO_EXEC_EMAIL}`)
  console.log(`   Member:    ${DEMO_MEMBER_EMAIL}`)
  console.log(`\n🤖 Demo club: "${club.name}" (code: ${club.clubCode}, join pw: robo2026)`)
  console.log(`   ${extras.length + 2} members, ${3} teams, ${5} tasks, ${4} meetings, ${3} announcements, ${7} service hours, chat with messages\n`)
}

main()
  .catch((e) => { console.error("Seed failed:", e); process.exit(1) })
  .finally(async () => { await db.$disconnect() })
