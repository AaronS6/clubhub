// tests/executive-guard.test.ts
//
// Tests the last-executive guard in PATCH /api/clubs/[clubId]/members:
//   1. Cannot demote the last executive (400 with "last executive" message).
//   2. Cannot remove the last executive (400 with "last executive" message).
//   3. After promoting a second executive, the first can be demoted and removed.
//
// Test approach: fetch against the running dev server; clean up via afterAll.

import { describe, it, expect, beforeAll, afterAll } from "bun:test"
import { db } from "@/lib/db"
import {
  signup, login, createClub, req, jsonOrText,
  RUN_PREFIX, cleanupAll,
} from "./setup"

const execEmail = `${RUN_PREFIX}-exec@verify.test`
const memberEmail = `${RUN_PREFIX}-member@verify.test`
const password = "Password123!"
const clubPassword = "club-pass-1234"

let execJar: any
let execUser: any
let memberJar: any
let memberUser: any
let club: { id: string; name: string; clubCode: string; accentColor: string; role: string }

beforeAll(async () => {
  await signup(execEmail, password, "Exec")
  await signup(memberEmail, password, "Member")
  ;({ jar: execJar, user: execUser } = await login(execEmail, password))
  ;({ jar: memberJar, user: memberUser } = await login(memberEmail, password))
  club = await createClub(execJar, `${RUN_PREFIX} Guard Club`, clubPassword)
  await req(memberJar, "POST", "/api/clubs/join", {
    body: { clubCode: club.clubCode, clubPassword: clubPassword },
  })
})

afterAll(async () => {
  await cleanupAll()
  await db.$disconnect()
})

describe("Last-executive guard", () => {
  it("blocks demoting the last executive with 400 + 'last executive' message", async () => {
    const r = await req(execJar, "PATCH", `/api/clubs/${club.id}/members`, {
      body: { action: "demote", userId: execUser.id },
    })
    expect(r.status, `expected 400 for demote-last-exec, got ${r.status}`).toBe(400)
    const j = await jsonOrText(r)
    expect(String(j?.error || "").toLowerCase(), `error should mention 'last executive': ${JSON.stringify(j)}`).toContain("last executive")

    // Confirm exec is still executive
    const m = await db.clubMember.findUnique({
      where: { clubId_userId: { clubId: club.id, userId: execUser.id } },
    })
    expect(m!.role, "role must remain 'executive' after blocked demote").toBe("executive")
  })

  it("blocks removing the last executive with 400 + 'last executive' message", async () => {
    const r = await req(execJar, "PATCH", `/api/clubs/${club.id}/members`, {
      body: { action: "remove", userId: execUser.id },
    })
    expect(r.status, `expected 400 for remove-last-exec, got ${r.status}`).toBe(400)
    const j = await jsonOrText(r)
    expect(String(j?.error || "").toLowerCase(), `error should mention 'last executive': ${JSON.stringify(j)}`).toContain("last executive")

    const m = await db.clubMember.findUnique({
      where: { clubId_userId: { clubId: club.id, userId: execUser.id } },
    })
    expect(m!.status, "status must remain 'active' after blocked remove").toBe("active")
  })

  it("after promoting a second executive, the first can be demoted", async () => {
    // Promote member to executive
    const promote = await req(execJar, "PATCH", `/api/clubs/${club.id}/members`, {
      body: { action: "promote", userId: memberUser.id },
    })
    expect(promote.status, `promote member failed: ${promote.status}`).toBe(200)

    // Now demote the originally-sole exec → should succeed
    const demote = await req(execJar, "PATCH", `/api/clubs/${club.id}/members`, {
      body: { action: "demote", userId: execUser.id },
    })
    expect(demote.status, `expected 200 for demote-after-second-exec, got ${demote.status}`).toBe(200)

    // Confirm exec is now 'member'
    const m = await db.clubMember.findUnique({
      where: { clubId_userId: { clubId: club.id, userId: execUser.id } },
    })
    expect(m!.role, "exec's role should now be 'member'").toBe("member")
  })

  it("after promoting a second executive, the first can be removed", async () => {
    // Re-promote exec (we demoted in the previous test)
    const promote = await req(memberJar, "PATCH", `/api/clubs/${club.id}/members`, {
      body: { action: "promote", userId: execUser.id },
    })
    expect(promote.status, `re-promote exec failed: ${promote.status}`).toBe(200)

    // Now remove the originally-sole exec → should succeed (memberUser is exec)
    const remove = await req(memberJar, "PATCH", `/api/clubs/${club.id}/members`, {
      body: { action: "remove", userId: execUser.id },
    })
    expect(remove.status, `expected 200 for remove-after-second-exec, got ${remove.status}`).toBe(200)

    // Confirm exec is now 'removed'
    const m = await db.clubMember.findUnique({
      where: { clubId_userId: { clubId: club.id, userId: execUser.id } },
    })
    expect(m!.status, "exec's status should now be 'removed'").toBe("removed")
  })

  it("blocks non-executives from calling PATCH /members (403)", async () => {
    // The original exec was removed; sign up a brand-new user, have them join,
    // and try to demote the remaining exec (memberUser).
    await signup(`${RUN_PREFIX}-stranger@verify.test`, password, "Stranger")
    const { jar } = await login(`${RUN_PREFIX}-stranger@verify.test`, password)
    await req(jar, "POST", "/api/clubs/join", {
      body: { clubCode: club.clubCode, clubPassword: clubPassword },
    })
    const r = await req(jar, "PATCH", `/api/clubs/${club.id}/members`, {
      body: { action: "demote", userId: memberUser.id },
    })
    expect(r.status, `expected 403 for non-exec PATCH /members, got ${r.status}`).toBe(403)
  })
})
