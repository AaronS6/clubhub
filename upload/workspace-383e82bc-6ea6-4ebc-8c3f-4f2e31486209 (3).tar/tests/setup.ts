// Shared helpers for the ClubHub test suite (bun test).
//
// Test approach:
//   - The Next.js dev server must be running on http://localhost:3000 (the
//     sandbox auto-starts it; if not, run `bun run dev` in another shell).
//   - Each test file uses a unique RUN_PREFIX (timestamp + random) so its
//     artifacts (users, clubs, files) don't collide with other runs.
//   - Each test creates its own users/clubs via the public API and DELETES
//     them at the end (via direct Prisma access through `db`).
//   - We do NOT use a separate test database — we use the existing dev DB
//     (`db/custom.db`) but clean up everything we create, so the dev DB is
//     left untouched after a green test run.  This is the simplest approach
//     given the shared global PrismaClient singleton (`src/lib/db.ts`).
//
// Usage in a test file:
//   import { signup, login, req, jsonOrText, CLEANUP, cleanupAll } from "./setup"
//   const { jar, user } = await login(email, password)
//   ...
//   afterAll(async () => { await cleanupAll() })

import { db } from "@/lib/db"
import { promises as fs } from "fs"
import path from "path"

const BASE = process.env.TEST_BASE_URL ?? "http://localhost:3000"

export const RUN_PREFIX = `2d-test-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`

// Global registry of artifacts created during this test process so we can
// clean them all up in afterAll().
export const CLEANUP = {
  users: [] as string[],
  clubs: [] as string[],
  files: [] as string[],
}

// ---------------- Cookie-jar fetch helper ----------------
export class CookieJar {
  private cookies = new Map<string, string>()
  set(_url: string, cookieHeader: string | string[]) {
    const headers = Array.isArray(cookieHeader) ? cookieHeader : [cookieHeader]
    for (const h of headers) {
      if (!h) continue
      const first = h.split(";")[0]
      const eq = first.indexOf("=")
      if (eq > 0) {
        const name = first.slice(0, eq).trim()
        const value = first.slice(eq + 1).trim()
        this.cookies.set(name, value)
      }
    }
  }
  header(): string {
    return Array.from(this.cookies.entries()).map(([n, v]) => `${n}=${v}`).join("; ")
  }
}

export interface ReqOpts {
  body?: any
  headers?: Record<string, string>
  isForm?: boolean
  rawBody?: boolean
  retries?: number
}

export async function req(jar: CookieJar, method: string, urlPath: string, opts: ReqOpts = {}): Promise<Response> {
  const { body, headers = {}, isForm = false, rawBody = false, retries = 3 } = opts
  const url = urlPath.startsWith("http") ? urlPath : `${BASE}${urlPath}`
  const finalHeaders: Record<string, string> = { ...headers }
  const cookie = jar.header()
  if (cookie) finalHeaders.Cookie = cookie

  let payload: any
  if (rawBody) {
    payload = body
  } else if (body && !isForm) {
    finalHeaders["Content-Type"] = "application/json"
    payload = JSON.stringify(body)
  } else if (isForm) {
    payload = body
  } else {
    payload = undefined
  }

  let lastErr: unknown
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, { method, headers: finalHeaders, body: payload })
      if (res.headers.get("set-cookie")) {
        jar.set(url, res.headers.get("set-cookie")!)
        const multi = (res.headers as any).getSetCookie?.()
        if (multi && multi.length > 1) jar.set(url, multi)
      }
      return res
    } catch (e) {
      lastErr = e
      const wait = Math.min(1000 * Math.pow(2, attempt), 4000)
      await new Promise((r) => setTimeout(r, wait))
    }
  }
  throw lastErr
}

export async function jsonOrText(res: Response): Promise<any> {
  const ct = res.headers.get("content-type") || ""
  if (ct.includes("application/json")) {
    try { return await res.json() } catch { return await res.text() }
  }
  return await res.text()
}

// ---------------- Auth helpers ----------------
export async function getCsrfToken(jar: CookieJar): Promise<string> {
  const res = await req(jar, "GET", "/api/auth/csrf")
  const data = await res.json()
  return data.csrfToken
}

export async function signup(email: string, password: string, name: string) {
  const res = await fetch(`${BASE}/api/auth/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password, name }),
  })
  if (res.status !== 200) throw new Error(`signup failed: ${res.status}`)
  const data = await res.json()
  CLEANUP.users.push(data.userId)
  return data
}

export async function login(email: string, password: string) {
  const jar = new CookieJar()
  const csrf = await getCsrfToken(jar)
  const res = await req(jar, "POST", "/api/auth/callback/credentials", {
    body: new URLSearchParams({
      csrfToken: csrf,
      email,
      password,
      json: "true",
      callbackUrl: "/",
    }).toString(),
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    rawBody: true,
  })
  if (res.status !== 200) throw new Error(`login failed: ${res.status}`)
  const s = await req(jar, "GET", "/api/auth/session")
  const sj = await s.json()
  if (!sj?.user?.email) throw new Error(`login did not produce session: ${JSON.stringify(sj)}`)
  return { jar, user: sj.user }
}

// ---------------- Club helpers ----------------
export async function createClub(jar: CookieJar, name: string, password = "club-pass-1234") {
  const res = await req(jar, "POST", "/api/clubs", {
    body: { name, description: "test club", accentColor: "#16a34a", clubPassword: password },
  })
  if (res.status !== 200) throw new Error(`createClub failed: ${res.status}`)
  const data = await res.json()
  CLEANUP.clubs.push(data.club.id)
  return data.club as { id: string; name: string; clubCode: string; accentColor: string; role: string }
}

export async function joinClub(jar: CookieJar, clubCode: string, clubPassword: string) {
  const res = await req(jar, "POST", "/api/clubs/join", {
    body: { clubCode, clubPassword },
  })
  return { status: res.status, body: await jsonOrText(res) }
}

// ---------------- Cleanup ----------------
export async function cleanupAll() {
  // Delete clubs first (cascade removes memberships, hours, etc.).
  for (const cid of CLEANUP.clubs) {
    await db.club.delete({ where: { id: cid } }).catch(() => {})
  }
  for (const uid of CLEANUP.users) {
    await db.user.delete({ where: { id: uid } }).catch(() => {})
  }
  // Remove orphan upload directories.
  for (const cid of CLEANUP.clubs) {
    await fs.rm(path.join(process.cwd(), "public", "uploads", "clubs", cid), { recursive: true, force: true }).catch(() => {})
  }
  for (const f of CLEANUP.files) {
    await fs.unlink(f).catch(() => {})
  }
  CLEANUP.clubs.length = 0
  CLEANUP.users.length = 0
  CLEANUP.files.length = 0
}
