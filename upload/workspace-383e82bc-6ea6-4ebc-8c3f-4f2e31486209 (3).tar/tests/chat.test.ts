// tests/chat.test.ts
//
// Tests the group-chat subsystem:
//   1. GET /conversations bootstraps a club-wide conversation on first call.
//   2. POST a message → 201; subsequent GET returns it.
//   3. A second user in the club sees the message via GET.
//   4. Author PATCHes own message → editedAt set.
//   5. Author DELETEs own message → 200, message soft-deleted (deletedAt set).
//   6. Non-member GET /messages → 403.
//   7. Rate limit: 31 rapid messages → 429 on the 31st.
//
// Test approach: fetch against the running dev server; clean up via afterAll.

import { describe, it, expect, beforeAll, afterAll } from "bun:test"
import { db } from "@/lib/db"
import {
  signup, login, createClub, req, jsonOrText,
  RUN_PREFIX, cleanupAll, CLEANUP,
} from "./setup"

const execEmail = `${RUN_PREFIX}-chat-exec@verify.test`
const memberEmail = `${RUN_PREFIX}-chat-member@verify.test`
const strangerEmail = `${RUN_PREFIX}-chat-stranger@verify.test`
const password = "Password123!"
const clubPassword = "club-pass-1234"

let execJar: any
let execUser: any
let memberJar: any
let memberUser: any
let strangerJar: any
let club: { id: string; name: string; clubCode: string; accentColor: string; role: string }
let clubWideConversationId: string

beforeAll(async () => {
  await signup(execEmail, password, "Exec Chat")
  await signup(memberEmail, password, "Member Chat")
  await signup(strangerEmail, password, "Stranger Chat")
  ;({ jar: execJar, user: execUser } = await login(execEmail, password))
  ;({ jar: memberJar, user: memberUser } = await login(memberEmail, password))
  ;({ jar: strangerJar } = await login(strangerEmail, password))
  club = await createClub(execJar, `${RUN_PREFIX} Chat Club`, clubPassword)
  // Member joins the club
  await req(memberJar, "POST", "/api/clubs/join", {
    body: { clubCode: club.clubCode, clubPassword },
  })
})

afterAll(async () => {
  await cleanupAll()
  await db.$disconnect()
})

describe("GET /api/clubs/[clubId]/chat/conversations (bootstrap)", () => {
  it("auto-creates a club-wide conversation on first GET", async () => {
    const r = await req(execJar, "GET", `/api/clubs/${club.id}/chat/conversations`)
    expect(r.status, `expected 200, got ${r.status}`).toBe(200)
    const j = await r.json()
    const clubWide = (j.conversations ?? []).find((c: any) => c.type === "club_wide")
    expect(clubWide, "a club-wide conversation must exist after GET").toBeTruthy()
    clubWideConversationId = clubWide.id
    expect(j.myUserId, "response must include myUserId").toBe(execUser.id)
  })
})

describe("POST /api/clubs/[clubId]/chat/conversations/[id]/messages", () => {
  it("creates a message with 201 and returns it", async () => {
    const r = await req(
      execJar,
      "POST",
      `/api/clubs/${club.id}/chat/conversations/${clubWideConversationId}/messages`,
      { body: { body: "Hello, club!" } },
    )
    expect(r.status, `expected 201, got ${r.status}`).toBe(201)
    const j = await r.json()
    expect(j.message.body, "body must round-trip").toBe("Hello, club!")
    expect(j.message.author.id, "author must be the exec").toBe(execUser.id)
    expect(j.message.isMine, "isMine must be true for the author").toBe(true)
    expect(j.message.deletedAt, "deletedAt must be null on create").toBeNull()
  })

  it("subsequent GET returns the message", async () => {
    const r = await req(
      execJar,
      "GET",
      `/api/clubs/${club.id}/chat/conversations/${clubWideConversationId}/messages`,
    )
    expect(r.status).toBe(200)
    const j = await r.json()
    const found = (j.messages ?? []).some((m: any) => m.body === "Hello, club!")
    expect(found, "the posted message must appear in GET").toBe(true)
  })

  it("a second club member sees the message via GET", async () => {
    const r = await req(
      memberJar,
      "GET",
      `/api/clubs/${club.id}/chat/conversations/${clubWideConversationId}/messages`,
    )
    expect(r.status).toBe(200)
    const j = await r.json()
    const found = (j.messages ?? []).some((m: any) => m.body === "Hello, club!")
    expect(found, "the other member must see the exec's message").toBe(true)
  })
})

describe("PATCH message (edit own)", () => {
  let messageId: string
  it("lets the author edit their own message", async () => {
    // Post a new message to edit.
    const post = await req(
      execJar,
      "POST",
      `/api/clubs/${club.id}/chat/conversations/${clubWideConversationId}/messages`,
      { body: { body: "edit-me" } },
    )
    expect(post.status).toBe(201)
    const pj = await post.json()
    messageId = pj.message.id

    const r = await req(
      execJar,
      "PATCH",
      `/api/clubs/${club.id}/chat/conversations/${clubWideConversationId}/messages/${messageId}`,
      { body: { body: "edited body" } },
    )
    expect(r.status, `expected 200 for PATCH, got ${r.status}`).toBe(200)
    const j = await r.json()
    expect(j.message.body, "body must be updated").toBe("edited body")
    expect(j.message.editedAt, "editedAt must be set").toBeTruthy()
  })

  it("rejects edit by a non-author non-exec (403)", async () => {
    // Use the message from the previous test (still owned by exec).
    const r = await req(
      memberJar,
      "PATCH",
      `/api/clubs/${club.id}/chat/conversations/${clubWideConversationId}/messages/${messageId}`,
      { body: { body: "hijack attempt" } },
    )
    expect(r.status, `expected 403 for non-author PATCH, got ${r.status}`).toBe(403)
  })
})

describe("DELETE message (soft-delete own)", () => {
  let messageId: string
  it("lets the author soft-delete their own message (200, deletedAt set)", async () => {
    const post = await req(
      execJar,
      "POST",
      `/api/clubs/${club.id}/chat/conversations/${clubWideConversationId}/messages`,
      { body: { body: "delete-me" } },
    )
    expect(post.status).toBe(201)
    const pj = await post.json()
    messageId = pj.message.id

    const r = await req(
      execJar,
      "DELETE",
      `/api/clubs/${club.id}/chat/conversations/${clubWideConversationId}/messages/${messageId}`,
    )
    expect(r.status, `expected 200 for DELETE, got ${r.status}`).toBe(200)

    // Verify the message row still exists but has deletedAt set.
    const row = await db.message.findUnique({ where: { id: messageId }, select: { deletedAt: true, body: true } })
    expect(row, "message row must still exist after soft-delete").not.toBeNull()
    expect(row!.deletedAt, "deletedAt must be set after soft-delete").toBeTruthy()
  })
})

describe("Authorization guard", () => {
  it("returns 403 when a non-member GETs messages", async () => {
    // stranger is not a member of this conversation (or club).
    const r = await req(
      strangerJar,
      "GET",
      `/api/clubs/${club.id}/chat/conversations/${clubWideConversationId}/messages`,
    )
    expect(r.status, `expected 403 for non-member GET messages, got ${r.status}`).toBe(403)
  })

  it("returns 403 when a non-member tries to POST a message", async () => {
    const r = await req(
      strangerJar,
      "POST",
      `/api/clubs/${club.id}/chat/conversations/${clubWideConversationId}/messages`,
      { body: { body: "intruder" } },
    )
    expect(r.status, `expected 403 for non-member POST, got ${r.status}`).toBe(403)
  })
})

describe("Rate limit (30 messages per minute per user per conversation)", () => {
  it("returns 429 on the 31st rapid message", async () => {
    // We post 31 messages back-to-back. The first 30 should be 201, the 31st
    // should be 429. (The rate-limit window is 60s and is keyed by
    // `${userId}:${conversationId}`.)
    let lastStatus = 0
    let lastBody: any
    for (let i = 0; i < 31; i++) {
      const r = await req(
        memberJar,
        "POST",
        `/api/clubs/${club.id}/chat/conversations/${clubWideConversationId}/messages`,
        { body: { body: `rl-${i}` } },
      )
      lastStatus = r.status
      lastBody = await jsonOrText(r)
      if (i < 30) {
        expect(r.status, `message #${i + 1} should be 201, got ${r.status}`).toBe(201)
      }
    }
    expect(lastStatus, `31st rapid message should be 429-rate-limited, got ${lastStatus}`).toBe(429)
    expect(lastBody?.error, "rate-limit error should mention 'fast'").toMatch(/fast/i)
  })
})
