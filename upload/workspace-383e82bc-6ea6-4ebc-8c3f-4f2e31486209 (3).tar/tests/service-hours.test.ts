// tests/service-hours.test.ts
//
// Tests the service-hours submission + review flow:
//   1. POST /api/clubs/[clubId]/hours creates a pending entry.
//   2. PATCH /api/clubs/[clubId]/hours/[hourId] with status="approved":
//        - transitions the entry to "approved"
//        - sets reviewedBy + reviewedAt
//        - deletes the proof file from disk
//   3. PATCH .../[hourId] with status="rejected":
//        - transitions the entry to "rejected"
//        - deletes the proof file from disk
//
// Test approach: fetch against the running dev server; clean up via afterAll.

import { describe, it, expect, beforeAll, afterAll } from "bun:test"
import { db } from "@/lib/db"
import sharp from "sharp"
import { promises as fs } from "fs"
import path from "path"
import {
  signup, login, createClub, req, jsonOrText,
  RUN_PREFIX, cleanupAll, CLEANUP,
} from "./setup"

const execEmail = `${RUN_PREFIX}-exec@verify.test`
const memberEmail = `${RUN_PREFIX}-member@verify.test`
const password = "Password123!"
const clubPassword = "club-pass-1234"

let execJar: any
let memberJar: any
let memberUser: any
let club: { id: string; name: string; clubCode: string; accentColor: string; role: string }

beforeAll(async () => {
  await signup(execEmail, password, "Exec")
  await signup(memberEmail, password, "Member")
  ;({ jar: execJar } = await login(execEmail, password))
  ;({ jar: memberJar, user: memberUser } = await login(memberEmail, password))
  club = await createClub(execJar, `${RUN_PREFIX} Hours Club`, clubPassword)
  // Member joins the club
  await req(memberJar, "POST", "/api/clubs/join", {
    body: { clubCode: club.clubCode, clubPassword: clubPassword },
  })
})

afterAll(async () => {
  await cleanupAll()
  await db.$disconnect()
})

async function uploadProof(jar: any, clubId: string) {
  const png = await sharp({
    create: { width: 500, height: 400, channels: 3, background: { r: 100, g: 50, b: 200 } },
  }).png().toBuffer()
  const form = new FormData()
  form.append("file", new Blob([png], { type: "image/png" }), "p.png")
  const r = await req(jar, "POST", `/api/clubs/${clubId}/hours/upload`, { body: form, isForm: true })
  const d = await r.json()
  return d.url as string
}

function proofPath(url: string) {
  return path.join(process.cwd(), "public", url.replace(/^\//, ""))
}

async function fileExists(p: string) {
  try { await fs.access(p); return true } catch { return false }
}

describe("POST /api/clubs/[clubId]/hours", () => {
  it("creates a pending entry owned by the submitter", async () => {
    const r = await req(memberJar, "POST", `/api/clubs/${club.id}/hours`, {
      body: {
        dateOfService: new Date(Date.now() - 86400000).toISOString(),
        hours: 2.5,
        reasonText: "Tutored students",
      },
    })
    expect(r.status, `expected 201, got ${r.status}`).toBe(201)
    const d = await r.json()
    expect(d.entry.status, "newly-submitted entry must be pending").toBe("pending")
    expect(d.entry.userId, "entry must belong to the submitter").toBe(memberUser.id)
    expect(d.entry.hours).toBe(2.5)

    // Verify directly in the DB
    const row = await db.serviceHour.findUnique({ where: { id: d.entry.id } })
    expect(row, "DB row must exist").not.toBeNull()
    expect(row!.status).toBe("pending")
  })

  it("rejects submission with hours <= 0 (400)", async () => {
    const r = await req(memberJar, "POST", `/api/clubs/${club.id}/hours`, {
      body: {
        dateOfService: new Date().toISOString(),
        hours: 0,
        reasonText: "x",
      },
    })
    expect(r.status).toBe(400)
  })

  it("rejects submission with empty reasonText (400)", async () => {
    const r = await req(memberJar, "POST", `/api/clubs/${club.id}/hours`, {
      body: {
        dateOfService: new Date().toISOString(),
        hours: 1,
        reasonText: "   ",
      },
    })
    expect(r.status).toBe(400)
  })
})

describe("PATCH /api/clubs/[clubId]/hours/[hourId] (approve)", () => {
  it("approves a pending entry, sets reviewer/timestamp, deletes proof file", async () => {
    const proofUrl = await uploadProof(memberJar, club.id)
    const submit = await req(memberJar, "POST", `/api/clubs/${club.id}/hours`, {
      body: {
        dateOfService: new Date(Date.now() - 86400000).toISOString(),
        hours: 3,
        reasonText: "Verify approve test",
        proofFileUrl: proofUrl,
      },
    })
    const entry = (await submit.json()).entry
    const proofFull = proofPath(proofUrl)
    CLEANUP.files.push(proofFull) // ensure cleanup if test fails
    expect(await fileExists(proofFull), "proof file must exist right after upload").toBe(true)

    const r = await req(execJar, "PATCH", `/api/clubs/${club.id}/hours/${entry.id}`, {
      body: { status: "approved", reviewComment: "Looks good" },
    })
    expect(r.status, `expected 200 on approve, got ${r.status}`).toBe(200)
    const d = await r.json()
    expect(d.entry.status).toBe("approved")
    expect(d.entry.reviewedBy, "reviewedBy must be set to the exec's id").toBeTruthy()
    expect(d.entry.reviewedAt, "reviewedAt must be set").toBeTruthy()
    expect(d.entry.proofFileUrl, "proofFileUrl must be nulled out after review").toBeNull()

    // Verify in DB
    const row = await db.serviceHour.findUnique({ where: { id: entry.id } })
    expect(row!.status).toBe("approved")
    expect(row!.reviewedBy).toBeTruthy()
    expect(row!.reviewedAt).toBeTruthy()
    expect(row!.proofFileUrl).toBeNull()

    // Verify the file is actually gone from disk
    expect(await fileExists(proofFull), "proof file must be deleted from disk on approve").toBe(false)
    // Remove from cleanup since it's already gone
    CLEANUP.files = CLEANUP.files.filter((f) => f !== proofFull)
  })

  it("rejects approving an already-reviewed entry (400)", async () => {
    // Create + approve
    const submit = await req(memberJar, "POST", `/api/clubs/${club.id}/hours`, {
      body: {
        dateOfService: new Date().toISOString(),
        hours: 1,
        reasonText: "Already reviewed",
      },
    })
    const entry = (await submit.json()).entry
    await req(execJar, "PATCH", `/api/clubs/${club.id}/hours/${entry.id}`, { body: { status: "approved" } })
    // Try to approve again
    const r = await req(execJar, "PATCH", `/api/clubs/${club.id}/hours/${entry.id}`, { body: { status: "approved" } })
    expect(r.status, `expected 400 for re-review, got ${r.status}`).toBe(400)
  })

  it("rejects approval from a non-executive (403)", async () => {
    const submit = await req(memberJar, "POST", `/api/clubs/${club.id}/hours`, {
      body: { dateOfService: new Date().toISOString(), hours: 1, reasonText: "Member approve attempt" },
    })
    const entry = (await submit.json()).entry
    const r = await req(memberJar, "PATCH", `/api/clubs/${club.id}/hours/${entry.id}`, { body: { status: "approved" } })
    expect(r.status, `expected 403 for non-exec approve, got ${r.status}`).toBe(403)
  })
})

describe("PATCH /api/clubs/[clubId]/hours/[hourId] (reject)", () => {
  it("rejects a pending entry and deletes the proof file", async () => {
    const proofUrl = await uploadProof(memberJar, club.id)
    const submit = await req(memberJar, "POST", `/api/clubs/${club.id}/hours`, {
      body: {
        dateOfService: new Date(Date.now() - 86400000).toISOString(),
        hours: 2,
        reasonText: "Verify reject test",
        proofFileUrl: proofUrl,
      },
    })
    const entry = (await submit.json()).entry
    const proofFull = proofPath(proofUrl)
    CLEANUP.files.push(proofFull)
    expect(await fileExists(proofFull), "proof file must exist before reject").toBe(true)

    const r = await req(execJar, "PATCH", `/api/clubs/${club.id}/hours/${entry.id}`, {
      body: { status: "rejected", reviewComment: "Insufficient detail" },
    })
    expect(r.status, `expected 200 on reject, got ${r.status}`).toBe(200)
    const d = await r.json()
    expect(d.entry.status).toBe("rejected")
    expect(d.entry.proofFileUrl).toBeNull()

    const row = await db.serviceHour.findUnique({ where: { id: entry.id } })
    expect(row!.status).toBe("rejected")
    expect(row!.reviewedBy).toBeTruthy()

    expect(await fileExists(proofFull), "proof file must be deleted on reject").toBe(false)
    CLEANUP.files = CLEANUP.files.filter((f) => f !== proofFull)
  })
})
