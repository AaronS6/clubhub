// tests/club-password.test.ts
//
// Tests the club-password encryption-at-rest + exec-only visibility + change flow:
//   1. Creating a club stores an ENCRYPTED password (not plaintext) — the DB
//      column `clubPasswordEnc` must differ from the plaintext AND contain the
//      `iv:tag:ciphertext` separator pattern.
//   2. Exec GET /api/clubs/[clubId]/password returns the decrypted plaintext.
//   3. Non-exec GET /password returns 403.
//   4. After PATCH changes the password, the OLD password no longer works for
//      /clubs/join and the NEW one does.
//   5. Non-exec PATCH /password returns 403.
//
// Test approach: fetch against the running dev server; clean up via afterAll.

import { describe, it, expect, beforeAll, afterAll } from "bun:test"
import { db } from "@/lib/db"
import {
  signup, login, createClub, joinClub, req, jsonOrText,
  RUN_PREFIX, cleanupAll, CLEANUP,
} from "./setup"

const execEmail = `${RUN_PREFIX}-exec-pw@verify.test`
const memberEmail = `${RUN_PREFIX}-member-pw@verify.test`
const strangerEmail = `${RUN_PREFIX}-stranger-pw@verify.test`
const password = "Password123!"
const clubPassword = "club-pass-1234"
const newClubPassword = "new-club-pass-9999"

let execJar: any
let memberJar: any
let strangerJar: any
let club: { id: string; name: string; clubCode: string; accentColor: string; role: string }

beforeAll(async () => {
  await signup(execEmail, password, "Exec PW")
  await signup(memberEmail, password, "Member PW")
  await signup(strangerEmail, password, "Stranger PW")
  ;({ jar: execJar } = await login(execEmail, password))
  ;({ jar: memberJar } = await login(memberEmail, password))
  ;({ jar: strangerJar } = await login(strangerEmail, password))
  club = await createClub(execJar, `${RUN_PREFIX} PW Club`, clubPassword)
  // Member joins (uses the correct password)
  await req(memberJar, "POST", "/api/clubs/join", {
    body: { clubCode: club.clubCode, clubPassword },
  })
})

afterAll(async () => {
  await cleanupAll()
  await db.$disconnect()
})

describe("Club password encryption-at-rest", () => {
  it("stores an encrypted password, not the plaintext", async () => {
    const row = await db.club.findUnique({ where: { id: club.id }, select: { clubPasswordEnc: true } })
    expect(row, "club must exist").not.toBeNull()
    const enc = row!.clubPasswordEnc
    expect(enc, "clubPasswordEnc must be non-empty").toBeTruthy()
    expect(enc, "stored value must NOT be the plaintext").not.toBe(clubPassword)
    // The encrypt helper uses the `iv:tag:ciphertext` (all hex) format.
    expect(enc.split(":").length, "encrypted value must have 3 colon-separated parts").toBe(3)
    expect(enc.split(":").every((p) => /^[0-9a-fA-F]+$/.test(p)), "all parts must be hex").toBe(true)
  })
})

describe("GET /api/clubs/[clubId]/password", () => {
  it("returns the decrypted plaintext for executives (200)", async () => {
    const r = await req(execJar, "GET", `/api/clubs/${club.id}/password`)
    expect(r.status, `expected 200 for exec GET, got ${r.status}`).toBe(200)
    const j = await r.json()
    expect(j.password, "decrypted password must equal the original plaintext").toBe(clubPassword)
  })

  it("returns 403 for non-executives", async () => {
    const r = await req(memberJar, "GET", `/api/clubs/${club.id}/password`)
    expect(r.status, `expected 403 for non-exec GET, got ${r.status}`).toBe(403)
  })

  it("returns 403 for non-members", async () => {
    const r = await req(strangerJar, "GET", `/api/clubs/${club.id}/password`)
    expect(r.status, `expected 403 for non-member GET, got ${r.status}`).toBe(403)
  })
})

describe("PATCH /api/clubs/[clubId]/password", () => {
  it("rejects non-executives with 403", async () => {
    const r = await req(memberJar, "PATCH", `/api/clubs/${club.id}/password`, {
      body: { newPassword: "should-not-work" },
    })
    expect(r.status, `expected 403 for non-exec PATCH, got ${r.status}`).toBe(403)
    // Confirm the password did NOT change.
    const row = await db.club.findUnique({ where: { id: club.id }, select: { clubPasswordEnc: true } })
    expect(row!.clubPasswordEnc.split(":").length).toBe(3)
  })

  it("rejects too-short passwords with 400", async () => {
    const r = await req(execJar, "PATCH", `/api/clubs/${club.id}/password`, {
      body: { newPassword: "ab" },
    })
    expect(r.status, `expected 400 for short password, got ${r.status}`).toBe(400)
  })

  it("exec PATCH changes the password; old password stops working, new one works", async () => {
    const r = await req(execJar, "PATCH", `/api/clubs/${club.id}/password`, {
      body: { newPassword: newClubPassword },
    })
    expect(r.status, `expected 200 for exec PATCH, got ${r.status}`).toBe(200)

    // Old password no longer works for a fresh join.
    await signup(`${RUN_PREFIX}-join-old@verify.test`, password, "Join Old")
    const { jar: oldJar } = await login(`${RUN_PREFIX}-join-old@verify.test`, password)
    const oldJoin = await joinClub(oldJar, club.clubCode, clubPassword)
    expect(oldJoin.status, "old password must no longer work for join (expected 400)").toBe(400)
    CLEANUP.users.push((oldJar as any).user?.id ?? "")
    // ^ (no actual user id captured since login returns just the jar here;
    //    we register the email above so cleanupAll already picks it up via
    //    the global CLEANUP.users list as well — but to be safe we noop.)

    // New password DOES work for a fresh join.
    await signup(`${RUN_PREFIX}-join-new@verify.test`, password, "Join New")
    const { jar: newJar } = await login(`${RUN_PREFIX}-join-new@verify.test`, password)
    const newJoin = await joinClub(newJar, club.clubCode, newClubPassword)
    expect(newJoin.status, `new password must work for join (expected 200): ${JSON.stringify(newJoin.body)}`).toBe(200)
  })

  it("returns the NEW plaintext (not the old) on subsequent GET", async () => {
    const r = await req(execJar, "GET", `/api/clubs/${club.id}/password`)
    expect(r.status).toBe(200)
    const j = await r.json()
    expect(j.password, "GET must return the new password after PATCH").toBe(newClubPassword)
  })
})
