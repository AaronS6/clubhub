// tests/auth.test.ts
//
// Tests the auth subsystem at the API level:
//   1. POST /api/auth/signup creates a User row in the database.
//   2. NextAuth credentials callback returns a session for the correct password.
//   3. NextAuth credentials callback rejects a wrong password (no session).
//
// Test approach:
//   - Fetch against the running dev server (http://localhost:3000).
//   - Each test creates its own user with a unique email and cleans up via afterAll().
//   - We do NOT use a separate test database — we use the existing dev DB and
//     clean up everything we create.  See tests/setup.ts for the strategy.

import { describe, it, expect, afterAll, beforeAll } from "bun:test"
import { db } from "@/lib/db"
import { signup, login, req, RUN_PREFIX, cleanupAll } from "./setup"

const email = `${RUN_PREFIX}-auth@verify.test`
const password = "Password123!"
const name = "Auth Tester"

beforeAll(async () => {
  await signup(email, password, name)
})

afterAll(async () => {
  await cleanupAll()
  await db.$disconnect()
})

describe("POST /api/auth/signup", () => {
  it("creates a user with a hashed password (not plaintext) in the database", async () => {
    const user = await db.user.findUnique({ where: { email } })
    expect(user, "signup must have created a User row").not.toBeNull()
    expect(user!.name).toBe(name)
    expect(user!.email).toBe(email)
    expect(user!.passwordHash, "password must be hashed, not stored as plaintext").not.toBe(password)
    expect(user!.passwordHash.length, "bcrypt hash is at least 60 chars").toBeGreaterThanOrEqual(60)
  })

  it("rejects a duplicate email with 409", async () => {
    const res = await fetch("http://localhost:3000/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, name: "Dup" }),
    })
    expect(res.status, `expected 409 for duplicate email, got ${res.status}`).toBe(409)
  })

  it("rejects a weak password (< 8 chars or no number) with 400", async () => {
    const res = await fetch("http://localhost:3000/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: `${RUN_PREFIX}-weak@verify.test`, password: "allletters", name: "Weak" }),
    })
    expect(res.status, `expected 400 for weak password, got ${res.status}`).toBe(400)
  })
})

describe("NextAuth credentials callback", () => {
  it("returns a session for the correct password", async () => {
    const { jar, user } = await login(email, password)
    expect(user.email, "session must include the user's email").toBe(email)
    expect(user.id, "session must include the user's id").toBeTruthy()
    // The session cookie should be set
    const s = await req(jar, "GET", "/api/auth/session")
    const sj = await s.json()
    expect(sj.user.email).toBe(email)
  })

  it("rejects a wrong password (no session)", async () => {
    // Hit csrf + credentials with a wrong password and assert the resulting
    // /api/auth/session has no `user` field.
    const csrfRes = await fetch("http://localhost:3000/api/auth/csrf")
    const csrf = (await csrfRes.json()).csrfToken
    const cookieHeader = csrfRes.headers.get("set-cookie") || ""
    const res = await fetch("http://localhost:3000/api/auth/callback/credentials", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: cookieHeader.split(";")[0],
      },
      body: new URLSearchParams({
        csrfToken: csrf,
        email,
        password: "WrongPassword999!",
        json: "true",
        callbackUrl: "/",
      }).toString(),
      redirect: "manual",
    })
    // With `json: "true"` in the body, NextAuth responds with a 401 JSON body
    // { error: "..." } instead of redirecting.  Without `json: "true"` it
    // would 302-redirect to /api/auth/signin?...&error=CredentialsSignin.
    // Either is acceptable for "rejected wrong password" — accept both.
    expect(
      res.status === 401 || res.status === 302,
      `wrong password should yield 401 (JSON mode) or 302 (redirect mode), got ${res.status}`,
    ).toBe(true)

    // And the session endpoint must not return a user.
    const sessionRes = await fetch("http://localhost:3000/api/auth/session", {
      headers: { Cookie: cookieHeader.split(";")[0] },
    })
    const sj = await sessionRes.json()
    expect(sj.user, "no session should exist after a failed login").toBeUndefined()
  })

  it("rejects a non-existent email (no session)", async () => {
    const csrfRes = await fetch("http://localhost:3000/api/auth/csrf")
    const csrf = (await csrfRes.json()).csrfToken
    const cookieHeader = csrfRes.headers.get("set-cookie") || ""
    const res = await fetch("http://localhost:3000/api/auth/callback/credentials", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: cookieHeader.split(";")[0],
      },
      body: new URLSearchParams({
        csrfToken: csrf,
        email: `${RUN_PREFIX}-nonexistent@verify.test`,
        password,
        json: "true",
        callbackUrl: "/",
      }).toString(),
      redirect: "manual",
    })
    expect(
      res.status === 401 || res.status === 302,
      `non-existent email should yield 401 or 302, got ${res.status}`,
    ).toBe(true)
  })
})
