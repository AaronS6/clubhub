// tests/clubs.test.ts
//
// Tests the clubs subsystem:
//   1. POST /api/clubs creates a club with a 6-char code and makes the creator an executive.
//   2. POST /api/clubs/join succeeds with correct code+password (200).
//   3. POST /api/clubs/join rejects a wrong password (400).
//   4. POST /api/clubs/join rejects a wrong code (404).
//   5. POST /api/clubs/join when already a member returns 409.
//
// Test approach: fetch against the running dev server; clean up via afterAll.

import { describe, it, expect, beforeAll, afterAll } from "bun:test"
import { db } from "@/lib/db"
import {
  signup, login, createClub, joinClub, req, jsonOrText,
  RUN_PREFIX, cleanupAll,
} from "./setup"

const execEmail = `${RUN_PREFIX}-exec@verify.test`
const memberEmail = `${RUN_PREFIX}-member@verify.test`
const password = "Password123!"
const clubPassword = "club-pass-1234"
const clubName = `${RUN_PREFIX} Club`

let execJar: any
let execUser: any
let club: { id: string; name: string; clubCode: string; accentColor: string; role: string }

beforeAll(async () => {
  await signup(execEmail, password, "Exec")
  await signup(memberEmail, password, "Member")
  ;({ jar: execJar, user: execUser } = await login(execEmail, password))
  club = await createClub(execJar, clubName, clubPassword)
})

afterAll(async () => {
  await cleanupAll()
  await db.$disconnect()
})

describe("POST /api/clubs (create)", () => {
  it("generates a 6-character club code", async () => {
    expect(club.clubCode.length, `clubCode must be 6 chars (got "${club.clubCode}")`).toBe(6)
    expect(club.clubCode, "clubCode must be alphanumeric").toMatch(/^[A-Z0-9]{6}$/)
  })

  it("makes the creator an executive in the club_members table", async () => {
    const m = await db.clubMember.findUnique({
      where: { clubId_userId: { clubId: club.id, userId: execUser.id } },
    })
    expect(m, "creator must have a ClubMember row").not.toBeNull()
    expect(m!.role, "creator role must be 'executive'").toBe("executive")
    expect(m!.status, "creator status must be 'active'").toBe("active")
  })

  it("returns the club in GET /api/clubs for the creator", async () => {
    const res = await req(execJar, "GET", "/api/clubs")
    const data = await res.json()
    expect(data.clubs.some((c: any) => c.clubId === club.id && c.role === "executive")).toBe(true)
  })
})

describe("POST /api/clubs/join", () => {
  it("succeeds with the correct code+password and makes the joiner a member", async () => {
    const { jar: memberJar, user: memberUser } = await login(memberEmail, password)
    const r = await joinClub(memberJar, club.clubCode, clubPassword)
    expect(r.status, `expected 200 for correct join, got ${r.status}: ${JSON.stringify(r.body)}`).toBe(200)
    expect(r.body.club.role, "joiner should be a 'member'").toBe("member")

    const m = await db.clubMember.findUnique({
      where: { clubId_userId: { clubId: club.id, userId: memberUser.id } },
    })
    expect(m, "joiner must have a ClubMember row").not.toBeNull()
    expect(m!.role).toBe("member")
    expect(m!.status).toBe("active")
  })

  it("rejects a wrong password with 400", async () => {
    // Use a brand-new user so we don't trigger the "already a member" path.
    await signup(`${RUN_PREFIX}-wrongpw@verify.test`, password, "Wrong PW")
    const { jar } = await login(`${RUN_PREFIX}-wrongpw@verify.test`, password)
    const r = await joinClub(jar, club.clubCode, "totally-wrong-pw")
    expect(r.status, `expected 400 for wrong password, got ${r.status}`).toBe(400)
  })

  it("rejects a non-existent code with 404", async () => {
    await signup(`${RUN_PREFIX}-wrongcode@verify.test`, password, "Wrong Code")
    const { jar } = await login(`${RUN_PREFIX}-wrongcode@verify.test`, password)
    const r = await joinClub(jar, "ZZZZZZ", clubPassword)
    expect(r.status, `expected 404 for unknown code, got ${r.status}`).toBe(404)
    expect(String(r.body?.error || ""), `error should mention "no club found"`).toMatch(/no club found/i)
  })

  it("returns 409 when joining a club you are already a member of", async () => {
    // The memberEmail user already joined above.
    const { jar } = await login(memberEmail, password)
    const r = await joinClub(jar, club.clubCode, clubPassword)
    expect(r.status, `expected 409 for already-a-member, got ${r.status}`).toBe(409)
  })
})
