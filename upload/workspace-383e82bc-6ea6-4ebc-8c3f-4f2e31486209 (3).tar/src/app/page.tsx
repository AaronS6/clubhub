"use client"

import { useAppStore } from "@/lib/store"
import { AppShell } from "@/components/app-shell"
import { DashboardView } from "@/components/views/dashboard-view"
import { AnnouncementsView } from "@/components/views/announcements-view"
import { HoursView } from "@/components/views/hours-view"
import { ApprovalsView } from "@/components/views/approvals-view"
import { TasksView } from "@/components/views/tasks-view"
import { MeetingsView } from "@/components/views/meetings-view"
import { TeamsView } from "@/components/views/teams-view"
import { MembersView } from "@/components/views/members-view"
import { ActivityView } from "@/components/views/activity-view"
import { ChatView } from "@/components/views/chat-view"
import { NotificationsView } from "@/components/views/notifications-view"

export default function Home() {
  const view = useAppStore((s) => s.view)
  return (
    <AppShell>
      {view === "dashboard" && <DashboardView />}
      {view === "announcements" && <AnnouncementsView />}
      {view === "hours" && <HoursView />}
      {view === "approvals" && <ApprovalsView />}
      {view === "tasks" && <TasksView />}
      {view === "meetings" && <MeetingsView />}
      {view === "teams" && <TeamsView />}
      {view === "members" && <MembersView />}
      {view === "activity" && <ActivityView />}
      {view === "chat" && <ChatView />}
      {view === "notifications" && <NotificationsView />}
    </AppShell>
  )
}
