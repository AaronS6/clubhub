import { db } from "@/lib/db"
import { getClubContext, json, error } from "@/lib/server-auth"

/**
 * GET /api/clubs/[clubId]/activity
 * Exec-only. Returns activity log entries (newest first), paginated with
 * `?page=&pageSize=50`. Supports filtering by `?actionType=`.
 */
export async function GET(req: Request, ctx: { params: Promise<{ clubId: string }> }) {
  const { clubId } = await ctx.params
  const c = await getClubContext(clubId)
  if (!c) return error("Not a member of this club", 403)
  if (c.membership.role !== "executive") return error("Executives only", 403)

  const url = new URL(req.url)
  const page = Math.max(1, parseInt(url.searchParams.get("page") ?? "1", 10) || 1)
  const pageSize = Math.min(
    200,
    Math.max(1, parseInt(url.searchParams.get("pageSize") ?? "50", 10) || 50)
  )
  const actionType = url.searchParams.get("actionType") || null

  const where = {
    clubId,
    ...(actionType ? { actionType } : {}),
  }

  const [items, total] = await Promise.all([
    db.activityLog.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize + 1, // fetch one extra to determine hasMore
      include: {
        actor: { select: { id: true, name: true, avatarUrl: true } },
      },
    }),
    db.activityLog.count({ where }),
  ])

  const hasMore = items.length > pageSize
  const trimmed = hasMore ? items.slice(0, pageSize) : items

  return json({
    items: trimmed.map((entry) => ({
      id: entry.id,
      actorUserId: entry.actorUserId,
      actorName: entry.actor.name,
      actorAvatarUrl: entry.actor.avatarUrl ?? null,
      actionType: entry.actionType,
      targetType: entry.targetType,
      targetId: entry.targetId,
      description: entry.description,
      createdAt: entry.createdAt,
    })),
    hasMore,
    total,
    page,
    pageSize,
  })
}
