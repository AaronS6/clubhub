/**
 * Server-side helper to push a realtime event to the socket.io mini-service.
 * The mini-service fans out to the relevant room (e.g. `user:<id>` or `club:<id>`).
 * This is best-effort: if the realtime service is down we just skip (the app
 * still works via polling). Called from API routes after a DB mutation.
 */
const REALTIME_URL = "http://localhost:3004/emit"
const INTERNAL_TOKEN = process.env.REALTIME_TOKEN || "dev-realtime-token"

type EmitInput =
  | { kind: "user"; userId: string; event: string; data?: any }
  | { kind: "club"; clubId: string; event: string; data?: any }

export async function emitRealtime(input: EmitInput): Promise<void> {
  try {
    const room = input.kind === "user" ? `user:${input.userId}` : `club:${input.clubId}`
    await fetch(REALTIME_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-realtime-token": INTERNAL_TOKEN },
      body: JSON.stringify({ room, event: input.event, data: input.data ?? {} }),
      // don't block long if the service is unreachable
      signal: AbortSignal.timeout(2000),
    })
  } catch {
    // swallow — realtime is a progressive enhancement
  }
}

/**
 * Convenience wrapper: emit a club-scoped event that triggers React-Query
 * invalidations on every connected client viewing that club.
 * `type` is one of the cases in use-realtime-sync.ts (e.g. "task_created").
 */
export async function emitClubEvent(clubId: string, type: string, data?: any): Promise<void> {
  await emitRealtime({ kind: "club", clubId, event: "realtime:club", data: { type, ...data } })
}
