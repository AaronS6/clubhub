"use client"

import { useEffect, useRef, useState } from "react"
import { useQueryClient } from "@tanstack/react-query"
import { getRealtimeSocket, onRealtimeEvent } from "@/lib/realtime-client"
import { useAppStore } from "@/lib/store"

export type ConnectionState = "connecting" | "connected" | "disconnected"

/**
 * Subscribes to realtime club events and React-Query cache invalidations.
 *
 * On any `realtime:club` event for the current club, it invalidates the
 * relevant query keys for the changed `data.type` (tasks/announcements/etc).
 * This is the single hook every view relies on for live updates — mount it
 * once high in the tree (it already is, inside AppShell).
 *
 * Also exposes a `connectionState` so the UI can show a subtle indicator.
 */
export function useRealtimeSync(): ConnectionState {
  const qc = useQueryClient()
  const currentClubId = useAppStore((s) => s.currentClubId)
  const [state, setState] = useState<ConnectionState>("connecting")
  const clubRef = useRef<string | null>(null)

  useEffect(() => {
    clubRef.current = currentClubId
  }, [currentClubId])

  useEffect(() => {
    const s = getRealtimeSocket()

    const onConn = () => setState(s.connected ? "connected" : "connecting")
    const onDisc = () => setState("disconnected")
    s.on("connect", onConn)
    s.on("disconnect", onDisc)
    s.on("connect_error", onDisc)
    // Defer the initial-state check to a microtask so we're not calling
    // setState synchronously during the effect body.
    Promise.resolve().then(() => {
      if (s.connected) setState("connected")
      else setState("connecting")
    })

    // Club-wide invalidations
    const unsubClub = onRealtimeEvent("realtime:club", (data: any) => {
      const cid = clubRef.current
      if (!cid) return
      const type = data?.type as string | undefined
      // Map the event type to the React-Query keys that need refreshing.
      // We use targeted invalidations to avoid refetching the whole club.
      const invalidate = (keys: string[][]) => {
        for (const key of keys) qc.invalidateQueries({ queryKey: key })
      }
      switch (type) {
        case "task_created":
        case "task_updated":
        case "task_deleted":
        case "task_status_changed":
          invalidate([["tasks", cid], ["dashboard", cid], ["activity", cid]])
          break
        case "announcement_created":
        case "announcement_updated":
        case "announcement_deleted":
        case "new_announcement":
          invalidate([["announcements", cid], ["dashboard", cid], ["activity", cid]])
          break
        case "announcement_reaction":
        case "announcement_comment":
        case "new_comment":
        case "new_reaction":
          invalidate([["announcements", cid], ["comments", cid]])
          break
        case "meeting_created":
        case "meeting_updated":
        case "meeting_cancelled":
        case "meeting_rsvp":
          invalidate([["meetings", cid], ["dashboard", cid], ["activity", cid]])
          break
        case "hours_submitted":
        case "hours_approved":
        case "hours_rejected":
          invalidate([["hours", cid], ["approvals", cid], ["dashboard", cid], ["activity", cid]])
          break
        case "team_created":
        case "team_updated":
        case "team_deleted":
        case "team_member_added":
        case "team_member_removed":
          invalidate([["teams", cid], ["members", cid], ["dashboard", cid], ["activity", cid]])
          break
        case "member_promoted":
        case "member_demoted":
        case "member_removed":
        case "new_member":
          invalidate([["members", cid], ["dashboard", cid], ["activity", cid]])
          break
        case "chat_message":
          invalidate([["conversations", cid], ["messages", cid]])
          break
        // Typing indicator: ephemeral, no cache invalidation. The ChatView
        // subscribes directly to `realtime:club` for these (see
        // TypingIndicator in chat-view.tsx). Listing it here as a no-op
        // keeps the default branch from refreshing dashboard + activity
        // (which would refetch unnecessarily on every keystroke).
        case "chat_typing":
        case "chat_typing:stop":
          break
        case "presence_update":
          invalidate([["presence", cid], ["members", cid]])
          break
        default:
          // Unknown — refresh dashboard + activity as a safe default.
          invalidate([["dashboard", cid], ["activity", cid]])
      }
    })

    return () => {
      s.off("connect", onConn)
      s.off("disconnect", onDisc)
      s.off("connect_error", onDisc)
      unsubClub()
    }
  }, [qc])

  return state
}
