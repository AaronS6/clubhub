# Task 2C — Search + CSV import + Badges

Agent: full-stack-developer (Search + CSV import + Badges)
Task: Add three features to ClubHub — (1) global search command palette (cmdk, Cmd/Ctrl+K), (2) bulk CSV member import (exec only), (3) gamification badges (computed from existing data).

## Plan

### Backend
1. `GET /api/clubs/[clubId]/search?q=` — active membership required. Returns categorized results (members/tasks/announcements/meetings), each capped at 8. Use Prisma `contains` (SQLite LIKE is ASCII-case-insensitive by default). Exclude soft-deleted tasks/announcements and cancelled meetings.
2. `POST /api/clubs/[clubId]/members/import` — exec only, multipart `file`. Tiny RFC-4180-ish CSV parser (no new deps). Expected header columns `name,email` (case-insensitive). For each row: validate email; if a user with that email exists, add as member (skip if already active, reactivate if removed); else push to `pendingInvites`. Max 1 MB / 500 rows. Log `bulk_member_import`.
3. `GET /api/clubs/[clubId]/members/[userId]/badges` — active membership; target user must be an active member. Compute stats with Prisma counts: tasks done (assignedToUserId), approved service hours (sum), going RSVPs count, announcements authored by user in club, team count. Map to 8 badges.

### Frontend
1. `src/components/global-search.tsx` — cmdk `CommandDialog` open on Cmd/Ctrl+K (also `/` shortcut optional). Debounced 200ms. Grouped results with icon + title + subtitle. Selecting navigates via `useAppStore.getState().setView(...)`. Loading + empty states.
2. Wire search trigger button into `app-shell.tsx` (desktop top bar + mobile header).
3. `src/components/shared/badges-display.tsx` — pill grid; earned = `bg-club-muted text-club`; unearned = `bg-muted text-muted-foreground` (faded).
4. Update `members-view.tsx` — add "Import CSV" button (exec only) opening a dialog with file picker + template download + results screen; add per-member detail dialog showing profile + stats + badges + top-3 earned badge icons inline next to member names in the table.

### Decisions
- CSV parsing: write a small custom parser (no papaparse) that handles quoted fields with embedded commas and `""` escapes.
- For emails without accounts: collect into `pendingInvites` and return the club code so the UI can tell the user to share it. Avoids auto-creating users with random passwords (security implications).
- Use the design system per Task F1: `variant="club"`, `bg-club-muted`, `text-club`, `bg-club-subtle`, type-scale classes, `EmptyState`, `StatusBadge`, `RoleBadge`, `card-quiet`.

## Work Log
- Reading worklog + schema + existing patterns (server-auth, activity, store, api client, app-shell, members-view, page-header).
- Writing this plan first.

## Stage Summary
- (filled in at end)

## Stage Summary
- Files created:
  - `src/app/api/clubs/[clubId]/search/route.ts` — `GET ?q=`, returns categorized hits.
  - `src/app/api/clubs/[clubId]/members/import/route.ts` — exec-only CSV import with hand-rolled parser; returns added/already/pending/invalid.
  - `src/app/api/clubs/[clubId]/members/[userId]/badges/route.ts` — computes 8 badges from existing data; returns `{ badges, stats, target }`.
  - `src/components/global-search.tsx` — cmdk `CommandDialog` palette, Cmd/Ctrl+K + `/` shortcuts, 200ms debounce, grouped results, loading + empty states.
  - `src/components/shared/badges-display.tsx` — reusable pill grid; earned = `bg-club-muted text-club`; unearned faded with `Lock`; optional compact top-3 mode.
- Files modified:
  - `src/components/app-shell.tsx` — search button (desktop + mobile), mounted `<GlobalSearch />` once.
  - `src/components/views/members-view.tsx` — Import CSV button + dialog (template download, results screen); per-member detail Sheet with stats + badges; row click handlers.
- Decisions:
  - SQLite: use plain `contains` (LIKE is ASCII-case-insensitive by default).
  - CSV import: NO auto-user-creation — pending invites collected with the club code so the exec can share it. Avoids password-reset problems.
  - CSV parser: hand-rolled (~60 lines, RFC-4180-ish). No new deps.
  - Badges: computed live, no DB table; endpoint returns stats too.
  - Member detail: right-side `Sheet` (matches Tasks pattern).
  - Design system: `variant="club"`, `bg-club-muted text-club`, `card-quiet`, `text-caption-medium`, `scrollbar-thin`, shared `EmptyState`/`Skeleton`.
- Lint: 0 errors. tsc: 0 errors in my files. Dev log: routes return 403 (expected auth-gate) on first compile; `/` returns 200.
