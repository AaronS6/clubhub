# Task 2D — Verification + Automated Tests

Agent: full-stack-developer (Verification + tests)
Task: Verify the Section-5 "things to verify" actually work, and add `bun test` automated tests for critical flows.

## Plan
1. Read worklog + scan every relevant API route (clubs, hours, members, announcements, tasks, meetings/ics) to internalize behavior.
2. Write `scripts/verify.mjs` — a single Node script that exercises each of the 8 verification items end-to-end against the running dev server.
3. Run verify, fix any API-route bugs revealed.
4. Write `tests/setup.ts` (shared helpers) + 4 test files covering auth, clubs, service-hours, executive-guard.
5. Run `bun test`, `bun run lint`, `bun scripts/verify.mjs` — make sure all green.
6. Append the worklog + write this agent-ctx entry.

## Work Log
- Read worklog + all relevant API route files (`clubs/route.ts`, `clubs/join/route.ts`, `clubs/[clubId]/members/route.ts`, `clubs/[clubId]/regenerate/route.ts`, `clubs/[clubId]/hours/*`, `clubs/[clubId]/meetings/ics/route.ts`, `clubs/[clubId]/announcements/*`, `clubs/[clubId]/tasks/*`).
- Wrote `scripts/verify.mjs` (~580 LOC, plain Node ES modules, run via `bun scripts/verify.mjs`):
  - Cookie-jar fetch with retry-on-ECONNRESET (dev server may briefly hiccup during route compilation).
  - NextAuth credentials login helper (csrf + URL-encoded POST to `/api/auth/callback/credentials`).
  - 8 verification checks, each with PASS/FAIL + reason.
  - Creates two test users + two test clubs (one for checks 1-7, one for check 8 multi-club scoping), then deletes them + their upload directories at the end via a small `bun -e` Prisma cleanup script.
- Initial run revealed 2 real gaps:
  1. `GET /api/clubs/[clubId]/announcements` and `GET /api/clubs/[clubId]/tasks` did NOT support `?includeDeleted=true` for exec recovery — soft-deleted items were invisible forever.
  2. There was no restore endpoint for announcements or tasks.
- Fixed both gaps in the API:
  - Added `?includeDeleted=true` (exec-only) to `announcements/route.ts` GET and `tasks/route.ts` GET.
  - Created `src/app/api/clubs/[clubId]/announcements/[id]/restore/route.ts` (exec-only, unsets `deletedAt`, logs `announcement_restored`).
  - Created `src/app/api/clubs/[clubId]/tasks/[id]/restore/route.ts` (exec-only, unsets `deletedAt`, logs `task_restored`).
  - Added `deletedAt` field to the serialized output of both GET endpoints so the UI can show "deleted" badges on recovered rows.
- Fixed one real bug in the ICS export (`meetings/ics/route.ts`):
  - `descriptionParts.join("\\n")` joined with the 2-char literal `\n` (backslash + n), which `escapeIcs` then DOUBLE-escaped (each backslash became `\\`). The result was `DESCRIPTION:foo\\nbar` (literal `\n` text) instead of `DESCRIPTION:foo\nbar` (the ICS newline escape). Changed to `join("\n")` (actual newline char) so `escapeIcs` produces the correct single-backslash escape sequence.
- Wrote `tests/setup.ts` (shared helpers) + 4 test files using `bun test`:
  - `tests/auth.test.ts` (5 tests): signup creates a User with a bcrypt-hashed password (≥60 chars, ≠ plaintext); 409 on duplicate email; 400 on weak password; correct password yields a NextAuth session; wrong password / non-existent email yield 401 (JSON mode) or 302 (redirect mode), and no session.
  - `tests/clubs.test.ts` (7 tests): create club generates a 6-char alphanumeric code, makes the creator an executive, returns the club in GET; join succeeds with correct code+password (200, role=member); wrong password → 400; wrong code → 404 with "no club found" message; already-a-member → 409.
  - `tests/service-hours.test.ts` (8 tests): submit creates a pending entry owned by the submitter (verified in DB); 400 on hours ≤ 0; 400 on empty reasonText; approve transitions to approved, sets reviewedBy+reviewedAt, nulls proofFileUrl, deletes proof file from disk; 400 on re-review; 403 on non-exec approve; reject transitions to rejected + deletes proof file.
  - `tests/executive-guard.test.ts` (5 tests): demote last exec → 400 with "last executive"; remove last exec → 400 with "last executive"; after promoting a 2nd exec, the first can be demoted; after re-promoting, the first can be removed; non-exec PATCH /members → 403.
- Each test file: unique `RUN_PREFIX` per run; `afterAll` calls `cleanupAll()` which deletes clubs (cascade), users, and orphan upload directories.
- Added `"test": "bun test"` script to `package.json`.

## Verification Results (final run)

```
✓ 1. Image upload + sharp compression — input=83458B → output=10317B (jpg, 1600x1067)
✓ 2. Proof deleted on approve+reject — both approve and reject removed the proof file from disk
✓ 3. Last-executive guard — blocked demote/remove of last exec, then succeeded after 2nd exec promoted
✓ 4. Regenerate code invalidates old — old code → 404, new code (LFS49L) → 200
✓ 5. Bulk approve/reject — 3 entries submitted, 3 approved in one bulk call
✓ 6. ICS export — 10 VEVENTs, RFC-5545 basics OK (CRLF + escaped commas)
✓ 7. Soft-delete recoverable — comment deleted:true; announcement & task hidden by default, restored via restore endpoint + visible with includeDeleted=true
✓ 8. Multi-club scoping — announcements/tasks/hours strictly scoped by clubId — no leakage

8/8 checks passed
```

## Test Results (final run)

```
 25 pass
 0 fail
 69 expect() calls
 Ran 25 tests across 4 files. [9.12s]
```

## Files Created / Modified

### Created
- `scripts/verify.mjs` — verification script (8 checks, runnable via `bun scripts/verify.mjs`).
- `tests/setup.ts` — shared test helpers (CookieJar, req, signup, login, cleanupAll).
- `tests/auth.test.ts` — 5 tests.
- `tests/clubs.test.ts` — 7 tests.
- `tests/service-hours.test.ts` — 8 tests.
- `tests/executive-guard.test.ts` — 5 tests.
- `src/app/api/clubs/[clubId]/announcements/[id]/restore/route.ts` — new restore endpoint (exec-only).
- `src/app/api/clubs/[clubId]/tasks/[id]/restore/route.ts` — new restore endpoint (exec-only).

### Modified
- `src/app/api/clubs/[clubId]/announcements/route.ts` — GET supports `?includeDeleted=true` (exec-only); serialized items now include `deletedAt`.
- `src/app/api/clubs/[clubId]/tasks/route.ts` — GET supports `?includeDeleted=true` (exec-only); serialized tasks now include `deletedAt`.
- `src/app/api/clubs/[clubId]/meetings/ics/route.ts` — fixed double-escaping of newlines in the DESCRIPTION field.
- `package.json` — added `"test": "bun test"` script.

## Stage Summary
- All 8 verification checks pass. The script can be re-run independently (it cleans up after itself — no permanent test data is left in the dev DB).
- All 25 tests pass across 4 files. Tests require the dev server running on `http://localhost:3000` (the sandbox auto-starts it). The tests are isolated: each uses a unique `RUN_PREFIX` and cleans up everything it creates via direct Prisma access.
- 2 API route bugs fixed:
  1. **Missing recovery path for soft-deleted announcements & tasks** — added `?includeDeleted=true` query param to the GET routes (exec-only) and new POST `restore` endpoints.
  2. **ICS DESCRIPTION double-escaping** — `descriptionParts.join("\\n")` was joining with a literal 2-char `\n`, which `escapeIcs` then escaped again to `\\n`. Switched to `join("\n")` (actual newline) so `escapeIcs` produces the correct single-backslash escape sequence.
- `bun run lint` passes (0 errors, 0 warnings).
