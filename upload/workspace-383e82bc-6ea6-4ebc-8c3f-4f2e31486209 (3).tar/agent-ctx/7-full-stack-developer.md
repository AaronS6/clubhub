# Task 7 — full-stack-developer (Teams + Members)

## Task
Build the **Teams + Members** module for the ClubHub platform. Backend: teams API routes (list, create, update, delete, add/remove team member). Frontend: `TeamsView` and `MembersView` view components. The members GET/PATCH route already exists — consume it from the frontend.

## What was built

### Backend — new API routes
- `src/app/api/clubs/[clubId]/teams/route.ts`
  - `GET` — lists teams with members (id, userId, joinedAt, user{id,name,avatarUrl}), task list (id, title, status, dueDate, assignee), upcoming meetings (startTime >= now), and counts (memberCount, taskCount, upcomingMeetingCount).
  - `POST` — exec only. Body `{ name, description? }`. Validates name (1–80 chars), description (≤1000 chars). Logs `team_created`. Best-effort notifies other club members with type `new_team`.
- `src/app/api/clubs/[clubId]/teams/[teamId]/route.ts`
  - `PATCH` — exec only. Updates name and/or description (same validation). Logs `team_updated`.
  - `DELETE` — exec only. Deletes the team. Cascade removes team_members; tasks/meetings get `teamId` set null (per schema's onDelete: SetNull). Logs `team_deleted`.
- `src/app/api/clubs/[clubId]/teams/[teamId]/members/route.ts`
  - `POST` — exec only. Body `{ userId }`. Validates the target user is an active club member. Guards the `@@unique([teamId, userId])` with a friendly error. Logs `team_member_added`. Notifies the added user (type `team_member_added`).
- `src/app/api/clubs/[clubId]/teams/[teamId]/members/[userId]/route.ts`
  - `DELETE` — exec only. Removes a user from the team. Logs `team_member_removed`.

### Backend — bug fix
- `src/app/api/clubs/[clubId]/members/route.ts` GET was broken: it tried `include: { teams: { include: { team: … } } }` on `ClubMember`, which has no `teams` relation in the Prisma schema. Fixed by querying `teamMember.findMany({ where: { team: { clubId } } })` separately and grouping by userId. The response shape is unchanged: `{ membershipId, role, joinedAt, user{…}, teams[{id,name}], approvedHours, myUserId, myRole }`. The PATCH (promote/demote/remove with last-executive guard) was untouched.

### Frontend — `src/components/views/teams-view.tsx` (`TeamsView`)
- Reads `currentClubId` + role from `useAppStore`.
- Responsive 3-col grid of team Cards with avatar stack (max 5 + "+N"), task count, upcoming meeting count, member count. Card is `role="button"` with keyboard support.
- Per-card dropdown (exec only): Edit / Delete.
- Click → right-side Sheet with: header (name/description/created-relative), Roster (avatars, names, joined-relative, remove button per member — exec only), Tasks list (title + assignee avatar + due date + status badge), Upcoming meetings list (title + date/time + location).
- "Add members" dialog: searchable multi-select of club members not already on the team; sequential bulk add; success/failure count in toast; invalidates both `teams` and `members` queries.
- "New team" dialog (exec): name + description form.
- Edit dialog (exec): prefilled form.
- Delete dialog (exec): AlertDialog confirm.
- Loading skeletons, error retry, empty state (exec sees Create CTA).
- All icon buttons have `aria-label`s.

### Frontend — `src/components/views/members-view.tsx` (`MembersView`)
- Reads `currentClubId` + role from `useAppStore`.
- PageHeader with "Leave club" button (always available to current user; AlertDialog confirm).
- "Club code & password" Card (exec only): shows the join code in a mono pill, "Copy code" button (clipboard API), "Regenerate code" button hits `/api/clubs/[clubId]/regenerate` and patches the store + clubs list.
- Search input filters by name/email.
- Desktop: shadcn Table inside a Card. Columns: Member (avatar+name+bio+email), Email, Role (RoleBadge), Teams (pills), Approved hours (right-aligned tabular-nums), Joined (relativeTime), Actions (exec-only dropdown).
- Mobile: stacked Cards with a 2-col grid (hours, joined) + teams pills + inline Promote/Demote/Remove buttons.
- Exec actions: Promote to executive / Demote to member (server's last-executive guard surfaces as toast on failure), Remove from club (AlertDialog confirm).
- Self-row hides the per-member actions menu (Leave is the only self-removal path).
- Loading skeletons (table + mobile), error retry, empty states (no members / no search matches).

## Patterns used (matching Task 1 conventions)
- `getClubContext(clubId)` for auth + role checks; `json()` / `error()` helpers.
- Exec guard: `if (c.membership.role !== "executive") return error("Executives only", 403)`.
- `logActivity({ clubId, actorUserId, actionType, targetType, targetId, description })`.
- Frontend: TanStack Query for server state, `api()` from `@/lib/api/client`, `useAppStore` for current club, `sonner` toast, shadcn/ui components, `cn()` from `@/lib/utils`, shared `PageHeader`/`RoleBadge`/`EmptyState`/`initials`/`relativeTime` from `@/components/shared/page-header`.
- `'use client'` directives at the top of every view.
- All API requests use relative paths only.

## New activity log action types introduced
- `team_created`
- `team_updated`
- `team_deleted`
- `team_member_added`
- `team_member_removed`

## New notification type introduced
- `new_team` (best-effort fan-out on team creation)
- `team_member_added` (best-effort notify the added user)

## Lint / type status
- `bun run lint` → exit 0.
- TypeScript errors only in pre-existing files (ZodError `.errors` in signup/clubs/meetings routes, hours-view generic arg, skills + examples folders) — none in any file this task created or modified.

## Dev log
- `tail -30 /home/z/my-project/dev.log` shows only 200s on `/`. No compile/runtime errors.

## Notes for downstream agents
- The `GET /api/clubs/[clubId]/teams` response now includes per-team `tasks` and `upcomingMeetings` arrays (plus the counts). If you build a tasks/meetings view that needs to be filtered by team, you can reuse this endpoint or extend the team detail sheet.
- The members route now correctly returns `teams: [{ id, name }]` per member. The Teams tab and Members tab both invalidate each other's queries on roster mutations, so the UI stays in sync.
- The "Club code & password" Card in MembersView only displays the code (passwords are hashed and never exposed). The regenerate button only rotates the code, matching the existing `/regenerate` API.
