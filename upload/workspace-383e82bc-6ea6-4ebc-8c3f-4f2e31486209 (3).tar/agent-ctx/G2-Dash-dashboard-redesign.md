# G2-Dash — Dashboard Bento-Grid Redesign

## Task
Rebuild the ClubHub dashboard view (`src/components/views/dashboard-view.tsx`) as a **bento-grid** with 3 information tiers, replacing the previous vertically-stacked ~10-section layout. Keep the existing `/api/clubs/[clubId]/dashboard` API and `["dashboard", clubId]` TanStack Query key — only the frontend layout changes.

## What changed
- **One file**: `src/components/views/dashboard-view.tsx` (replaced, ~1134 lines).
- **No backend changes**. **No design-system / globals.css changes**. **No other views touched**.

## New layout structure
- **Row 1** — slim hero bar (accent stripe + avatar tile + name + role badge + "{n} members · joined {Mon YYYY}").
- **Row 2** — Tier 1 "Needs your attention":
  - Brand-new club → dismissible onboarding banner (REPLACES Tier 1, persisted in `localStorage` under `onboarding-dismissed-<clubId>`).
  - Otherwise → horizontal strip of compact action cards (each with `border-l-2 border-l-club` accent): pending approvals (exec only, > 0), my pending hours (> 0), tasks due soon/overdue (lists 2–3 inline; red dot + `border-l-red-500` for overdue), pinned announcements (1–2 inline).
  - If nothing needs attention → single full-width "You're all caught up" card (section stays visible).
- **Rows 3+4** — 12-col grid (mobile re-ordered via `order-*` so snapshot surfaces first on mobile):
  - Desktop row 1: hours trend chart (8 cols, Tier 3, accent fill + muted CartesianGrid) + leaderboard (4 cols, Tier 3, gold/silver/bronze rank badges, clickable rows → members view).
  - Desktop row 2: your snapshot (4 cols, Tier 2 — approved hours + Progress to `bg-club`, X open / Y done, next 2–3 meetings) + recent announcements (4 cols, Tier 3) + upcoming meetings (4 cols, Tier 3).
- **Row 5** — "Club at a glance" — 4-up clickable mini-stats (members / total hours / open tasks / upcoming meetings).
- **Row 6 (execs only)** — "Executive insights" — 6-up compact strip (pending approvals [urgent-tinted, clickable] / avg turnaround / completion rate / submissions/wk / announcements/mo / teams) — denser than the prior 3-col 6-card grid.

## Key implementation notes
- Mobile (375px) priority order: onboarding banner → Tier 1 → snapshot (Tier 2) → chart → leaderboard → announcements → meetings → club stats → exec insights. Achieved with `order-1`..`order-5` on the Rows 3+4 grid children + `lg:order-*` to revert on desktop.
- Staggered entrance: every section uses `animate-fade-in` + inline `animationDelay: i*50ms` + `animationFillMode: "backwards"` via a `stagger(i)` helper.
- `Progress` indicator overridden to `bg-club` via `[&_[data-slot=progress-indicator]]:bg-club` so it picks up the per-club accent (default `bg-primary` would have stayed static emerald).
- Chart `CartesianGrid` uses `hsl(var(--border))` dashed thin gridlines (design-system-aligned, dark-mode-safe).
- `localStorage` read for onboarding dismiss state is deferred to a microtask (`Promise.resolve().then(...)`) with a cancellation guard — mirrors the pattern in `src/lib/use-realtime-sync.ts` to satisfy the `react-hooks/set-state-in-effect` lint rule.
- Rebuilt `DashboardSkeleton` to mirror the new bento layout (hero bar + Tier 1 4-up + chart/leaderboard + snapshot/announcements/meetings + club stats).
- Clickable elements use `useAppStore.getState().setView("members" | "tasks" | "hours" | "approvals" | "announcements" | "meetings" | "teams")`.

## Accent coverage (all driven by `--club-accent` from `ClubAccentProvider`)
- Hero stripe + avatar tile (`bg-club`)
- Tier 1 card left borders (`border-l-club`)
- Chart stroke + gradient fill (`var(--club-accent)`)
- Progress bar fill (`bg-club` via child selector)
- Leaderboard rank-1 highlight (`ring-club/20 bg-club-muted/30`)
- Task "upcoming" dot (`bg-club`)
- Member role badge pill (`text-club border-club/30 bg-club-muted`)
- Snapshot/chart header icons (`text-club`)

## Verification
- `bun run lint` — clean (0 errors, 0 warnings).
- `tail dev.log` — recent `GET / 200` responses; no runtime errors attributable to the dashboard.
- Dark-mode-safe (chart colors, card borders, Tier 1 accent treatment all use CSS vars with explicit `dark:` variants on tinted elements).
- Mobile responsive at 375px (chart container is `h-56 w-full min-w-0`, can't overflow).

## Patterns used
- `useAppStore` for currentClubId/currentClub/setView.
- `api()` for the dashboard fetch.
- TanStack Query `useQuery({ queryKey: ["dashboard", clubId], staleTime: 30_000 })` — realtime invalidation handled by `useRealtimeSync` mounted in AppShell.
- shadcn `Avatar`, `Button`, `Progress`, `Separator`, `Badge` + lucide icons + recharts `AreaChart`/`CartesianGrid`.
- Shared `EmptyState`, `StatCardSkeleton`, `initials`, `relativeTime`, `avatarColor` from `@/components/shared/page-header`.
- `cn()`, `card-quiet`, `chip-approved/pending/rejected`, `bg-club-muted`, `text-club`, `animate-fade-in` from the F1 design system.
