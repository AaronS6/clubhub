# Work record — Task G2-Chat (Group Chat module)

**Agent:** full-stack-developer (Group Chat)
**Task ID:** G2-Chat
**Task:** Build the Group Chat module for ClubHub — backend API routes + ChatView frontend.

## Files created / modified

### Backend (`src/app/api/clubs/[clubId]/chat/`)
1. `conversations/route.ts` — GET (list + bootstrap club-wide) + POST (create group/direct, idempotent for existing direct chats).
2. `conversations/[conversationId]/route.ts` — PATCH (rename group, owner/exec).
3. `conversations/[conversationId]/messages/route.ts` — GET (paginated 50/page with `?before`/`?after`, marks read on latest fetch) + POST (rate-limited 30/min/user/conv, notifications, emits `chat_message`).
4. `conversations/[conversationId]/messages/[messageId]/route.ts` — PATCH (author edits, sets editedAt) + DELETE (author/owner/exec soft-delete).
5. `conversations/[conversationId]/messages/[messageId]/reactions/route.ts` — POST toggle/swap with fixed emoji set.
6. `conversations/[conversationId]/messages/[messageId]/pin/route.ts` — PATCH (owner/exec only) sets/clears pinnedAt.
7. `conversations/[conversationId]/members/route.ts` — POST (owner/exec add member to group).
8. `conversations/[conversationId]/members/[userId]/route.ts` — DELETE (self/owner/exec; promotes new owner on owner-leave; hard-deletes empty non-club-wide conversations).
9. `conversations/[conversationId]/pinned/route.ts` — GET returns pinned messages for the bar.

### Lib
- `src/lib/rate-limit.ts` — in-memory rolling-window counter (30 msg/min/user/conversation).
- `src/lib/notif-prefs.ts` — added `chat_message` to `NotifType`, `ALL_NOTIF_TYPES`, `NOTIF_TYPE_META`, and default prefs (email=false, in-app=true).
- `src/lib/email-notifications.ts` — added `chat_message` to `EMAIL_TYPES` + `buildSubject` + `buildBody`.

### Frontend
- `src/components/views/chat-view.tsx` — named `ChatView` export, no props. Full split-pane desktop + mobile full-screen chat UI (~2160 LOC).

## Patterns / conventions followed

- `getClubContext` for club auth + role.
- Per-conversation membership check via `db.conversationMember.findUnique({ where: { conversationId_userId: ... } })`.
- `emitClubEvent(clubId, "chat_message", { conversationId })` after every mutation.
- `useRealtimeSync` (mounted in AppShell) invalidates `["conversations", clubId]` + `["messages", clubId]` keys on `chat_message` events.
- `usePresence(clubId)` powers online dots on DM rows + the header avatar + the members dropdown.
- React 19 lint-compliant: avoided `setState`-in-effect cascades by giving the club-scoped inner component a `key={clubId}` prop so React auto-resets state on club switch; same pattern for `ConversationPane` keyed by conversation ID.

## Decisions

1. **Club-wide conversation auto-bootstrap**: every GET to `/conversations` checks for a club-wide conversation and creates one (with all active members seeded) if missing. Also handles new members who joined the club after the conversation was created.
2. **Direct chat idempotency**: POST with `type: "direct"` returns the existing conversation if one already exists between the two users in this club (looked up via two ConversationMember queries intersected in-memory).
3. **Notifications**:
   - Direct/group chats: notify all other members (excluding author) on every new message.
   - Club-wide chats: only notify members whose `lastReadAt === joinedAt` (i.e. have never opened the conversation). Once they GET messages, `lastReadAt` is updated to `now()` and they won't be notified again on subsequent messages — they're "subscribed" via realtime.
4. **Rate limit**: in-memory `Map<key, Bucket>` with rolling 60s window, pruned lazily on each call. 429 responses include `Retry-After` header.
5. **Soft-delete**: preserves the message row so reply chains / reaction counts stay intact; UI renders "[message deleted]" muted italic.
6. **Owner-leave**: promotes the longest-tenured remaining member to owner (group only). When the last member leaves a non-club-wide conversation, hard-deletes the messages and conversation.
7. **Mobile UX**: full-screen single panel — conversation list collapses to show messages, with a back button to return. Achieved via Tailwind `hidden md:flex` toggling based on local `isMobileShowingMessages` state.
8. **Message pagination**: `useQuery` for the latest 50 messages + local state array for prepended older pages, deduped by message ID. Auto-scroll-to-bottom when user is pinned to bottom; "Load older" affordance on scroll-up preserves scroll position.
9. **`skipDuplicates` workaround**: Prisma SQLite's TypeScript types didn't allow `skipDuplicates: true` on `createMany` for `ConversationMember` even with the unique constraint — replaced with a try/catch loop (idempotent).

## Verification

- `bun run lint` → 0 errors, 0 warnings in authored files.
- `bunx tsc --noEmit` → no errors in authored files (only pre-existing errors in unrelated modules).
- Dev log shows 200s on `/`; no compile errors for the new chat routes.

## Patterns for downstream agents

- The `chat_message` notif type is now registered end-to-end (in-app + email). Other modules that want to fan out a similar message-passing notification can follow the same pattern: add to `NotifType` union + `ALL_NOTIF_TYPES` + `NOTIF_TYPE_META` + default prefs, and add to `EMAIL_TYPES` + `buildSubject`/`buildBody` if email-eligible.
- The `rateLimit(key, limit, windowMs)` helper in `src/lib/rate-limit.ts` is reusable for any per-user-per-resource rate limiting (returns `{ ok: true }` or `{ ok: false, retryAfterMs }`).
- Pattern for "reset component state when prop changes": don't use `useEffect` + `setState`; instead delegate to an inner component with a `key` prop so React remounts and resets state automatically.
