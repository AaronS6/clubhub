# Task 8 — Dashboard + Activity Log module (full-stack-developer)

## Task
Build the Dashboard + Activity Log views and supporting aggregating API for the ClubHub multi-club management platform. Two frontend view components (`DashboardView`, `ActivityView`) plus three GET API routes that aggregate stats directly from the existing Prisma tables.

## Plan
1. Read `worklog.md` + existing patterns (server-auth, activity, store, api client, page-header, app-shell, schema, members route).
2. Backend routes (direct Prisma queries):
   - `GET /api/clubs/[clubId]/dashboard` — one-shot overview: club info + memberCount, myRole, myStats, clubStats, top-5 leaderboard, recent announcements, my open tasks, upcoming meetings with my RSVP, 30-day approved-hours trend (recharts area chart), and exec-only `execStats` (avg approval turnaround, submissions this week, task completion rate).
   - `GET /api/clubs/[clubId]/activity` — exec-only, paginated `?page=&pageSize=50`, optional `?actionType=` filter. Returns `{ items, hasMore, total, page, pageSize }` with actor info joined.
   - `GET /api/clubs/[clubId]/leaderboard` — `?range=thisMonth|thisSemester|allTime` + optional `?teamId=`. Returns `{ items: [{ userId, name, avatarUrl, hours, tasksDone, meetingsAttended }] }` sorted by hours desc.
3. Frontend:
   - `dashboard-view.tsx` — hero with accent stripe + logo/name/description/joined date; 4 stat cards row (Approved Hours w/ progress toward hoursGoal, Open Tasks, Upcoming Meetings, Pending Submissions); 4 mini club-overview cards (Total Members, Approved Hours, Open Tasks, Upcoming Meetings); exec Insights card; onboarding checklist for brand-new clubs; 30-day AreaChart trend (club accent color) + leaderboard card (rank badges 1/2/3); 3-column row of My Tasks / Upcoming Meetings / Recent Announcements. All TanStack Query, loading skeleton, toast on error.
   - `activity-view.tsx` — exec-only gate (member sees "Executives only" empty state); action-type Select filter with full action catalog (club_created, new_member, promote, demote, member_removed, hours_submitted, hours_approved, hours_rejected, new_announcement, task_assigned, task_created, task_completed, meeting_created, meeting_cancelled, team_created, club_updated, code_regenerated); vertical timeline list with actor avatar + name + colored action badge + description + relative time + "Latest" indicator on first entry; `useInfiniteQuery` + "Load more" button.
4. `bun run lint`, fix my errors, check `tail -30 dev.log`, append worklog.

## Patterns followed
- Auth: `getClubContext(clubId)` returns `{user, membership, club}`; `c.membership.role !== "executive"` for exec-only.
- Responses: `json(data)` / `error(msg, status)` from `@/lib/server-auth`.
- Direct Prisma aggregation via `db.*` (no dependency on other modules' APIs).
- Client: `api()` from `@/lib/api/client`; `useAppStore` for currentClubId/role.
- shadcn/ui: card, button, progress, badge, skeleton, scroll-area, avatar, select.
- `EmptyState`, `StatusBadge`, `initials`, `relativeTime` from `@/components/shared/page-header`.
- recharts `AreaChart` with club-accent gradient for the hours trend.
- date-fns `format`, `isPast`, `isToday`, `parseISO` for date handling.
- TanStack Query `useQuery` + `useInfiniteQuery` with proper `enabled` gating.

## Files created/modified
- NEW `src/app/api/clubs/[clubId]/dashboard/route.ts`
- NEW `src/app/api/clubs/[clubId]/activity/route.ts`
- NEW `src/app/api/clubs/[clubId]/leaderboard/route.ts`
- OVERWRITE `src/components/views/dashboard-view.tsx`
- OVERWRITE `src/components/views/activity-view.tsx`

## Decisions
- Dashboard pulls everything in one round-trip to keep the UI snappy (single `useQuery` key `["dashboard", clubId]`, 30s staleTime). Sub-modules' list APIs are NOT called from the dashboard; the dashboard reads the DB directly. This means the dashboard is always consistent with the data even if a sub-module API shape changes.
- 30-day trend is built server-side by bucketing `serviceHour.dateOfService` into 30 daily slots; the frontend only renders. Keeps the client lightweight.
- Exec stats: `avgApprovalTurnaroundHours` averaged over the last 200 reviewed entries (bounded for performance). `taskCompletionRate = round(tasksDone / (openTasks + tasksDone) * 100)`.
- Onboarding checklist triggers when `isExec && memberCount < 3 && teamsCount === 0 && recentAnnouncements.length === 0`. Items are clickable to navigate to the relevant view; share-club-code is shown inline.
- Activity timeline: vertical line + avatar bullet for a clean chronology; first entry gets a "Latest" indicator. Color-coded action badges via an `ACTION_META` map.
- `useInfiniteQuery` for activity log pagination (cleaner than manual page state). `fetchNextPage` driven by a "Load more" button.
- All cards use proper `p-4`/`p-6` padding, `gap-4`/`gap-6` spacing per UI rules; long lists wrapped in `ScrollArea` with `max-h-72`/`max-h-96`.
- Accent color applied tastefully: hero stripe + gradient bg, stat card top bar, icon tint, chart stroke/area. Text remains on default foreground for readability.

## Verification
- `bun run lint` passes with 0 errors and 0 warnings on my files.
- `bunx tsc --noEmit --skipLibCheck` reports 0 errors in my files (other agents' files have unrelated ZodError/import errors).
- dev.log shows clean 200 responses for `/`.
