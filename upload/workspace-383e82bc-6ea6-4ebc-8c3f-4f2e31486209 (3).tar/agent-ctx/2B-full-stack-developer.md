# Task 2B — Email Notifications + Notification Preferences UI

## What was built

1. **`src/lib/notif-prefs.ts`** — typed prefs schema + helpers:
   - `NotifType` union (7 types: hours_approved, hours_rejected, task_assigned,
     new_comment, new_reaction, meeting_reminder, new_announcement).
   - `NotifPrefs` interface (`{ email, emailMode, inApp }`).
   - `ALL_NOTIF_TYPES`, `NOTIF_TYPE_META` (label + description for UI).
   - `getDefaultPrefs()` — email defaults: new_reaction off, new_announcement
     off (low signal / noisy); all others on. inApp all on.
   - `normalizePrefs(raw)` — merges stored prefs over defaults (handles
     missing fields, wrong types, legacy keys, completely invalid JSON).
   - `parsePrefsString(raw)` — parse the JSON string from DB.
   - `isEmailEnabled(prefs, type)` / `isInAppEnabled(prefs, type)` predicates.
   - `mergePrefs(current, patch)` — deep-merge a partial patch; drops unknown
     keys; returns a fully-normalized prefs object.

2. **`src/lib/email.ts`** — Resend wrapper + email template:
   - `sendEmail({ to, subject, html })` — uses Resend SDK. Reads
     `process.env.RESEND_API_KEY`. If missing/empty: logs a warning in
     non-production and returns `{ ok: false, reason: "RESEND_API_KEY not configured" }`
     (NO throw — graceful no-op).
   - `getFromAddress()` — `process.env.EMAIL_FROM` or
     `ClubHub <onboarding@resend.dev>` (Resend's sandbox sender, default).
   - `isEmailConfigured()` — convenience predicate.
   - `renderEmailHtml({ title, preheader, bodyLines, ctaText?, ctaUrl?, clubName? })`
     — responsive inline-CSS HTML email (max-width 560px, emerald header
     accent, body paragraphs, optional CTA button, footer with club name +
     year). HTML-escapes all user content.

3. **`src/lib/email-notifications.ts`** — bridges in-app → email:
   - `EMAIL_TYPES` set + `shouldTryEmail(type)` predicate for callers that
     want to short-circuit fan-out for non-emailable types.
   - `sendEmailNotification({ userId, type, message, linkUrl?, clubName? })`:
     1. Skips silently if type isn't in EMAIL_TYPES.
     2. Loads user (email + name + notifPrefs) from DB.
     3. Parses prefs; skips silently if `prefs.email[type] === false`.
     4. If `prefs.emailMode === "digest"`: logs "queued for digest" and
        returns (digest is a separate scheduled concern).
     5. Otherwise builds type-appropriate subject + body and calls sendEmail.
   - All errors swallowed (best-effort, never breaks the caller).
   - `buildSubject()` / `buildBody()` — per-type subject lines and body copy.
   - `resolveCtaUrl()` — allows http(s):// or `/`-prefixed paths; absolute
     URLs are made full using NEXTAUTH_URL if set.

4. **`src/lib/activity.ts`** — wired email into existing helpers
   (drop-in addition, no behavior change to existing callers):
   - `notify()` now calls `fireEmailNotification()` fire-and-forget after
     the in-app row + realtime push, but only if `shouldTryEmail(type)`.
   - `notifyClub()` similarly calls `fireEmailNotificationForClub()` after
     the existing fan-out. Looks up club name ONCE before fanning out emails.
   - Both fire-and-forget paths use an inner async IIFE with
     `.catch(console.error)` so the outer promise never rejects.
   - The `shouldTryEmail` guard skips the entire email path (no DB
     lookups, no fan-out) for non-emailable types like `new_announcement`.

5. **`src/app/api/me/notifications/preferences/route.ts`** — REST API:
   - `GET` — returns `{ prefs, email }` where prefs is the normalized object.
   - `PATCH` — accepts `{ email?, inApp?, emailMode? }` partial patch;
     merges over existing via `mergePrefs`; saves back as JSON string;
     returns the normalized `{ prefs, email }`.
   - Uses `z.record(z.string(), z.boolean())` (not enum-keyed) so partial
     patches with only some keys work; unknown keys are filtered by
     `mergePrefs` (silently dropped).
   - Auth via `getSessionUser()` — 401 if no session.

6. **`src/components/app-shell.tsx`** — `SettingsDialog` upgraded:
   - Converted from scrollable single-form to `Tabs`-based dialog with
     three tabs: **Profile** | **Notifications** | **Security**.
   - New `NotificationsTab` component:
     - Loads prefs on mount via `GET /api/me/notifications/preferences`.
     - "Email delivery" radio card group (Instant | Daily digest) using
       `RadioGroup` + custom-styled labels with accent highlight on the
       active option.
     - "Email notifications" section: row per notif type with label +
       description + `Switch` toggle.
     - "In-app notifications" section: same layout (compact, label only).
     - Note line shows "Emails are sent to {user.email}".
     - Save button (variant="club") PATCHes the full prefs object back;
       toast on success/error.
   - Existing Profile + Password sections preserved as separate tabs; all
     save buttons use `variant="club"` per the new design system.

7. **`.env`** — added:
   ```
   RESEND_API_KEY=
   EMAIL_FROM=ClubHub <onboarding@resend.dev>
   ```
   Both with explanatory comments about the sandbox sender and how to
   upgrade to a verified domain.

## Environment / how to enable email

| Variable         | Required? | Default                              | Notes |
|------------------|-----------|--------------------------------------|-------|
| `RESEND_API_KEY` | optional  | (unset)                              | Get from https://resend.com/api-keys. Without it, `sendEmail` is a graceful no-op (logs a warning in non-production). |
| `EMAIL_FROM`     | optional  | `ClubHub <onboarding@resend.dev>`   | Resend's sandbox sender only delivers to your own account's verified email. Set to `ClubHub <noreply@yourdomain.com>` after verifying your domain in Resend. |

## What happens when email is NOT configured

- `sendEmail()` returns `{ ok: false, reason: "RESEND_API_KEY not configured" }` immediately (no API call to Resend).
- A warning is logged in non-production: `[email] RESEND_API_KEY is not set — skipping email send to <email> (subject: <subj>)`.
- The triggering API request (hours approval, task assignment, etc.) returns normally — the in-app notification + realtime push still happen.
- User-facing flows are completely unaffected.

## Files created / modified

**Created:**
- `src/lib/notif-prefs.ts`
- `src/lib/email.ts`
- `src/lib/email-notifications.ts`
- `src/app/api/me/notifications/preferences/route.ts`

**Modified:**
- `src/lib/activity.ts` — wired in fire-and-forget email fan-out
- `src/components/app-shell.tsx` — SettingsDialog → Tabs + NotificationsTab
- `.env` — added RESEND_API_KEY + EMAIL_FROM

## Verification

- `bun run lint` — passes (exit 0).
- `bunx tsc --noEmit --skipLibCheck` — no errors in any of my files (pre-existing errors in other agents' files unchanged).
- Smoke-tested with bun:
  - `sendEmail()` with no key → graceful no-op + warning log + returns `{ ok: false }`.
  - `renderEmailHtml()` produces correct HTML containing title, CTA, club name.
  - `getDefaultPrefs()` returns the expected defaults.
  - `parsePrefsString(null/garbage/{})` all return normalized defaults (no throw).
  - `parsePrefsString(stored)` correctly merges overrides with defaults.
  - `mergePrefs(current, partial)` correctly applies patches and ignores unknown keys.
  - `sendEmailNotification(nonexistent user)` → no throw, silent return.
  - `sendEmailNotification(new_announcement)` → silent skip without DB lookup.
  - `notify({ type: "hours_approved" })` → triggers the email path (logs "[email] RESEND_API_KEY is not set").
  - `notify({ type: "new_announcement" })` → skips email entirely (no log, no DB lookup).
  - `notifyClub({ type: "task_assigned" })` → fans out email to each member.
  - `notifyClub({ type: "new_announcement" })` → skips entire email fan-out path.
- End-to-end via curl:
  - `GET /api/me/notifications/preferences` (authenticated) → returns normalized defaults.
  - `PATCH` with partial override (`hours_approved: false, new_reaction: true, emailMode: digest`) → applies correctly, other keys preserved.
  - `PATCH` with unknown keys → silently dropped, prefs unchanged.
  - `PATCH` with invalid `emailMode: "weekly"` → rejected with 400 "Invalid preferences payload".
  - `GET` after PATCH → persisted values confirmed.
- Dev server log: clean 200s on `/`, no compile errors in my new files. The Next.js dev server briefly restarted (likely due to file changes), recovered cleanly.

## Key decisions

- **`z.record(z.string(), z.boolean())`** for the PATCH body, not enum-keyed — zod v4's `z.record(z.enum(...), z.boolean())` requires ALL enum keys to be present, rejecting partial patches. The `mergePrefs` helper already filters unknown keys, so accepting any string→boolean map here lets clients send minimal partial patches.
- **`shouldTryEmail(type)` guard at the activity layer** — for `notifyClub` of `new_announcement`, we'd otherwise do 1 (club lookup) + N (user lookup per member) DB queries just to no-op each one. The guard skips the entire fan-out, saving those queries.
- **Fire-and-forget via inner async IIFE + `.catch(console.error)`** — the outer promise resolves immediately so the triggering API request is never blocked; the inner promise logs any error but never propagates.
- **Club name lookup happens ONCE per fan-out** (in `fireEmailNotificationForClub`), not per member — minimizes DB load for large clubs.
- **Tabs layout for SettingsDialog** (Profile | Notifications | Security) instead of one long scroll — cleaner UX, lets the Notifications tab have its own scroll area when expanded.
- **Email defaults: new_reaction OFF, new_announcement OFF** — reactions are low-signal ("someone 👍'd your post") and clubs post many announcements (noisy). User can re-enable either from the UI.
- **Resend sandbox sender as default `EMAIL_FROM`** — lets you actually receive a test email to your own account's email without verifying a domain. Documented in the code comment + .env.
