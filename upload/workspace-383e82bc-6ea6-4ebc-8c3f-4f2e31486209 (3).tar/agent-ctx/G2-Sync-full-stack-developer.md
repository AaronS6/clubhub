# G2-Sync — Realtime sync + password UI + task polish

## Summary
- Wired `emitClubEvent(clubId, type, data?)` into 24 mutation paths across 17 API route files (tasks/announcements/meetings/hours/teams/members + join/leave/import/restore).
- Added the exec-only club-password visibility UI in `members-view.tsx`: show/hide eye toggle (fetches decrypted plaintext on demand from `/api/clubs/[clubId]/password`), Copy password button, and a Change-password dialog with live 4–60 char validation + amber warning.
- Polished task delete: `tasks/[id]/route.ts` DELETE now allows exec OR assignee; `tasks/[id]/restore/route.ts` (already existed) loosened from exec-only to exec-OR-assignee and emits `task_updated`; subtask DELETE loosened to any club member (checklist semantics); `tasks-view.tsx` shows a `sonner` Undo toast (5s) that calls the restore endpoint.
- Added an approvals-viewing indicator chip in `approvals-view.tsx` using `useViewingIndicator` + `useViewingCount` ("1 other viewing" / "N others viewing") so two execs don't double-review.
- Added presence dots (`bg-emerald-500 ring-2 ring-background`) on member avatars in Members view (desktop row + mobile card + detail sheet) and Teams view (card stack + roster sheet) via `usePresence(clubId)`.

## Files modified
- API (17): `tasks/route.ts`, `tasks/[id]/route.ts`, `tasks/[id]/restore/route.ts`, `tasks/[id]/subtasks/route.ts`, `tasks/[id]/subtasks/[subtaskId]/route.ts`, `tasks/[id]/comments/route.ts`, `tasks/[id]/comments/[commentId]/route.ts`, `announcements/route.ts`, `announcements/[id]/route.ts`, `announcements/[id]/reactions/route.ts`, `announcements/[id]/comments/route.ts`, `announcements/[id]/comments/[commentId]/route.ts`, `announcements/[id]/restore/route.ts`, `meetings/route.ts`, `meetings/[id]/route.ts`, `meetings/[id]/rsvp/route.ts`, `hours/route.ts`, `hours/[hourId]/route.ts`, `hours/bulk-review/route.ts`, `teams/route.ts`, `teams/[teamId]/route.ts`, `teams/[teamId]/members/route.ts`, `teams/[teamId]/members/[userId]/route.ts`, `members/route.ts`, `members/import/route.ts`, `leave/route.ts`, `clubs/join/route.ts`. (Some files count multiple mutations.)
- Frontend (4): `members-view.tsx`, `tasks-view.tsx`, `approvals-view.tsx`, `teams-view.tsx`.

## Verification
- `bun run lint` → 0 errors, 2 warnings (both pre-existing in `chat-view.tsx`, untouched).
- `tail -30 dev.log` → `/` returns 200 ~30ms; modified routes recompiled cleanly.
- Worklog appended at the bottom of `worklog.md` with full Task G2-Sync entry.
