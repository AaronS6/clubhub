# Task 4 — Announcements module (full-stack-developer)

## Task
Build the Announcements module (feed + reactions + comments) for ClubHub:
- Backend API routes under `src/app/api/clubs/[clubId]/announcements/`
- Frontend `AnnouncementsView` (named export, no props) overwriting the stub at `src/components/views/announcements-view.tsx`

## Plan
1. Read worklog + existing patterns (server-auth, activity, store, api client, page-header).
2. Backend routes:
   - `route.ts` — GET (list, pinned-first then reverse-chron, 20/page, with author + reaction counts + myReaction + commentCount; exclude soft-deleted; `{ items, hasMore, page }`) and POST (exec-only, body `{ title, body, isPinned? }`; notifyClub `new_announcement` exclude author; logActivity).
   - `[id]/route.ts` — PATCH (author or exec, update title/body/isPinned; only exec can toggle isPinned) and DELETE (exec only, soft-delete `deletedAt = now`).
   - `[id]/reactions/route.ts` — POST `{ emoji }`; one reaction per user per announcement (`@@unique([announcementId, userId])`): same emoji -> remove, different -> swap, none -> create; notify author `new_reaction` (excludes reactor).
   - `[id]/comments/route.ts` — GET (list asc by createdAt, soft-deleted -> `{ deleted: true, ... }`) and POST `{ body }` (notify author `new_comment`, exclude commenter; logActivity).
   - `[id]/comments/[commentId]/route.ts` — DELETE (author or exec; soft-delete).
3. Frontend `announcements-view.tsx`:
   - Header with "New Announcement" button (exec only) → dialog (title, body textarea, pin switch).
   - Feed: `useInfiniteQuery` poll every 10s, "Load more" when hasMore.
   - Card: avatar + name + relative time + (edited) + Pinned badge, title (font-semibold), body (whitespace-pre-wrap + auto-link URLs).
   - Reaction bar: 5 fixed emojis `["👍","❤️","🎉","👏","😂"]` as pills (count only if > 0), active reaction highlighted in emerald, optimistic updates.
   - Comment count + Comments toggle that expands inline comment section.
   - Comment section: `useQuery` poll 15s, list with avatar/name/time/body, soft-deleted show "[comment removed]", input box Enter-to-send, Shift+Enter for newline, × delete (own or any if exec).
   - Pin/unpin, Edit (author or exec), Delete (exec only) menu on each card.
   - Empty state + skeletons.
4. Run `bun run lint`, fix files, check `tail -30 dev.log`, append worklog.

## Patterns to follow
- Auth: `getClubContext(clubId)` returns `{ user, membership, club }`; exec check `c.membership.role !== "executive"`.
- Responses: `json(data, status)` / `error(msg, status)` from `@/lib/server-auth`.
- Activity/notify: `logActivity(...)`, `notify(...)`, `notifyClub(...)` from `@/lib/activity`.
- Client: `api(path, { method, json })`.
- Store: `useAppStore((s) => s.currentClubId)` + `useAppStore((s) => s.currentClub)` (role).
- shadcn UI from `@/components/ui/*`; shared `PageHeader`, `EmptyState`, `initials`, `relativeTime` from `@/components/shared/page-header`.
- Use `useSession()` to read current user id for client-side author checks.

## Files to create/modify
- NEW `src/app/api/clubs/[clubId]/announcements/route.ts`
- NEW `src/app/api/clubs/[clubId]/announcements/[id]/route.ts`
- NEW `src/app/api/clubs/[clubId]/announcements/[id]/reactions/route.ts`
- NEW `src/app/api/clubs/[clubId]/announcements/[id]/comments/route.ts`
- NEW `src/app/api/clubs/[clubId]/announcements/[id]/comments/[commentId]/route.ts`
- OVERWRITE `src/components/views/announcements-view.tsx`

## Notes / decisions
- Emojis stored as Unicode escapes (`"\uD83D\uDC4D"`) in code so the file stays ASCII-clean per "no emojis in code unless part of reaction feature data" — they ARE reaction feature data but escapes are safe.
- Used `useInfiniteQuery` for the feed so "Load more" naturally composes; `refetchInterval: 10_000` re-fetches the first page so new pinned items appear quickly.
- Optimistic reaction updates across all cached pages (cancel + rollback pattern).
- Comments query has its own `refetchInterval: 15_000` so other members' new comments surface.
- All GET routes exclude soft-deleted announcements/comments; DELETE sets `deletedAt = new Date()`.
- Parent announcement refetch updates `commentCount` after posting/deleting a comment (in addition to the local comments cache patch).
