# Task 6 — Meetings module

## What was built

The Meetings module: list (upcoming/past) + calendar month grid views, RSVP, recurring series, ICS export, exec management.

## Files created / modified

### Backend API routes
- `src/app/api/clubs/[clubId]/meetings/route.ts`
  - `GET` — list upcoming + recent (last 7 days) meetings, exclude cancelled. Supports `?teamId=`. Includes creator name, team name, RSVP counts (`going`, `notGoing`, `maybe`), and the current user's RSVP. Also returns the list of teams in the club + `now` timestamp.
  - `POST` — exec only. Body validated with zod. Creates the anchor meeting + next 8 occurrences if `isRecurring` (9 total) using a single `$transaction`. Logs activity + notifies all members.
- `src/app/api/clubs/[clubId]/meetings/[id]/route.ts`
  - `PATCH` — exec only. Updates fields; recomputes time validation.
  - `DELETE` — exec only. Soft-cancel (`cancelledAt = now`). Supports `?scope=series` to cancel ALL non-cancelled meetings in the club with the same `title` + `recurrenceRule` + `createdById` + `teamId`. Notifies members either way.
- `src/app/api/clubs/[clubId]/meetings/[id]/rsvp/route.ts`
  - `POST` — body `{ status: "going"|"not_going"|"maybe" }`. Upserts the unique `(meetingId, userId)` RSVP. Returns updated `rsvpCounts`.
- `src/app/api/clubs/[clubId]/meetings/[id]/attendees/route.ts`
  - `GET` — exec only. Returns RSVP list with user info, sorted by status (going, maybe, not_going).
- `src/app/api/clubs/[clubId]/meetings/ics/route.ts`
  - `GET` — generates a valid `.ics` calendar file (VCALENDAR + VEVENT per upcoming meeting) with `UID`, `DTSTAMP`, `DTSTART`, `DTEND`, `SUMMARY`, `LOCATION`, `DESCRIPTION`. Sets `Content-Type: text/calendar` + `Content-Disposition: attachment; filename="club-meetings.ics"`.

### Frontend view (overwrote stub)
- `src/components/views/meetings-view.tsx`
  - `MeetingsView` (named, no props) — reads `currentClubId` + `currentClub` from `useAppStore`.
  - **Tabs**: Upcoming / Past / Calendar (default Upcoming).
  - **Filter**: team `<Select>` (All / each team) shown on list tabs only.
  - **Export .ics** button in header (fetches blob, triggers download).
  - **New Meeting** button (exec only) → dialog (title, description, location, start/end datetime-local, team optional, recurring checkbox + recurrence select weekly/biweekly/monthly). Default start = next hour, end = +1h.
  - **MeetingCard**: clickable title (opens detail dialog), date/time formatted as "Mon, Jan 15 · 3:00 PM – 4:30 PM", location w/ `MapPin` icon, team badge, recurring badge w/ rule, attendee count summary "5 going · 2 maybe", RSVP buttons (Going / Maybe / Not Going) highlighting current choice (`aria-pressed`), exec dropdown with Edit + Cancel (Cancel shows AlertDialog with "this occurrence only" vs "entire series" radios when recurring).
  - **Past list**: read-only, sorted desc by start time, shows final attendee counts.
  - **Calendar view**: minimal month grid built with `date-fns` (`startOfMonth` / `endOfMonth` / `startOfWeek` / `endOfWeek` / `eachDayOfInterval` / `addMonths` / `subMonths` / `isToday` / `isSameMonth` / `format`). 7 columns, prev/today/next nav, today highlighted with `ring-1 ring-primary`, meetings shown as small chips with time + title (truncated), "+N more" overflow. Click chip → detail dialog.
  - **Detail dialog**: shows full info, RSVP tally cards (going/maybe/not_going with emerald/amber/rose color coding), RSVP buttons (hidden if past), attendees list (exec only) with avatars + status pills, scrollable.
  - **Loading**: skeletons; **errors**: retry button; **empty states**: contextual (exec sees "Schedule a meeting" CTA).
  - **Responsive**: header buttons collapse to icon+label on mobile, calendar cells shrink on mobile (single-letter weekday header, `min-h-[5rem]`), card layout flips from horizontal to vertical on small screens.
  - **Dark-mode-safe**: all color tokens via `bg-card`, `bg-muted`, `text-muted-foreground`, `border`, etc.; RSVP tallies / pills include dark variants.
  - **Accessibility**: `aria-label` on icon-only buttons, `aria-pressed` on RSVP buttons, `sr-only` labels on filters, semantic `<button>` chips in calendar, keyboard-navigable dropdowns/dialogs.
  - TanStack Query for server state; mutations invalidate the `["meetings", clubId]` query.

## Decisions / non-obvious choices

- Recurring series created as 9 rows (anchor + 8 next) rather than generating indefinitely — keeps the DB simple and bounded; users can cancel the whole series or individual occurrences later.
- Series "match signature" is `(clubId, title, recurrenceRule, createdById, teamId)` — narrowed to club + creator + title + rule + team to avoid accidentally cancelling an unrelated meeting with the same title.
- `ics` route is a sibling static segment under `meetings/` (App Router prioritises the static `ics` over the dynamic `[id]` segment, so `/meetings/ics` resolves to the static handler).
- RSVP upsert keyed on the schema's `@@unique([meetingId, userId])`.
- "Recent" window for GET is 7 days back — meetings that ended within the last week still show in the upcoming/past list (past tab) so members can see just-ended context.
- Teams list is bundled into the meetings GET response (saves a round-trip; no separate teams endpoint exists yet as of this task).
- Calendar built from scratch with `date-fns` + divs — no heavy calendar lib (per task instruction).

## Verification

- `bun run lint` — passes for my files (any errors reported are in other agents' files: `announcements-view.tsx`, `teams-view.tsx`).
- Dev server compiles cleanly: `GET /api/clubs/nonexistent/meetings → 403`, `GET /api/clubs/nonexistent/meetings/ics → 403`, `GET /api/clubs/test/meetings/abc → 405` (PATCH/DELETE only), `GET /api/clubs/test/meetings/abc/rsvp → 405` (POST only), `GET /api/clubs/test/meetings/abc/attendees → 403`, `POST …/rsvp → 403`, `PATCH …/abc → 403`, `DELETE …/abc → 403` — all routes reachable and auth-gated.
- `GET /` still returns 200.
