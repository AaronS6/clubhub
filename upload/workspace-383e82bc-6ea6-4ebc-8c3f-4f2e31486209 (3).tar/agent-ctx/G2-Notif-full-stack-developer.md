# G2-Notif — Notification UI redesign

Task: Redesign the NotificationBell dropdown + build the full NotificationsView + extend the notifications API with pagination/filtering + ensure click-to-navigate works + ensure the unread badge updates live.

## Files created
- `src/lib/notif-meta.ts` — type→{icon,label,view,tone,getLinkUrl} map for all 11 notif types (hours_approved, hours_rejected, task_assigned, meeting_reminder, new_announcement, new_comment, new_reaction, promoted, demoted, new_member, chat_message). Includes `notifToneClasses()` (semantic Tailwind classes per tone, dark-mode safe) and `targetViewFor()` (resolves destination View from a notif's `linkUrl` or type default).

## Files modified
- `src/app/api/notifications/route.ts` — extended GET to support `?page=&pageSize=&filter=all|unread&type=<type>`. Returns `{items, hasMore, total, unread, page, pageSize}`. `unread` is the user's total unread count (independent of filter) so the badge stays accurate even when the view is filtered.
- `src/components/app-shell.tsx`:
  - Rebuilt `NotificationBell` dropdown: grouped by New (unread, top) / Earlier (read), per-type icon in a tinted circle, relative timestamps, click-to-navigate (via `setView(targetView)`), optimistic mark-read on click + on hover button, live unread badge via `realtime:notification` subscription + 20s poll, "View all" link → `notifications` view, "Notification settings" footer link → dispatches `open-settings` custom event.
  - Added `NotifSection` + `NotifRow` subcomponents.
  - Added `NotifItem` + `NotifListResponse` types.
  - `UserMenu` now listens for the `open-settings` window event and opens the SettingsDialog on the requested tab. Lifted SettingsDialog tab state into `UserMenu` (`settingsTab` + `onTabChange`).
  - `SettingsDialog` now accepts `tab` + `onTabChange` props; Tabs component switched from `defaultValue` to controlled `value`/`onValueChange`.
- `src/components/views/notifications-view.tsx` — full implementation: `useInfiniteQuery` with pagination, filter `Select` (All / Unread / by type via grouped options), PageHeader with "Mark all read" button + filter, mark-read hover affordance, optimistic cache updates via `qc.setQueriesData`, realtime subscription via `onRealtimeEvent("realtime:notification")` → `qc.invalidateQueries({queryKey:["notifications"]})`, empty state, loading skeleton, "Load more" pagination button.

## Decisions
- **Bell fetches 10 items** (`?pageSize=10`) instead of 50 — keeps the dropdown lean; users click "View all" for the full paginated history. Spec said the bell "can keep fetching 50" but 10 is the right size for a dropdown preview.
- **Optimistic updates everywhere**: bell's `markRead`/`markAllRead` flip local state instantly; view's mutations flip the react-query cache instantly. Both fall back to a re-fetch on API error.
- **Live updates**: bell subscribes directly to `realtime:notification` events (instant refetch + toast). View subscribes to the same event and invalidates `["notifications"]` query key (covers both the view's `["notifications","list",filter]` and any future notifications queries). The 20s poll is the fallback for both.
- **Custom event pattern for opening SettingsDialog**: rather than lifting SettingsDialog state to a zustand store (adds coupling), used a `window.dispatchEvent(new CustomEvent("open-settings", {detail:{tab:"notifications"}}))` pattern. UserMenu holds the open state + tab state; the bell just dispatches the event. Clean and decoupled.
- **Click-to-navigate**: `targetViewFor(n)` prefers the notification's own `linkUrl` (parses `?view=` param if present), falls back to the type's default `view`. v1 only navigates to the right View; deep-linking to a specific item is a future enhancement.
- **Tone palette**: mirrors the StatusBadge semantic palette — emerald=approved, red=rejected, blue=task, violet=meeting, amber=announcement, sky=comment, fuchsia=reaction, teal=member. Each has a soft tinted background + matching strong foreground, with dark-mode variants.
- **Nested button a11y**: each row is a `div role="button" tabIndex={0}` (keyboard accessible via Enter/Space); the hover-only "mark read" affordance is a real `<button>` with `e.stopPropagation()` so it doesn't trigger row navigation.
- **Filter Select groups**: "Status" (All/Unread) + "By type" (all 11 types) grouped via `SelectGroup`/`SelectLabel` for scannability.

## Verification
- `bunx tsc --noEmit` — 0 errors in my files (notifications-view, notif-meta, app-shell, api/notifications/route).
- `bun run lint` — 0 errors in my files. (2 pre-existing errors in chat-view.tsx are the chat subagent's territory; 2 pre-existing warnings in chat-view.tsx are also theirs.)
- `tail dev.log` — all GET / 200 responses; the bell's `GET /api/notifications?pageSize=10` call works (401 when unauthenticated, as expected — the bell silently fails in its catch block).
