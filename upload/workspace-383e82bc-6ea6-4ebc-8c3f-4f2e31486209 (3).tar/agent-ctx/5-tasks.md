# Task 5 — Tasks Module (Kanban + List)

**Agent**: full-stack-developer (Tasks)
**Date**: 2026-09-07

## What was built

A complete Tasks module for the ClubHub platform — full backend API + frontend `TasksView` component. The view is rendered on the `/` route when the user navigates to the "tasks" view.

## Backend API routes

All under `src/app/api/clubs/[clubId]/tasks/`:

| Route | Method | Description |
|---|---|---|
| `/api/clubs/[clubId]/tasks` | GET | List tasks (filters: `teamId`, `assigneeId`, `status`). Also returns `teams`, `members`, `myUserId`, `myRole` for filter dropdowns. Excludes soft-deleted. |
| `/api/clubs/[clubId]/tasks` | POST | Exec-only. Body `{ title, description?, teamId?, assignedToUserId?, dueDate? }`. Notifies assignee (`task_assigned`), logs `task_created`. |
| `/api/clubs/[clubId]/tasks/[id]` | PATCH | Exec can edit any field; members can ONLY change `status` of tasks assigned to them. Logs activity on status/assignment change, notifies newly-assigned user. |
| `/api/clubs/[clubId]/tasks/[id]` | DELETE | Exec-only, soft-deletes via `deletedAt = now`. |
| `/api/clubs/[clubId]/tasks/[id]/subtasks` | POST | Any member. Body `{ title }`. |
| `/api/clubs/[clubId]/tasks/[id]/subtasks/[subtaskId]` | PATCH | Any member. Body `{ isDone }` or `{ title }`. |
| `/api/clubs/[clubId]/tasks/[id]/subtasks/[subtaskId]` | DELETE | Exec or task creator. |
| `/api/clubs/[clubId]/tasks/[id]/comments` | GET / POST | List / add comment. Body `{ body }`. |
| `/api/clubs/[clubId]/tasks/[id]/comments/[commentId]` | DELETE | Author or exec. |

### Auth pattern used

```ts
const { clubId } = await ctx.params
const c = await getClubContext(clubId)
if (!c) return error("Not a member of this club", 403)
// ...
```

## Frontend `TasksView`

`src/components/views/tasks-view.tsx` — named export `TasksView`, no props.

### Features

- **Tabs**: Board (default) | List. Separate mobile (full-width tabs) and desktop (right-aligned tabs) variants.
- **Filters**: team select (All + each team), assignee select (All + Assigned to me + each member), status select (list view only). "Clear" button resets all.
- **Board view**: 3 columns (Not Started / In Progress / Done) with status-colored backgrounds and `StatusBadge` headers.
  - Each card is `useSortable` with `id = taskId`.
  - Each column is also `useDroppable` so empty columns accept drops.
  - `DndContext` with `PointerSensor` (6px activation) + `KeyboardSensor` (`sortableKeyboardCoordinates`) + `closestCorners` collision detection.
  - `DragOverlay` shows the dragged card with rotation + shadow for visual feedback.
  - On drop, determines target status (column id or task's column) and PATCHes optimistically with refetch-on-error rollback.
  - Card shows: title, description (truncated), team badge, subtask progress (e.g. "2/5"), comment count, assignee avatar (or Users icon if unassigned), due date in red when overdue.
  - Mobile: columns stack vertically (single-column grid). Desktop (`sm+`): 3-column grid.
- **List view**: `@/components/ui/table` with columns Title, Assignee, Team (hidden `md-`), Due (hidden `sm-`), Status (inline `Select` — disabled unless exec or self-assigned), Actions (button opens detail).
- **Task detail**: right-side `Sheet` with `ScrollArea`.
  - Exec: editable title (Input, onBlur saves), description (Textarea), team Select, assignee Select, due date `<input type=date>`, status Select, destructive Delete button (with AlertDialog confirm).
  - Member: read-only fields + status Select (allowed because they're assignee).
  - Inline subtasks checklist (add/toggle/delete — delete button hidden until hover).
  - Inline comments list + add (any member; author/exec can delete).
- **New Task dialog** (exec only): title, description, team, assignee, due date.
- **Loading skeletons**: board shows 3 column skeletons; list shows table-row skeletons.
- **Empty state**: with optional "New Task" CTA (exec only).
- **Error state**: with retry button.
- **Toast feedback** (sonner) on every mutation success/error.
- **TanStack Query**: `useQuery(["tasks", clubId])` for list, `useMutation` for all writes with `invalidateQueries({ queryKey: ["tasks", clubId] })` after success.

### Accessibility

- ARIA labels on all icon buttons (delete subtask, delete comment, open task details).
- Keyboard navigation on cards (`Enter`/`Space` opens detail).
- `sortableKeyboardCoordinates` enables DnD keyboard support.
- `sr-only` description in Sheet header.
- `aria-label` on each column (e.g. "Not Started column").
- Touch targets ≥ 36px.

### Dark-mode safe

All colors come from Tailwind built-in variables (`bg-muted`, `text-muted-foreground`, `border-border/60`, `ring-primary`) plus the shared `StatusBadge` palette (which already has dark variants).

## Verification

- `bun run lint` — 0 errors in my code (only 1 pre-existing warning in `dashboard-view.tsx`, not mine).
- `bunx tsc --noEmit` — no errors in any tasks-related file (pre-existing errors in other modules remain, but nothing in `tasks-view.tsx` or `tasks/` API routes).
- `/api/clubs/nonexistent/tasks` returns 403 and compiles cleanly in dev.log (740ms first compile, then 2ms cached).
- Dev log shows all `GET /` requests return 200 with no compile errors.

## Files touched

- Created: 6 backend route files under `src/app/api/clubs/[clubId]/tasks/`
- Overwritten: `src/components/views/tasks-view.tsx` (full implementation, ~1300 lines)
- Appended to: `/home/z/my-project/worklog.md`

## Notes for next agents

- Tasks list GET response includes `teams` and `members` arrays — reuse this if you need a list of club teams/members in another module (avoids extra round-trips).
- The Tasks schema fields `teamId` and `assignedToUserId` accept `null` for "unassigned"; the frontend uses `"none"` as the Select sentinel value and converts back to `null` on save.
- The PATCH endpoint validates that the member is the assignee AND is only changing `status` (any other field returns 403).
- Subtask delete is restricted to exec or task creator (not just any member) per the spec; subtask add/toggle is open to all members.
