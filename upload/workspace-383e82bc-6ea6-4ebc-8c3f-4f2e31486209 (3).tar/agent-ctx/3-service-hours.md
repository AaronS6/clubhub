# Task 3 — Service Hours module (full-stack-developer)

## Task
Build the Service Hours module: backend API routes + two frontend view components (`HoursView` member-facing and `ApprovalsView` exec-facing approval queue) for ClubHub.

## Plan
1. Read worklog + existing patterns (server-auth, activity, store, api client, page-header).
2. Backend routes under `src/app/api/clubs/[clubId]/hours/`:
   - `route.ts` — GET (list with scope/userId/status filters + totals + club hoursGoal), POST (submit new entry, notify execs).
   - `upload/route.ts` — multipart upload, validate type/size, sharp-resize images to max 1600px JPEG q80, PDFs as-is, save under `public/uploads/clubs/<clubId>/hours/`, return public URL.
   - `[hourId]/route.ts` — PATCH (exec approve/reject, delete proof file, notify submitter, log activity), DELETE (member deletes own pending; exec deletes any — both delete proof file).
   - `bulk-review/route.ts` — exec bulk approve/reject with comment.
   - `export/route.ts` — current user's APPROVED hours as CSV download.
   - `categories/route.ts` — GET for all members, POST exec-only.
3. Frontend:
   - `hours-view.tsx` — PageHeader + Submit Hours dialog (date, hours, reason, category, file upload) + summary (total approved hours + Progress bar to club hoursGoal) + history table that collapses to cards on mobile + Export CSV button + Delete (own pending). TanStack Query `["hours", clubId]`, `["hours-categories", clubId]`.
   - `approvals-view.tsx` — exec-only gate, filter by member + date range, table of pending with checkbox + Approve/Reject (reject opens comment dialog), bulk actions, polls every 5s. Query key `["approvals", clubId, filters]`.
4. Run `bun run lint`, fix my files, check `tail -30 dev.log`, append worklog.

## Patterns to follow
- Auth: `getClubContext(clubId)` returns `{user, membership, club}`; check `c.membership.role !== "executive"` for exec-only.
- Responses: `json(data, status)` / `error(msg, status)` from `@/lib/server-auth`.
- Activity/notify: `logActivity(...)`, `notify(...)` from `@/lib/activity`.
- Client: `api()` for JSON, `apiUpload()` for multipart.
- Store: `useAppStore((s) => s.currentClubId)`.
- shadcn UI from `@/components/ui/*`; shared `PageHeader`, `StatusBadge`, `EmptyState`, `relativeTime` from `@/components/shared/page-header`.
- Static routes (`upload`, `bulk-review`, `export`, `categories`) take precedence over `[hourId]` dynamic — safe.

## Files to create/modify
- NEW `src/app/api/clubs/[clubId]/hours/route.ts`
- NEW `src/app/api/clubs/[clubId]/hours/upload/route.ts`
- NEW `src/app/api/clubs/[clubId]/hours/[hourId]/route.ts`
- NEW `src/app/api/clubs/[clubId]/hours/bulk-review/route.ts`
- NEW `src/app/api/clubs/[clubId]/hours/export/route.ts`
- NEW `src/app/api/clubs/[clubId]/hours/categories/route.ts`
- OVERWRITE `src/components/views/hours-view.tsx`
- OVERWRITE `src/components/views/approvals-view.tsx`
