"use client"

import { useRef, useState, useMemo } from "react"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import { useAppStore } from "@/lib/store"
import { api, apiUpload } from "@/lib/api/client"
import { cn } from "@/lib/utils"
import { usePollingFallback } from "@/lib/realtime-store"
import { toast } from "sonner"
import { PageHeader, EmptyState, TableSkeleton, relativeTime, initials, avatarColor } from "@/components/shared/page-header"
import { StatusPill } from "@/components/shared/status-pill"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"
import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Clock,
  Plus,
  Download,
  Upload,
  Trash2,
  FileText,
  Loader2,
  CheckCircle2,
  XCircle,
  Link as LinkIcon,
  History,
  ChevronDown,
  Calendar,
  Target,
} from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { DIALOG_CLASS } from "@/components/shared/dialog-class"

interface HoursItem {
  id: string
  clubId: string
  userId: string
  dateOfService: string
  hours: number
  reasonText: string
  proofFileUrl: string | null
  status: "pending" | "approved" | "rejected"
  reviewedBy: string | null
  reviewComment: string | null
  submittedAt: string
  reviewedAt: string | null
  category: { id: string; name: string } | null
  user?: { id: string; name: string }
  reviewer?: { id: string; name: string } | null
}

interface HoursResponse {
  items: HoursItem[]
  totals: { approvedHours: number }
  clubHoursGoal: number
  myRole: "member" | "executive"
  myUserId: string
  filteredUserId: string | null
}

interface CategoryResponse {
  categories: { id: string; name: string; hoursCount: number; createdAt: string }[]
  myRole: "member" | "executive"
}

function statusKind(s: HoursItem["status"]) {
  return s as "pending" | "approved" | "rejected"
}

function fmtDate(d: string) {
  const date = new Date(d)
  if (isNaN(date.getTime())) return d
  return date.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" })
}

function todayISO() {
  const d = new Date()
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, "0")
  const day = String(d.getDate()).padStart(2, "0")
  return `${y}-${m}-${day}`
}

export function HoursView() {
  const clubId = useAppStore((s) => s.currentClubId)
  const isExec = useAppStore((s) => s.currentClub?.role) === "executive"
  const qc = useQueryClient()
  const [submitOpen, setSubmitOpen] = useState(false)
  const [period, setPeriod] = useState<string>("all_time")

  const hoursQuery = useQuery<HoursResponse>({
    queryKey: ["hours", clubId],
    queryFn: () => api<HoursResponse>(`/api/clubs/${clubId}/hours`),
    enabled: !!clubId,
    staleTime: 15_000,
    // Realtime is primary; poll only as a fallback while the socket is down.
    refetchInterval: usePollingFallback(10000),
  })

  const catsQuery = useQuery<CategoryResponse>({
    queryKey: ["hours-categories", clubId],
    queryFn: () => api<CategoryResponse>(`/api/clubs/${clubId}/hours/categories`),
    enabled: !!clubId,
    staleTime: 60_000,
  })

  // Personal service-hours goal for this club (0 = unset → the summary falls
  // back to the club-wide goal). Editable via the SetGoalPopover.
  const goalQuery = useQuery<{ personalGoal: number; clubGoal: number; role: string }>({
    queryKey: ["my-goal", clubId],
    queryFn: () => api<{ personalGoal: number; clubGoal: number; role: string }>(`/api/clubs/${clubId}/my-goal`),
    enabled: !!clubId,
    staleTime: 30_000,
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api(`/api/clubs/${clubId}/hours/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      toast.success("Entry deleted")
      qc.invalidateQueries({ queryKey: ["hours", clubId] }); qc.invalidateQueries({ queryKey: ["dashboard", clubId] })
    },
    onError: (e: Error) => toast.error(e.message),
  })

  // ---- Time-period filtering + grouping ----------------------------------
  // The API returns all items; we filter + group client-side based on the
  // selected period. For "this_year"/"last_year" we group by month; for
  // "all_time" we group by year and stash pre-current-year groups in an
  // "older" bucket so they can be collapsed behind an "Older entries" trigger.
  // NOTE: this useMemo is placed BEFORE the `if (!clubId)` early return so
  // React's rules-of-hooks are satisfied (hooks must run unconditionally).
  type Group = { key: string; label: string; items: HoursItem[] }
  const { currentGroups, olderGroups } = useMemo<{ currentGroups: Group[]; olderGroups: Group[] }>(() => {
    const data = hoursQuery.data
    if (!data) return { currentGroups: [], olderGroups: [] }
    const now = new Date()
    const thisYear = now.getFullYear()
    const thisMonth = now.getMonth()

    // --- Filter by period ---
    let filtered = data.items
    if (period === "this_month") {
      filtered = data.items.filter((it) => {
        const d = new Date(it.dateOfService)
        return d.getFullYear() === thisYear && d.getMonth() === thisMonth
      })
    } else if (period === "last_month") {
      const lm = new Date(thisYear, thisMonth - 1, 1)
      filtered = data.items.filter((it) => {
        const d = new Date(it.dateOfService)
        return d.getFullYear() === lm.getFullYear() && d.getMonth() === lm.getMonth()
      })
    } else if (period === "this_year") {
      filtered = data.items.filter((it) => new Date(it.dateOfService).getFullYear() === thisYear)
    } else if (period === "last_year") {
      filtered = data.items.filter((it) => new Date(it.dateOfService).getFullYear() === thisYear - 1)
    }
    // "all_time" — no filter

    // --- Group ---
    // Sort filtered items by dateOfService descending (most recent first).
    const sorted = [...filtered].sort(
      (a, b) => new Date(b.dateOfService).getTime() - new Date(a.dateOfService).getTime(),
    )

    if (period === "this_year" || period === "last_year") {
      // Group by month, most recent first.
      const map = new Map<string, Group>()
      for (const it of sorted) {
        const d = new Date(it.dateOfService)
        const key = `${d.getFullYear()}-${String(d.getMonth()).padStart(2, "0")}`
        const label = d.toLocaleDateString(undefined, { year: "numeric", month: "long" })
        const existing = map.get(key)
        if (existing) {
          existing.items.push(it)
        } else {
          map.set(key, { key, label, items: [it] })
        }
      }
      return { currentGroups: [...map.values()], olderGroups: [] }
    }

    if (period === "all_time") {
      // Group by year. Current year → currentGroups (shown directly); older
      // years → olderGroups (collapsed behind "Older entries").
      const currentMap = new Map<string, Group>()
      const olderMap = new Map<string, Group>()
      for (const it of sorted) {
        const d = new Date(it.dateOfService)
        const y = d.getFullYear()
        const key = String(y)
        const label = String(y)
        const target = y === thisYear ? currentMap : olderMap
        const existing = target.get(key)
        if (existing) {
          existing.items.push(it)
        } else {
          target.set(key, { key, label, items: [it] })
        }
      }
      return {
        currentGroups: [...currentMap.values()],
        olderGroups: [...olderMap.values()],
      }
    }

    // this_month / last_month — single flat group (no header).
    return {
      currentGroups: [{ key: "flat", label: "", items: sorted }],
      olderGroups: [],
    }
  }, [hoursQuery.data, period])

  const filteredCount = currentGroups.reduce((n, g) => n + g.items.length, 0) + olderGroups.reduce((n, g) => n + g.items.length, 0)

  function handleExport() {
    if (!clubId) return
    // Opens the styled, printable HTML export in a new tab. The user can then
    // use "Print → Save as PDF" or click "Download CSV" inside the doc.
    window.open(`/api/clubs/${clubId}/hours/export`, "_blank", "noopener,noreferrer")
  }

  if (!clubId) {
    return <div className="p-8 text-muted-foreground">Loading…</div>
  }

  const data = hoursQuery.data
  const approvedHours = data?.totals.approvedHours ?? 0
  // Effective goal: the member's PERSONAL goal takes priority; falls back
  // to the club-wide goal the executives set. (Both are editable — personal
  // here via the goal popover, club-wide by executives during the tour or
  // in Members → Club settings.)
  const personalGoal = goalQuery.data?.personalGoal ?? 0
  const effectiveGoal = personalGoal > 0 ? personalGoal : (data?.clubHoursGoal ?? 0)
  const goalIsPersonal = personalGoal > 0
  const progressPct =
    effectiveGoal > 0 ? Math.min(100, Math.round((approvedHours / effectiveGoal) * 100)) : 0

  return (
    <div className="space-y-6">
      <PageHeader
        title="Service Hours"
        actions={
          <>
            <Button variant="outline" size="sm" onClick={handleExport} disabled={!data || data.items.length === 0}>
              <Download className="h-4 w-4" />
              <span className="hidden sm:inline">Export</span>
            </Button>
            <Button size="sm" variant="club" onClick={() => setSubmitOpen(true)}>
              <Plus className="h-4 w-4" />
              <span>Submit Hours</span>
            </Button>
          </>
        }
      />

      {/* Summary card */}
      <div className="card-quiet rounded-xl p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-club-muted text-club">
              <Clock className="h-6 w-6" />
            </div>
            <div>
              <div className="text-caption-medium text-muted-foreground">Total approved hours</div>
              <div className="text-3xl font-semibold tracking-tight">
                {hoursQuery.isLoading ? <Skeleton className="h-9 w-20" /> : approvedHours}
              </div>
            </div>
          </div>
          <div className="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:gap-4">
            {effectiveGoal > 0 && (
              <div className="flex-1 sm:max-w-xs">
                <div className="flex items-center justify-between text-caption-medium mb-1.5">
                  <span className="text-muted-foreground">
                    {goalIsPersonal ? "Your goal" : "Club goal"}: {effectiveGoal}h
                  </span>
                  <span className="font-medium">{progressPct}%</span>
                </div>
                <Progress value={progressPct} className="h-2.5" />
              </div>
            )}
            <SetGoalPopover
              clubId={clubId}
              current={personalGoal}
              onSaved={() => {
                goalQuery.refetch()
                qc.invalidateQueries({ queryKey: ["dashboard", clubId] })
              }}
            />
          </div>
        </div>
      </div>

      {/* History */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <History className="h-4 w-4" />
            <span>History</span>
            {data && filteredCount > 0 && (
              <span className="text-caption text-muted-foreground/70">
                · {filteredCount} {filteredCount === 1 ? "entry" : "entries"}
              </span>
            )}
          </div>
          {/* Time period filter — client-side filtering/grouping. */}
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[150px] sm:w-[180px] h-9" aria-label="Filter by time period">
              <Calendar className="h-3.5 w-3.5 text-muted-foreground mr-1" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="this_month">This month</SelectItem>
              <SelectItem value="last_month">Last month</SelectItem>
              <SelectItem value="this_year">This year</SelectItem>
              <SelectItem value="last_year">Last year</SelectItem>
              <SelectItem value="all_time">All time</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {hoursQuery.isLoading ? (
          <TableSkeleton rows={5} />
        ) : hoursQuery.error ? (
          <EmptyState
            icon={<XCircle className="h-8 w-8" />}
            title="Couldn't load hours"
            description={hoursQuery.error.message}
            action={
              <Button variant="outline" size="sm" onClick={() => hoursQuery.refetch()}>
                Retry
              </Button>
            }
          />
        ) : !data || data.items.length === 0 ? (
          <EmptyState
            icon={<Clock className="h-8 w-8" />}
            title="No service hours yet"
            action={
              <Button size="sm" variant="club" onClick={() => setSubmitOpen(true)}>
                <Plus className="h-4 w-4" /> Submit Hours
              </Button>
            }
          />
        ) : filteredCount === 0 ? (
          <EmptyState
            icon={<Calendar className="h-8 w-8" />}
            title="No entries in this period"
          />
        ) : (
          <>
            {/* Current groups (this month / this year months / current year) */}
            {currentGroups.map((g) => (
              <div key={g.key} className="space-y-2">
                {g.label && (
                  <div className="flex items-center gap-2 px-1">
                    <h3 className="text-card-title">{g.label}</h3>
                    <span className="text-caption text-muted-foreground">
                      {g.items.length} {g.items.length === 1 ? "entry" : "entries"}
                    </span>
                  </div>
                )}
                {/* Desktop: table */}
                <div className="card-quiet rounded-xl p-0 overflow-hidden hidden md:block">
                  <Table>
                    <TableHeader className="[&_th]:sticky [&_th]:top-0 [&_th]:bg-muted/85 [&_th]:z-10">
                      <TableRow>
                        <TableHead className="min-w-[7rem]">Date</TableHead>
                        <TableHead className="min-w-[3rem]">Hours</TableHead>
                        <TableHead className="min-w-[12rem]">Reason</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Proof</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Submitted</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {g.items.map((it) => (
                        <HoursRow
                          key={it.id}
                          item={it}
                          canDelete={isExec || it.status === "pending"}
                          onDelete={() => deleteMutation.mutate(it.id)}
                          deleting={deleteMutation.isPending && deleteMutation.variables === it.id}
                          goal={data?.clubHoursGoal ?? 0}
                        />
                      ))}
                    </TableBody>
                  </Table>
                </div>
                {/* Mobile: stacked cards */}
                <div className="md:hidden space-y-3">
                  {g.items.map((it) => (
                    <HoursCard
                      key={it.id}
                      item={it}
                      canDelete={isExec || it.status === "pending"}
                      onDelete={() => deleteMutation.mutate(it.id)}
                      deleting={deleteMutation.isPending && deleteMutation.variables === it.id}
                    />
                  ))}
                </div>
              </div>
            ))}

            {/* Older entries (all_time only) — collapsed by default. */}
            {olderGroups.length > 0 && (
              <Collapsible className="space-y-2">
                <CollapsibleTrigger asChild>
                  <button
                    type="button"
                    className="flex w-full items-center gap-2 rounded-lg border bg-card/50 px-3 py-2.5 text-left text-sm hover:bg-accent/40 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <ChevronDown className="h-4 w-4 text-muted-foreground [[data-state=open]_&]:rotate-180 transition-transform" />
                    <span className="font-medium">Older entries</span>
                    <span className="text-caption text-muted-foreground">
                      {olderGroups.reduce((n, g) => n + g.items.length, 0)} entries ·{" "}
                      {olderGroups.map((g) => g.label).join(", ")}
                    </span>
                  </button>
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-4">
                  {olderGroups.map((g) => (
                    <div key={g.key} className="space-y-2">
                      <div className="flex items-center gap-2 px-1">
                        <h3 className="text-card-title">{g.label}</h3>
                        <span className="text-caption text-muted-foreground">
                          {g.items.length} {g.items.length === 1 ? "entry" : "entries"}
                        </span>
                      </div>
                      <div className="card-quiet rounded-xl p-0 overflow-hidden hidden md:block">
                        <Table>
                          <TableHeader className="[&_th]:sticky [&_th]:top-0 [&_th]:bg-muted/85 [&_th]:z-10">
                            <TableRow>
                              <TableHead className="min-w-[7rem]">Date</TableHead>
                              <TableHead className="min-w-[3rem]">Hours</TableHead>
                              <TableHead className="min-w-[12rem]">Reason</TableHead>
                              <TableHead>Category</TableHead>
                              <TableHead>Proof</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead>Submitted</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {g.items.map((it) => (
                              <HoursRow
                                key={it.id}
                                item={it}
                                canDelete={isExec || it.status === "pending"}
                                onDelete={() => deleteMutation.mutate(it.id)}
                                deleting={deleteMutation.isPending && deleteMutation.variables === it.id}
                                goal={data?.clubHoursGoal ?? 0}
                              />
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                      <div className="md:hidden space-y-3">
                        {g.items.map((it) => (
                          <HoursCard
                            key={it.id}
                            item={it}
                            canDelete={isExec || it.status === "pending"}
                            onDelete={() => deleteMutation.mutate(it.id)}
                            deleting={deleteMutation.isPending && deleteMutation.variables === it.id}
                          />
                        ))}
                      </div>
                    </div>
                  ))}
                </CollapsibleContent>
              </Collapsible>
            )}
          </>
        )}
      </div>

      <SubmitHoursDialog
        open={submitOpen}
        onOpenChange={setSubmitOpen}
        clubId={clubId}
        categories={catsQuery.data?.categories ?? []}
        categoriesLoading={catsQuery.isLoading}
        onSubmitted={() => {
          qc.invalidateQueries({ queryKey: ["hours", clubId] }); qc.invalidateQueries({ queryKey: ["dashboard", clubId] })
        }}
      />
    </div>
  )
}

function HoursRow({
  item,
  canDelete,
  onDelete,
  deleting,
  goal,
}: {
  item: HoursItem
  canDelete: boolean
  onDelete: () => void
  deleting: boolean
  /** Monthly club hours goal — powers the inline progress bar in the Hours cell.
      0/undefined = no bar (spec: "If no goal, skip the bar"). Purely visual. */
  goal?: number
}) {
  const pct = goal && goal > 0 ? Math.min(100, Math.round((item.hours / goal) * 100)) : 0
  return (
    <TableRow className="hover:bg-muted/30 transition-colors">
      <TableCell className="text-xs text-muted-foreground">{fmtDate(item.dateOfService)}</TableCell>
      <TableCell>
        <div className="flex items-center gap-2">
          <span className="text-base font-semibold tabular-nums">{item.hours}</span>
          {goal && goal > 0 && pct > 0 && (
            <span
              className="h-1 w-16 shrink-0 rounded-full bg-muted overflow-hidden"
              aria-hidden
            >
              <span
                className="block h-full rounded-full bg-club"
                style={{ width: `${pct}%` }}
              />
            </span>
          )}
        </div>
      </TableCell>
      <TableCell className="max-w-xs">
        <div className="line-clamp-2 text-sm">{item.reasonText}</div>
        {item.status === "rejected" && item.reviewComment && (
          <div className="text-xs text-danger-foreground dark:text-danger-foreground mt-1 line-clamp-2">
            "{item.reviewComment}"
          </div>
        )}
      </TableCell>
      <TableCell className="text-sm text-muted-foreground">
        {item.category?.name ?? <span className="text-muted-foreground/60">—</span>}
      </TableCell>
      <TableCell>
        <ProofLink url={item.proofFileUrl} />
      </TableCell>
      <TableCell>
        <StatusPill status={statusKind(item.status)} />
      </TableCell>
      <TableCell className="text-xs text-muted-foreground">{relativeTime(item.submittedAt)}</TableCell>
      <TableCell className="text-right">
        {canDelete && (
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9 text-muted-foreground hover:text-danger-foreground hover:bg-danger-subtle dark:hover:bg-danger-subtle"
            onClick={onDelete}
            disabled={deleting}
            aria-label="Delete entry"
            title="Delete entry"
          >
            {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
          </Button>
        )}
      </TableCell>
    </TableRow>
  )
}

function HoursCard({
  item,
  canDelete,
  onDelete,
  deleting,
}: {
  item: HoursItem
  canDelete: boolean
  onDelete: () => void
  deleting: boolean
}) {
  return (
    <div className="card-quiet rounded-xl p-4 space-y-2">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="text-body-medium">{fmtDate(item.dateOfService)}</div>
          <div className="text-caption">
            <span className="font-mono tabular-nums text-foreground">{item.hours}</span> hour{item.hours === 1 ? "" : "s"}
            {item.category && <span> · {item.category.name}</span>}
          </div>
        </div>
        <StatusPill status={statusKind(item.status)} />
      </div>
      <div className="text-body">{item.reasonText}</div>
      {item.status === "rejected" && item.reviewComment && (
        <div className="text-caption text-danger-foreground dark:text-danger-foreground">
          <span className="font-medium">Reason:</span> {item.reviewComment}
        </div>
      )}
      {/* §39 — Reviewer name + avatar (when reviewed). The API exposes
          only the reviewer's id+name; we render initials as the fallback. */}
      <div className="flex items-center justify-between pt-1 gap-2">
        <div className="text-caption min-w-0 flex items-center gap-1.5">
          Submitted {relativeTime(item.submittedAt)}
          {item.reviewer && item.reviewedAt && (
            <span className="truncate inline-flex items-center gap-1.5">
              <Avatar className="h-4 w-4">
                <AvatarFallback className={cn("text-xs", avatarColor(item.reviewer.name))}>
                  {initials(item.reviewer.name)}
                </AvatarFallback>
              </Avatar>
              · reviewed by {item.reviewer.name}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {item.proofFileUrl && <ProofLink url={item.proofFileUrl} compact />}
          {canDelete && (
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 text-muted-foreground hover:text-danger-foreground hover:bg-danger-subtle dark:hover:bg-danger-subtle"
              onClick={onDelete}
              disabled={deleting}
              aria-label="Delete entry"
              title="Delete entry"
            >
              {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}

function ProofLink({ url, compact }: { url: string | null; compact?: boolean }) {
  if (!url) return <span className="text-caption text-muted-foreground/60">—</span>
  const isPdf = url.toLowerCase().endsWith(".pdf")
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        "inline-flex items-center gap-1.5 rounded-md border bg-background px-2 py-1 text-caption-medium text-club hover:bg-club-subtle",
        compact && "px-1.5 py-1"
      )}
    >
      {isPdf ? <FileText className="h-3.5 w-3.5" /> : <LinkIcon className="h-3.5 w-3.5" />}
      <span>{isPdf ? "PDF" : "Image"}</span>
    </a>
  )
}

function SubmitHoursDialog({
  open,
  onOpenChange,
  clubId,
  categories,
  categoriesLoading,
  onSubmitted,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  clubId: string
  categories: { id: string; name: string }[]
  categoriesLoading: boolean
  onSubmitted: () => void
}) {
  const qc = useQueryClient()
  const [date, setDate] = useState<string>(todayISO())
  const [hours, setHours] = useState<string>("")
  const [reason, setReason] = useState<string>("")
  const [categoryId, setCategoryId] = useState<string>("__none__")
  const [proofUrl, setProofUrl] = useState<string | null>(null)
  const [proofLabel, setProofLabel] = useState<string>("")
  const [uploading, setUploading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [hoursError, setHoursError] = useState<string | null>(null)
  const [dateError, setDateError] = useState<string | null>(null)
  const [reasonError, setReasonError] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  function reset() {
    setDate(todayISO())
    setHours("")
    setReason("")
    setCategoryId("__none__")
    setProofUrl(null)
    setProofLabel("")
    setHoursError(null)
    setDateError(null)
    setReasonError(null)
    if (fileRef.current) fileRef.current.value = ""
  }

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]
    if (!f) return
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append("file", f)
      const res = await apiUpload<{ url: string }>(`/api/clubs/${clubId}/hours/upload`, fd)
      setProofUrl(res.url)
      setProofLabel(f.name)
      toast.success("Proof uploaded")
    } catch (err: any) {
      toast.error(err.message || "Upload failed")
      setProofUrl(null)
      setProofLabel("")
    } finally {
      setUploading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const hoursNum = Number(hours)
    let bad = false
    if (!date) {
      setDateError("Please pick a date")
      bad = true
    } else {
      setDateError(null)
    }
    if (!hours.trim() || !isFinite(hoursNum) || hoursNum <= 0) {
      setHoursError("Enter a valid number of hours")
      bad = true
    } else {
      setHoursError(null)
    }
    if (!reason.trim()) {
      setReasonError("Please describe what you did")
      bad = true
    } else {
      setReasonError(null)
    }
    if (bad) return

    setSubmitting(true)
    try {
      await api(`/api/clubs/${clubId}/hours`, {
        method: "POST",
        json: {
          dateOfService: new Date(date).toISOString(),
          hours: hoursNum,
          reasonText: reason.trim(),
          categoryId: categoryId !== "__none__" ? categoryId : undefined,
          proofFileUrl: proofUrl ?? undefined,
        },
      })
      toast.success("Hours submitted for review")
      reset()
      onOpenChange(false)
      onSubmitted()
      qc.invalidateQueries({ queryKey: ["hours-categories", clubId] })
    } catch (err: any) {
      toast.error(err.message || "Submission failed")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) reset()
        onOpenChange(v)
      }}
    >
      <DialogContent className={DIALOG_CLASS} showCloseButton={false}>
        <DialogHeader className="px-5 pt-5 pb-3 sm:p-0 sm:pb-0 border-b sm:border-0 shrink-0">
          <DialogTitle>Submit service hours</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex-1 relative flex flex-col min-h-0">
          <div className="flex-1 min-h-0 overflow-y-auto scrollbar-thin px-5 py-5 sm:p-0 space-y-5 pb-24 sm:pb-6">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="hours-date" className="text-xs font-medium text-muted-foreground">Date</Label>
                <Input id="hours-date" type="date" value={date} max={todayISO()}
                  onChange={(e) => { setDate(e.target.value); if (dateError) setDateError(null) }}
                  required aria-invalid={!!dateError}
                  className={cn("h-11", dateError && "border-danger/50")}
                />
                {dateError && <p className="text-xs text-danger-foreground">{dateError}</p>}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="hours-num" className="text-xs font-medium text-muted-foreground">Hours</Label>
                <Input id="hours-num" type="number" inputMode="decimal" step="any" min="0.1" max="1000"
                  placeholder="3.5" value={hours}
                  onChange={(e) => { setHours(e.target.value); if (hoursError) setHoursError(null) }}
                  required aria-invalid={!!hoursError}
                  className={cn("h-11", hoursError && "border-danger/50")}
                />
                {hoursError && <p className="text-xs text-danger-foreground">{hoursError}</p>}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="hours-reason" className="text-xs font-medium text-muted-foreground">What did you do?</Label>
              <Textarea id="hours-reason" rows={4}
                placeholder="e.g. Helped set up the spring fair booths."
                value={reason} onChange={(e) => { setReason(e.target.value); if (reasonError) setReasonError(null) }}
                maxLength={2000} required aria-invalid={!!reasonError}
                className={cn(reasonError && "border-danger/50")}
              />
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">{reason.length}/2000</span>
                {reasonError && <span className="text-danger-foreground">{reasonError}</span>}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="hours-category" className="text-xs font-medium text-muted-foreground">Category (optional)</Label>
              {categoriesLoading ? (
                <Skeleton className="h-11 w-full" />
              ) : (
                <Select value={categoryId} onValueChange={setCategoryId}>
                  <SelectTrigger id="hours-category" className="h-11"><SelectValue placeholder="No category" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">No category</SelectItem>
                    {categories.map((c) => (<SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>))}
                  </SelectContent>
                </Select>
              )}
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-muted-foreground">Proof (optional)</Label>
              <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={handleFile} className="hidden" id="hours-proof-input" />
              {proofUrl ? (
                <div className="flex items-center justify-between gap-2 rounded-lg border border-club/30 bg-club-subtle px-3 py-2.5">
                  <div className="flex items-center gap-2 min-w-0">
                    <CheckCircle2 className="h-4 w-4 text-club shrink-0" />
                    <span className="text-sm truncate">{proofLabel || "uploaded"}</span>
                  </div>
                  <Button type="button" variant="ghost" size="sm" onClick={() => fileRef.current?.click()} disabled={uploading}>Replace</Button>
                </div>
              ) : (
                <button type="button" onClick={() => fileRef.current?.click()} disabled={uploading}
                  className="flex items-center justify-center gap-2 w-full h-20 rounded-lg border-2 border-dashed border-border hover:border-club/40 hover:bg-accent/30 transition-colors text-sm text-muted-foreground">
                  {uploading ? <><Loader2 className="h-4 w-4 animate-spin" /> Uploading…</> : <><Upload className="h-5 w-5" /> <span>Tap to upload proof</span></>}
                </button>
              )}
              <p className="text-xs text-muted-foreground">JPG, PNG, WebP, or PDF</p>
            </div>
          </div>
          <div className="pointer-events-none absolute bottom-3 right-3 left-3 z-20 sm:static sm:z-auto sm:pointer-events-auto flex items-center justify-end gap-2">
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)} disabled={submitting}
              className="pointer-events-auto rounded-full sm:rounded-md h-11">
              Cancel
            </Button>
            <Button type="submit" disabled={submitting || uploading} variant="club"
              className="pointer-events-auto rounded-full sm:rounded-md h-11">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              {submitting ? "Submitting…" : "Submit for review"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

// ---------------------------------------------------------------------------
// SetGoalPopover — compact editor for the member's PERSONAL service-hours
// goal. Appears next to the summary's goal bar ("Your goal: 25h") or as the
// "Set a goal" button when no goal exists yet. Saves via PATCH /my-goal.
// ---------------------------------------------------------------------------

function SetGoalPopover({
  clubId,
  current,
  onSaved,
}: {
  clubId: string
  current: number
  onSaved?: () => void
}) {
  const [open, setOpen] = useState(false)
  const [value, setValue] = useState(String(current || ""))
  const [saving, setSaving] = useState(false)

  function clamp(raw: string): number {
    const n = parseInt(raw.replace(/[^\d]/g, ""), 10)
    if (isNaN(n) || n < 0) return 0
    return Math.min(n, 10000)
  }

  async function save() {
    const goal = clamp(value)
    setSaving(true)
    try {
      await api(`/api/clubs/${clubId}/my-goal`, { method: "PATCH", json: { goal } })
      toast.success(goal > 0 ? `Personal goal set to ${goal}h` : "Personal goal cleared")
      setOpen(false)
      onSaved?.()
    } catch (err: any) {
      toast.error(err?.message || "Couldn't save your goal")
    } finally {
      setSaving(false)
    }
  }

  return (
    <Popover
      open={open}
      onOpenChange={(o) => {
        setOpen(o)
        if (o) setValue(current > 0 ? String(current) : "")
      }}
    >
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1.5 h-8">
          <Target className="h-3.5 w-3.5" />
          {current > 0 ? "Change goal" : "Set a goal"}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-64 p-4" aria-label="Edit personal goal">
        <p className="text-sm font-semibold">Personal goal</p>
        <p className="text-caption text-muted-foreground mt-0.5 mb-3">
          Your own target. The club goal applies otherwise.
        </p>
        <div className="flex items-center gap-2">
          <Input
            value={value}
            onChange={(e) => setValue(e.target.value.replace(/[^\d]/g, "").slice(0, 5))}
            inputMode="numeric"
            placeholder="e.g. 25"
            aria-label="Goal in hours"
            className="h-9 w-24 tabular-nums"
            onKeyDown={(e) => { if (e.key === "Enter") save() }}
          />
          <span className="text-caption-medium text-muted-foreground">hours</span>
        </div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {[10, 25, 50, 100].map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => setValue(String(p))}
              className={cn(
                "rounded-md border px-2 py-1 text-xs font-medium tabular-nums transition-colors",
                value === String(p)
                  ? "border-club/40 bg-club-subtle text-club-ink"
                  : "border-border text-muted-foreground hover:border-club/30 hover:text-foreground"
              )}
            >
              {p}h
            </button>
          ))}
          {current > 0 && (
            <button
              type="button"
              onClick={() => setValue("")}
              className="rounded-md border border-border px-2 py-1 text-xs font-medium text-muted-foreground hover:text-destructive transition-colors"
            >
              Clear
            </button>
          )}
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="ghost" size="sm" onClick={() => setOpen(false)} disabled={saving}>
            Cancel
          </Button>
          <Button size="sm" variant="club" onClick={save} disabled={saving}>
            {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
            Save
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  )
}
